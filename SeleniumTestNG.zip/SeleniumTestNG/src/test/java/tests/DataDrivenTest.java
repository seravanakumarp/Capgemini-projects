
package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class DataDrivenTest {

    WebDriver driver;

    @BeforeMethod
    public void setup() {
     	System.setProperty("webdriver.chrome.driver", "C:\\Users\\sekumarp\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://practicetestautomation.com/practice-test-login/"); // Example login site
    }

    @DataProvider(name = "loginData")
    public Object[][] loginDataProvider() {
        return new Object[][] {
            {"student", "Password123"},     // valid
            {"admin", "admin123"},          // invalid
            {"user", "user123"}             // invalid
        };
    }

    @Test(dataProvider = "loginData")
    public void loginTest(String username, String password) {
        driver.findElement(By.id("username")).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);
        driver.findElement(By.id("submit")).click();

        // Simple validation
        boolean isSuccess = driver.getPageSource().contains("Logged In Successfully");
        System.out.println("Login attempt with " + username + "/" + password + ": " + (isSuccess ? "Success" : "Failure"));

        driver.navigate().back(); // Go back to login page for next test
    }

    @AfterMethod
    public void teardown() {
        driver.quit();
    }
}

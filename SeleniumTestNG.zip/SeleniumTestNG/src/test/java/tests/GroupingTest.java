
package tests;

import org.testng.annotations.Test;

public class GroupingTest {

    @Test(groups = {"smoke"})
    public void loginTest() {
        System.out.println("Running Smoke Test: Login");
    }

    @Test(groups = {"regression"})
    public void searchTest() {
        System.out.println("Running Regression Test: Search");
    }

    @Test(groups = {"sanity", "smoke"})
    public void homePageTest() {
        System.out.println("Running Sanity & Smoke Test: Home Page");
    }

    @Test(groups = {"regression"})
    public void checkoutTest() {
        System.out.println("Running Regression Test: Checkout");
    }
}

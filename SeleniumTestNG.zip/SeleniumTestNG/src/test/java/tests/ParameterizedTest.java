package tests;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class ParameterizedTest {

    WebDriver driver;

    @BeforeMethod
    public void setup() {
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\sekumarp\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        
    }

    @Test
    @Parameters({"url", "expectedTitle"})
    public void verifyTitle(@Optional("https://example.com")String url, @Optional("Example Domain")String expectedTitle) {
        driver.get(url);
        String actualTitle = driver.getTitle();
        System.out.println("Page title is: " + actualTitle);
        Assert.assertEquals(actualTitle, expectedTitle, "Title does not match!");
    }

    @AfterMethod
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}

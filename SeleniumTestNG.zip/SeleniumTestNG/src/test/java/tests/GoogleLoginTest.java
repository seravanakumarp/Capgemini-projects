package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class GoogleLoginTest 
{

    WebDriver driver=null;

    @BeforeMethod
    public void setUp() {
        
	    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\sekumarp\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	    	driver = new ChromeDriver();

    }

    @Test
    public void verifyGoogleHomePage() {
        driver.get("https://www.google.com");
        String title = driver.getTitle();
        Assert.assertEquals(title, "Google");
    }

   

    @AfterMethod
    public void tearDown() throws InterruptedException {
        if (driver != null)
        {
        		Thread.sleep(5000); // Wait for 2 seconds to see the result
            driver.quit();
        }
    }
}

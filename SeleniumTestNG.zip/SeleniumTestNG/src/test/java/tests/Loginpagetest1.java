
package tests;

import com.aventstack.extentreports.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import Pages.Loginpage;
import Pages.Loginpage1;
import utils.ExtentReportManager;

public class Loginpagetest1 {
    WebDriver driver;
    Loginpage1 loginpage1;
    ExtentReports extent;
    ExtentTest test;

    @BeforeClass
    public void setup() {
        extent = ExtentReportManager.getReportInstance();
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\sekumarp\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        loginpage1 = new Loginpage1(driver);
    }

    @Test
    public void testLogin() {
        test = extent.createTest("Login Test");
        driver.get("http://www.adactin.com/HotelApp/index.php");
        loginpage1.login("testuser", "securepassword");

        String title = driver.getTitle();
        test.info("Page title: " + title);

        if (title.contains("Dashboard")) {
            test.pass("Login successful.");
        } else {
            test.fail("Login failed.");
        }
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
        extent.flush();
    }
}


package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import Pages.Loginpage;


public class Loginpagetest {
    WebDriver driver;
    
    Loginpage loginpage;

    @BeforeClass
    public void setup() {
    			// Set the path to the ChromeDriver executable
    		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sekumarp\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        
        driver.manage().window().maximize();
        loginpage = new Loginpage(driver);
    }

    @Test
    public void testValidLogin() {
        driver.get("http://www.adactin.com/HotelApp/index.php");
        loginpage.login("testuser", "securepassword");

        // Add your assertion here
        Assert.assertTrue(driver.getTitle().contains("Hotel"));
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}

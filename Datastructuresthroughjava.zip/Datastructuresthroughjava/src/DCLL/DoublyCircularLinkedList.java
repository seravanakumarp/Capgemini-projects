package DCLL;

class Node {
    int data;
    Node next, prev;

    public Node(int data) {
        this.data = data;
        this.next = this.prev = null;
    }
}

public class DoublyCircularLinkedList {
    private Node head;

    public DoublyCircularLinkedList() {
        head = null;
    }

    // Insert at the end
    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            head.next = head;
            head.prev = head;
        } else {
            Node last = head.prev;
            newNode.next = head;
            newNode.prev = last;
            last.next = newNode;
            head.prev = newNode;
        }
    }

    // Delete a node with given value
    public void delete(int key) {
        if (head == null)
            return;

        Node curr = head;
        do {
            if (curr.data == key) {
                if (curr.next == curr) { // only one node
                    head = null;
                    return;
                }
                curr.prev.next = curr.next;
                curr.next.prev = curr.prev;
                if (curr == head)
                    head = curr.next;
                return;
            }
            curr = curr.next;
        } while (curr != head);
    }

    // Display the list forward
    public void displayForward() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        Node temp = head;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != head);
        System.out.println();
    }

    // Display the list backward
    public void displayBackward() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        Node last = head.prev;
        Node temp = last;
        do {
            System.out.print(temp.data + " ");
            temp = temp.prev;
        } while (temp != last);
        System.out.println();
    }

    public static void main(String[] args) {
        DoublyCircularLinkedList dcll = new DoublyCircularLinkedList();
        dcll.insert(10);
        dcll.insert(20);
        dcll.insert(30);
        dcll.insert(40);

        System.out.println("Forward:");
        dcll.displayForward();

        System.out.println("Backward:");
        dcll.displayBackward();

        dcll.delete(20);
        System.out.println("After deleting 20 (Forward):");
        dcll.displayForward();
    }
}


package DoubleLinkedList;

public class Main {

	public static void main(String[] args) {
		MyDoublyLinkList dll = new MyDoublyLinkList();
		dll.addFront(10);
		dll.addFront(20);
		dll.addFront(30);
		dll.display();
		dll.removeFront();
		dll.display();
		dll.addRear(5);
		dll.addRear(2);
		dll.display();
		dll.removeRear();
		dll.removeRear();
		dll.display();
		

	}

}

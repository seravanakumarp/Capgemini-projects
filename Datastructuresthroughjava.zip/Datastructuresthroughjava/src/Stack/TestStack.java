package Stack;

public class TestStack {

	public static void main(String[] args)  {
		StackDemo sd =new StackDemo(3);
		

			try {
				sd.pushDynamicGrow(10);
				sd.pushDynamicGrow(20);
				sd.pushDynamicGrow(30);
				sd.display();
				sd.pushDynamicGrow(40);
				sd.display();
				System.out.println("Popped ele:"+sd.pop());
				System.out.println("Popped ele:"+sd.pop());
				System.out.println("Popped ele:"+sd.pop());
			
				System.out.println("Peek ele:"+sd.peek());
			
			} catch (StackUnderflowException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
	}

}

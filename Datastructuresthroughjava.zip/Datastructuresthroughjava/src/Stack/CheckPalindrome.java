package Stack;

import java.util.Stack;

public class CheckPalindrome {
public static void main(String[] args) {
	String str = "abcba";
	// Stack is a predefined class in Java, part of the Java Collections Framework.
	Stack<Character> orgStr = new Stack<>();
	Stack<Character> revStr = new Stack<>();
	
	for(int i=0;i<str.length();i++)
	{
		orgStr.push(str.charAt(i));
	}
	String newStr="";
	for(int i=0;i<str.length();i++)
	{
		//System.out.println(orgStr.pop());
		
		newStr+=orgStr.pop();
	}
	System.out.println(str+"  "+newStr);
	if(newStr.equals(str))
		System.out.println("Palindrome");
	else
		System.out.println("Not a Palindrome");
		
		
	
}
}

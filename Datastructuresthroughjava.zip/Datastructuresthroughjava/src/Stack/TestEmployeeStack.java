package Stack;

public class TestEmployeeStack {

	public static void main(String[] args) {
		Employee e1=new Employee(100, "Raj", 6000);
		Employee e2=new Employee(101, "Ravi", 7000);
		Employee e3=new Employee(102, "Ram", 8000);
		
		EmployeeStack es = new EmployeeStack(3);
		try {
			es.push(e1);
			es.push(e2);
			es.push(e3);
			es.display();
		} catch (StackOverflowException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (StackUnderflowException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

package Stack;

public class EmployeeStack {
private int size;
private int top;
private Employee[] stack;

public EmployeeStack(int size) {
	super();
	this.size = size;
	top=-1;
	stack=new Employee[3];
}

public void push(Employee ele) throws StackOverflowException 
{
	
	//stack is full ?
	if(top==size-1)
		{
			throw new StackOverflowException("Stack is full!");
		}
		top++;
		stack[top]=ele; //pushed an ele
}
public Employee pop() throws StackUnderflowException
{
	if(top==-1) //stack is empty
	{
		throw new StackUnderflowException("Stack is empty");
	}
	Employee ele=stack[top];
	top--;
	return ele;
}


public Employee peek() throws StackUnderflowException
{
	if(top==-1) //stack is empty
	{
		throw new StackUnderflowException("Stack is empty");
	}
	Employee ele=stack[top];
	return ele;
}


public void display() throws StackUnderflowException
{
	if(top==-1) //stack is empty
	{
		throw new StackUnderflowException("Stack is empty");
	}
	System.out.println(stack[top]+"<----- Top");
	for(int i=top-1;i>=0;i--)
	{
	System.out.println(stack[i]);
	}
	System.out.println("=====================");
}

}

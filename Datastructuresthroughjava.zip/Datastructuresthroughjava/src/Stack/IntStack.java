package Stack;

import java.util.EmptyStackException;

public class IntStack {
	private int[] stack;
	private int top;
	public IntStack(int size)
	{
		this.stack=new int[size];
		this.top=-1;
	}
	
	public void display()
	{
		System.out.println(stack[top]+"<<==Top");
		for(int i=top-1;i>=0;i--)
			System.out.println(stack[i]);
		System.out.println("============");
	}

	public int pop()
	{
		if(top==-1)
			throw new EmptyStackException();
		return stack[top--];
		
	}
	
	public int peek()
	{
		if(top==-1)
			throw new EmptyStackException();
		return stack[top];
		
	}
	public void push(int ele)
	{
		if(top==stack.length-1)
		{
			System.out.println("Array growing dynamically!!!");
			int[] newstack=new int[stack.length*2];
			System.arraycopy(stack, 0, newstack, 0, stack.length);
			stack=newstack;
		}
		stack[++top]=ele;
	}
	
	public static void main(String[] args) {
		IntStack st = new IntStack(3);
		try
		{
		st.pop();
		}
		catch(EmptyStackException es)
		{
			System.out.println("Stack underflow error!");
		}
		st.push(10);
		st.push(20);
		st.push(30);
		st.display();
		st.push(40);
		st.display();
		
		
		
	}

}

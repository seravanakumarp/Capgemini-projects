package Stack;


public class StackUnderflowException  extends Exception {

	public StackUnderflowException ()
	{
		super();
	}
	public StackUnderflowException (String msg)
	{
		super(msg);
	}
}
package Tree;

public class TreeNode {
private int data; //Holds the integer value of the node.
private TreeNode leftChild; // Reference to the left child node.
private TreeNode rightChild; //

public TreeNode get(int value)
{
	//Searches for a node with the given value in the subtree rooted at this node.
	if(value == this.data)
	{
		return this;
	}
	//If the value is less than current node's value, search left subtree if it exists.
	if(value < data)
	{
		if(leftChild != null)
		{
			return leftChild.get(value);
		}
	}
	//If the value is greater, search right subtree if it exists
	else
	{
		if(rightChild != null)
		{
			return rightChild.get(value);
		}
	}
		
	return null;
}

//Finds the minimum value in the subtree.
public int min()
{
	if(leftChild == null)
		return data;
	else
		return leftChild.min();
}
//Finds the maximum value in the subtree.
public int max()
{
	if(rightChild == null)
		return data;
	else
		return rightChild.max();
}
//Inorder Traversal (left, root, right).
public void traverseInnode()
{
	if(leftChild != null)
	{
		leftChild.traverseInnode();
	}
	System.out.println("Data="+data+",");
	if(rightChild != null)
	{
		rightChild.traverseInnode();
	}
}
//Preorder Traversal (root, left, right).
public void traversePrenode()
{
	System.out.println("Data="+data+",");
	if(leftChild != null)
	{
		leftChild.traversePrenode();
	}
	
	if(rightChild != null)
	{
		rightChild.traversePrenode();
	}
}

//Postorder Traversal (left, right, root).
public void traversePostnode()
{
	
	if(leftChild != null)
	{
		leftChild.traversePostnode();
	}
	
	if(rightChild != null)
	{
		rightChild.traversePostnode();
	}
	System.out.println("Data="+data+",");
}
//Inserts a value into the subtree.
public void insert(int value)
{
	if(value == this.data)
		return;
	if(value < data)
	{
		if(leftChild == null)
		{
			leftChild = new TreeNode(value); //place for insertion
		}
		else
			leftChild.insert(value);
	}
	else
	{
		if(rightChild == null)
		{
			rightChild = new TreeNode(value);//place for insertion
		}
		else
			rightChild.insert(value);
	}
}

public int getData() {
	return data;
}


public void setData(int data) {
	this.data = data;
}


public TreeNode getLeftChild() {
	return leftChild;
}


public void setLeftChild(TreeNode leftChild) {
	this.leftChild = leftChild;
}


public TreeNode getRightChild() {
	return rightChild;
}


public void setRightChild(TreeNode rightChild) {
	this.rightChild = rightChild;
}


public TreeNode(int data) {
	super();
	this.data = data;
}


@Override
public String toString() {
	return "TreeNode [data=" + data + ", leftChild=" + leftChild + ", rightChild=" + rightChild + "]";
}

//Deletes a node with the given value from the subtree.
//Recursively finds node, deletes it, and reorganizes children if needed.
public TreeNode delete(TreeNode subTreeRoot,int value)
{
	if(subTreeRoot == null)
	{
		return subTreeRoot;
	}
	if(value < subTreeRoot.getData())
	{
		subTreeRoot.setLeftChild(delete(subTreeRoot.getLeftChild(),value));
	}
	else
		if(value > subTreeRoot.getData()) {
			subTreeRoot.setRightChild(delete(subTreeRoot.getRightChild(),value));
		}
		else
		{
			if(subTreeRoot.getLeftChild() == null)
			{
				return subTreeRoot.getRightChild();
			}
			else
				if(subTreeRoot.getRightChild() == null)
				{
					return subTreeRoot.getLeftChild();
				}
		}
	return subTreeRoot;
}

}



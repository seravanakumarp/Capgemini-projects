package Tree;

public class Main 
{
    public static void main(String[] args) {
        Tree tree = new Tree();       // 1. Create a new empty tree
        tree.insert(10);              // 2. Insert 10 as root
        tree.insert(5);               // 3. Insert 5 (left of 10)
        tree.insert(15);              // 4. Insert 15 (right of 10)
        tree.insert(8);               // 5. Insert 8 (right of 5)
        tree.insert(12);              // 6. Insert 12 (left of 15)
        tree.traverseInorder();       // 7. Print tree inorder: 5, 8, 10, 12, 15
        System.out.println(tree.get(12).getData()); // 8. Find and print 12
        System.out.println("Min:" + tree.min());    // 9. Print min: 5
        System.out.println("Max:" + tree.max());    // 10. Print max: 15

        System.out.println("=============================");
        //tree.delete(5);            // (commented out)
        tree.traverseInorder();       // 11. Print tree inorder again
        System.out.println("=============================");
        tree.traversePreorder();      // 12. Print tree preorder: 10, 5, 8, 15, 12
        System.out.println("=============================");
        tree.traversePostorder();     // 13. Print tree postorder: 8, 5, 12, 15, 10
//        Locates 8 (left of 10, right of 5). Node 8 has no children.
//        Node 8 is removed by setting right child of 5 to null
        tree.delete(8);               // 14. Delete node with value 8
        System.out.println("=============================");
        tree.traverseInorder();       // 15. Print tree inorder after deletion
    }
}
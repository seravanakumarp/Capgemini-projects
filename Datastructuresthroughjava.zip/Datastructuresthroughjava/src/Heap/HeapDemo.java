package Heap;

public class HeapDemo 
{
	//Max Heap implementation
private int[] heap;
private int size;

public HeapDemo(int capacity)
{
	heap=new int[capacity];
	size=0;
}

public void insert(int newVal)
{
	if(isFull())
	{
		throw new ArrayIndexOutOfBoundsException("Heap is full!");
	}
	heap[size]=newVal; //added new element at the end of the heap
	fixHeapAboveSize(size); //Heapify-- converting a binary tree to heap - either max or min
//	In a Max Heap, every parent node is greater than or equal to its children.
//	In a Min Heap, every parent node is less than or equal to its children.
	size++;
	
}

public boolean isFull()
{
	return size==heap.length;
}

public int getParent(int index) //1p
{
	return (index-1)/2;
//	For any node at index i:
//		Parent index = (i-1)/2
//		Left child index = 2*i + 1
//		Right child index = 2*i + 2
}

public void fixHeapAboveSize(int size) //2 3
{
	int newVal = heap[size]; //1 //newVal=6 newVal=4
	int index=size; //index=0 1 2 3
	while(index > 0 && newVal > heap[getParent(index)])
	{   //2 >0 && 6 >heap[0]=8 3>0 && 4>heap[1]=1 1>0 && 4>0heap[0]=8
		heap[index]=heap[getParent(index)]; //h[3]=h[1] 
		index=getParent(index); //
	}
	heap[index]=newVal; //8 4 6 1
}

public void display()
{
	for(int i=0;i<size;i++)
	{
		System.out.print(heap[i]+"  ");
	}
}

}

package Heap;

public class HeapTest {

	public static void main(String[] args) {
	HeapDemo h = new HeapDemo(10);
	h.insert(8);
	h.insert(1);
	h.insert(6);
	h.insert(4);
	h.insert(5);
	h.insert(9);
	h.insert(3);

	h.display();

	}

}

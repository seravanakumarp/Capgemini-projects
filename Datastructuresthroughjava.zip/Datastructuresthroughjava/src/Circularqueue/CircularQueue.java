package Circularqueue;

public class CircularQueue {
	private int[] queue;
	 int front;
	 int rear;

	public CircularQueue(int size)
	{
		queue = new int[size];
		front = -1;
		rear = -1;
	}

	public void enQueue(int ele) throws QueueOverflowException 
	{
	    if (front == -1 && rear == -1) { // Empty Queue
	        front = rear = 0;
	        queue[rear] = ele;
	    } else if ((front == rear + 1) || (front == 0 && rear == queue.length - 1)) {
	        throw new QueueOverflowException(); // Queue Full
	    } else {
	        rear = (rear + 1) % queue.length;
	        queue[rear] = ele;
	    }
	}


	public int deQueue() throws EmptyQueueException {
		if(front == -1 && rear == -1) //queue empty
		{
			throw new EmptyQueueException("Queue is Empty!");
		}
		if(front == rear) //only one element in queue
		{
			int x = queue[front];
			front = rear = -1;
			return x;
		}
		else
			if(front==queue.length-1)
			{
				int x=queue[front];
				front=0;
				return x;
			}
			else
				return queue[front++];   //more elements in queue
	}

	public int peek() throws EmptyQueueException {
		if(front == -1 && rear == -1)
		{
			throw new EmptyQueueException("Queue is Empty!");
		}
		return queue[front];
	}

	public void display()
	{
		if(front!=-1 && rear!=-1)
		{
		if(front<rear)
		{
			for(int i=0;i<front;i++)
				System.out.print(" * ");
			for(int i=front;i<=rear;i++)
				System.out.print(queue[i]+" ");
			for(int i=rear+1;i<queue.length;i++)
				System.out.print(" * ");
			
		}
		else //rear<front
		{

			
			for(int i=0;i<=rear;i++)
				System.out.print(queue[i]+" ");
			for(int i=rear+1;i<front;i++)
				System.out.print(" * ");
			for(int i=front;i<queue.length;i++)
				System.out.print(queue[i]+" ");
		}
		System.out.println("\n================");
		}
		
	}

	}


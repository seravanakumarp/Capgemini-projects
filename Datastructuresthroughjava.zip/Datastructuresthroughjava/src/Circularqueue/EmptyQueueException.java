package Circularqueue;

public class EmptyQueueException extends Exception {

	
	public EmptyQueueException(String msg)
	{
		super(msg);
	}
}

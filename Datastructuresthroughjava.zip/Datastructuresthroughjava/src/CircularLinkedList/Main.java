package CircularLinkedList;
// Node class
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

// Circular Linked List class
class CircularLinkedList {
    private Node head = null;
    private Node tail = null;

    // Insert a node at the end
    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) { // First node
            head = newNode;
            tail = newNode;
            newNode.next = head; // Circular link
        } else {
            tail.next = newNode;
            tail = newNode;
            tail.next = head; // Keep it circular
        }
    }

    // Display the list
    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    // Delete a node from the list
    public void delete(int key) {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        Node prev = null;

        // If head is to be deleted
        if (head.data == key) {
            if (head == tail) { // Only one element
                head = null;
                tail = null;
                return;
            }
            head = head.next;
            tail.next = head;
            return;
        }

        // Search for node to delete
        do {
            prev = current;
            current = current.next;
            if (current.data == key) {
                prev.next = current.next;
                if (current == tail) {
                    tail = prev;
                }
                return;
            }
        } while (current != head);

        System.out.println("Node " + key + " not found.");
    }
}

// Test the Circular Linked List
public class Main {
    public static void main(String[] args) {
        CircularLinkedList cll = new CircularLinkedList();

        cll.insert(10);
        cll.insert(20);
        cll.insert(30);
        cll.insert(40);

        System.out.print("Circular Linked List: ");
        cll.display();

        cll.delete(20);
        System.out.print("After deleting 20: ");
        cll.display();

        cll.delete(10);
        System.out.print("After deleting 10: ");
        cll.display();

        cll.delete(50); // Not in list
    }
}

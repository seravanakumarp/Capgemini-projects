package DoubleEndedQueue;

public class Test {

	public static void main(String[] args) 
	{
		Deque dq = new Deque(5);

        dq.insertRear(10);
        dq.insertRear(20);
        dq.insertFront(5);
        dq.insertFront(2);
        dq.display(); // Output: 2 5 10 20

        dq.deleteRear();
        dq.deleteFront();
        dq.display(); // Output: 5 10
	}

}

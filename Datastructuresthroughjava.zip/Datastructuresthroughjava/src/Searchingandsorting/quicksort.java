package Searchingandsorting;
import java.util.*;
class quicksort
{
					
	static void quicksort(int a[],int lower,int upper) //qs(a,0,9) qs(a,0,3)
	{
		int i;
	
		if(upper>lower)  //(9>0) 3>0
		{
			i=split(a,lower,upper); //split(a,0,9) i=4 split(a,0,3) i=0
			quicksort(a,lower,i-1);  //qs(a,0,3) qs(a,0,-1)
			quicksort(a,i+1,upper);  //qs(a,5,9) qs(a,1,3)
		}
		
		
	}
	
	static int split(int a[],int lower,int upper) //split(a,0,9) split(a,0,3)
	{
			int i,p,q,t;
			p=lower+1;  //p=0+1=1 p=0+1=1
			q=upper; //q=9  q=3
			i=a[lower]; // i=a[0]=11 i=a[0]=1
			while(q>=p) //9>=1 9>=3 7>=4 4>=5 3>=1 0>=1
				{
					while(p<=q && a[p]<=i) //1<=9 && 2<=11 2<=9 && 9<=13 //3<=9 && 13<=11 3<=9 && 3<=11 4<=9&& 57<=11 4<=7&& 1<=11 5<=7 && 25<=11 1<=3&& 2<=1
 						p++;  //p=2 p=3 p=4 p=5
					while(a[q]>i) //a[9]>11 3>11 13>11 90>11 1>11 17>11 //25>11 1>11 3>1 9>1 2>1 1>1
						q--;   //q=8 q=7 q=6 q=5 q=4 q=2 q=1 q=0
					
					if(q>p) //9>3 7>4 4>5 0>1
					{
			
     						t=a[p];  
     						a[p]=a[q]; 
						a[q]=t;  
					}
 					
				}
			t=a[lower]; //t=a[0]=11 t=a[0]=1
			a[lower]=a[q]; //a[0]=a[4] a[0]=a[0]
			a[q]=t;  //a[4]=11
			
			return q; //4 0
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int a[]=new int[20];
		int i,n;
		System.out.println("enter the size of array a");
		n=sc.nextInt();
		System.out.println("enter the array a elements");
		for(i=0;i<n;i++)
			a[i]=sc.nextInt(); //11 2 9 13 57 25 17 1 90 3
		
		quicksort(a,0,n-1);// calling method 
		
		for(i=0;i<n;i++)
			System.out.print(a[i]+" ");
		
	}
}
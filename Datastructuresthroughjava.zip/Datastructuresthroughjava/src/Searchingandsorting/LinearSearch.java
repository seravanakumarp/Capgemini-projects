package Searchingandsorting;



public class LinearSearch {
	int[] arr = {10,9,8,7,6,5,4,3,2,1};
	
	//O(n)
	public  int linearSearch(int searchEle)
	{
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i] == searchEle)
			{
				return i;
			}
		}
		return -1;
	}
public static void main(String[] args) {
	
	
	
	int searchEle = 9;
	int res = new LinearSearch().linearSearch(searchEle);
	System.out.println("ELe found at index:"+(res));
	
}
}

package Searchingandsorting;
import java.util.*;
class binarysearch
{
	static void sort(int a[],int n)
		{
				int i,j,temp;
				for(i=0;i<n;i++)
				{
					for(j=i+1;j<n;j++)
					{
						if(a[i]>a[j])
						{
							temp=a[i];
							a[i]=a[j];
							a[j]=temp;
						}
					}
				}
			}
		static void binary_search(int a[],int n,int keyelement)
			{
					int i,mid=0,flag=0,low,high;
					low=0;
					high=n-1;
					for(i=0;i<n;i++)
						{
							mid=(low+high)/2;
							if(keyelement==a[mid])
								{		
									flag=1;
									break;
								}
							else if(keyelement>a[mid])
									low=mid+1;
							else
									high=mid-1;
						}
					if(flag==1)
						System.out.println("search is successful! Keyelement found at"+mid);
					else
						System.out.println("keyelement not found");
				}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int a[]=new int[20];
		int n,i,keyelement;
		System.out.println("enter the size of array a");
		n=sc.nextInt();
		System.out.println("enter the array a elements");
		for(i=0;i<n;i++)
		a[i]=sc.nextInt();
		System.out.println("enter the keyelement need to be searched");
		keyelement=sc.nextInt();
		sort(a,n);
		binary_search(a,n,keyelement);
	}
}
	
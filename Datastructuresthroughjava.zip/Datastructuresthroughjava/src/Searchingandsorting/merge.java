package Searchingandsorting;
import java.util.*;
class merge
{
public static void main(String args[])
{
    Scanner sc=new Scanner(System.in);
    int a[]=new int[10];
    int i, size;

    System.out.println("How Many elements u want to Sort :: ");
    size=sc.nextInt();

    System.out.println("Enter the array a elements");

    for(i = 0; i < size; i++)
    a[i]=sc.nextInt();

    partition(a, 0, size - 1); //calling method

    System.out.println("sorted list is ");
    for(i = 0;i < size; i++)
    {
         System.out.print(a[i]+"\t");
    }
}


static void partition(int a[],int low,int high)
{
    int mid;

    if(low < high) //0<8
    {
        mid = (low + high) / 2; //4
        partition(a, low, mid); //p(a,0,4)
        partition(a, mid + 1, high); //p
        mergeSort(a, low, mid, high); //
    }
}
									  
static void mergeSort(int arr[],int left,int mid,int right)
{
    
    int i, j, k;
    int s1 = mid - left + 1; //s1=0-0+1=1
    int s2 = right - mid;  //s2=1-0=1	
 
    /* It will create two temporary arrays */
    int left_arr[]= new int[s1]; //1
    int right_arr[]=new int[s2]; //1
 
    /* It will copy data from arr to temporary arrays */
    for (i = 0; i < s1; i++)  //0<1 1<1
        left_arr[i] = arr[left + i]; //left_arr[0]=arr[0+0]=arr[0]=15 
     
    for (j = 0; j < s2; j++)  //0<1
        right_arr[j] = arr[mid + 1 + j];  //right_arr[0]=arr[0+1+0]=arr[1]=5
    
    i = 0; j = 0;  
    k = left; 
    while (i < s1 && j < s2) //0<1 && 0<1 0<1 && 1<1
    {
        if (left_arr[i] <= right_arr[j]) //15<=5
        {
            arr[k] = left_arr[i];
            i++;
        }
        else {
            arr[k] = right_arr[j];  //arr[0]=5 
            j++;
        }
        k++; 
    }
 
    /* Copying the items of left_arr[] that have been left */
    while (i < s1) //0<1 1<1
    {
        arr[k] = left_arr[i]; //arr[1]=15
        i++; //1
        k++; //2
    }
 
    /* Copying the items of right_arr[] that have been left */
    while (j < s2)  //1<1
    {
        arr[k] = right_arr[j];
        j++;
        k++;
    }
}
}
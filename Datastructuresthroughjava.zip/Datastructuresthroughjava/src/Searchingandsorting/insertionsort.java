package Searchingandsorting;
import java.util.*;
class insertionsort
{
		public static void main(String args[])
		{
			Scanner sc=new Scanner(System.in);
			int a[]=new int[20];
			int i,n,j,temp,p;
			System.out.println("enter the size of array a");
			n=sc.nextInt();
			System.out.println("enter the array a elements");
			for(i=0;i<n;i++)
				a[i]=sc.nextInt();
			for(i=1;i<n;i++) //i=2 i=3
			{
				temp=a[i]; //temp=a[1]=12 87 25
				j=i-1; //j=0 j=1 j=2
				while(j>=0&&a[j]>temp) //0>=0 && a[0]>12
					{                  //1>=0 && a[1]>25
							a[j+1]=a[j]; //a[3]=a[2]
							j--; 
					}
							a[j+1]=temp;
			
				for(p=0;p<n;p++)
					System.out.print(a[p]+"\t");
					System.out.println();
			}
			for(i=0;i<n;i++)
					System.out.print(a[i]+"\t");
		}
}
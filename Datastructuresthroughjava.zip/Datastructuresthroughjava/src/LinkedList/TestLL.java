package LinkedList;



public class TestLL {

	public static void main(String[] args) {
		Employee e1=new Employee(100, "Raj", 6000);
		Employee e2=new Employee(101, "Ravi", 7000);
		Employee e3=new Employee(102, "Ram", 8000);
		Employee e4=new Employee(103, "Giri", 8000);
		Employee e5=new Employee(104, "Hari", 8000);
		Employee e6=new Employee(105, "Sam", 9000);
		EmployeeLinkList ll=new EmployeeLinkList(); //head=null
		ll.insertFront(e1);
		ll.insertFront(e2);
		ll.insertFront(e3);
		ll.display();
		ll.insertLast(e4);
		ll.insertInbetween(e5, 101);
		ll.insertInbetween(e6, 103);
		System.out.println("=============");
		ll.display();
		//ll.removeFirst();
		//ll.removeLast();
		//ll.display();
		

	}

}

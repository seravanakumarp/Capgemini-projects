package LinkedList;

public class MyLinkList {
private Node head;


public MyLinkList()
{
	head=null;
}

public void addFront(int data)
{
	Node newNode=new Node(data);
	if(head==null)
	{
		head=newNode;
	}
	else
	{
		newNode.setNext(head);
		head=newNode;
	}
}

public void addEnd(int data)
{
	
	Node newNode=new Node(data);
	if(head==null)
	{
		head=newNode;
	}
	else
	{
		Node temp=head;
		while(temp.getNext()!=null)
		{
			temp=temp.getNext();
		}
		temp.setNext(newNode);
		
	}
}

public void removeFront()
{
	Node temp=head;
	head=head.getNext();
	temp.setNext(null);
	
}

public void removeEnd()
{
	Node temp=head;
	while(temp.getNext().getNext()!=null)
	{
		temp=temp.getNext();
	}
	//Node delNode=temp.getNext();
	temp.setNext(null);
	
}
public void display()
{
	Node temp=head;
	System.out.print("head -> ");
	while(temp!=null)
	{
		System.out.print(temp.getData()+" -> ");
		temp=temp.getNext();
	}
	System.out.print(" end");
	System.out.println();
}

}

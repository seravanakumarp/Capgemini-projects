package LinkedList;

public class Employee {
private int id;
private String name;
private double salary;
private Employee next;// Self referential class

public Employee(int id, String name, double salary) {
	super();
	this.id = id;
	this.name = name;
	this.salary = salary;
	this.next=null;
}


public Employee getNext() {
	return next;
}

public void setNext(Employee next) {
	this.next = next;
}



@Override
public String toString() {
	//return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", next=" + next + "]";
	return " "+name;
}


public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}






}

package Queue;

public class Employee1 {
	private String firstName;
	private String lastName;
	private double Salary;
	
	public Employee1()
	{
		
	}

	public Employee1(String firstName, String lastName, double salary) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		Salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [firstName=" + firstName + ", lastName=" + lastName + ", Salary=" + Salary + "]";
	}
	
	
}

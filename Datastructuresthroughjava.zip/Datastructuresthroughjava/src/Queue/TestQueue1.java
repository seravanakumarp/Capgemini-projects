package Queue;


public class TestQueue1 {
public static void main(String[] args) throws EmptyQueueException  {
	ArrayQueue queue = new ArrayQueue(3);
	queue.enQueue(new Employee1("Raj","Sharma",5000));
	queue.enQueue(new Employee1("Ravi","Verma",5000));
	queue.deQueue();
	
	queue.enQueue(new Employee1("Giri","Bose",5000));
	//queue.deQueue();
	queue.enQueue(new Employee1("Hari","Verma",5000));
	//queue.deQueue();
	queue.enQueue(new Employee1("John","Bose",5000));
//	queue.display();
	queue.deQueue();
//	queue.display();
	queue.deQueue();
//	queue.enQueue(new Employee1("John","Bose",5000));
	queue.display();
}
}

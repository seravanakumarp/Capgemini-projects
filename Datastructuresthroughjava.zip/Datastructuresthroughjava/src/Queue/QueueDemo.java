package Queue;

public class QueueDemo {
private int[] queue;
private int size;
private int front;
private int rear;

public QueueDemo( int size) {
	super();
	this.size = size;
	this.queue = new int[this.size];
	this.front = -1;
	this.rear = -1;
}

public void enQueue(int ele) throws QueueOverflowException
{
	if(rear==size-1)
	{
		throw new QueueOverflowException("Queue is full");
	}
	if(front==-1) //No elements
	{
		front=0;
	}
	rear++; 
	queue[rear]=ele;

}

public void enQueueDynamicGrow(int ele) 
{
	if(rear==size-1)
	{
		//code dynamic grow
		this.size=this.size*2;
		int[] newQueue=new int[this.size];
		System.arraycopy(queue, 0, newQueue, 0, queue.length);
		queue=newQueue;
	}
	if(front==-1) //No elements
	{
		front=0;
	}
	rear++; 
	queue[rear]=ele;

}

public int deQueue() throws QueueUnderflowException
{
	if(front==-1) //empty
	{
		throw new QueueUnderflowException("Queue is empty");
	}
	int ele = queue[front];
	if(front==rear) //only one ele
	{
		front=-1;
		rear=-1;
	}
	else
		front++; //when more ele are there
	return ele;
}


public int peek() throws QueueUnderflowException
{
	if(front==-1) //empty
	{
		throw new QueueUnderflowException("Queue is empty");
	}
	int ele = queue[front];
	return ele;
}

public void display()
{
	System.out.println();
	for(int i=front;i<=rear;i++)
	{
		System.out.print(queue[i]+" ");
	}
	System.out.println();
}
}
package Queue;

public class ArrayQueue {
private Employee1[] queue;
private int front;
private int rear;

public ArrayQueue(int size)
{
	queue = new Employee1[size];
	front = -1;
	rear = -1;
}

public void enQueue(Employee1 employee)
{
	if(front == -1 && rear == -1) //Empty Queue
	{
		front++;
	}
	else
	{
		if(rear == queue.length-1) //Resizing queue if full
		{
			Employee1[] newArray = new Employee1[queue.length*2];
			System.arraycopy(queue, 0, newArray, 0, queue.length);
			queue = newArray;
		}
	}
	queue[++rear] = employee;
}


public Employee1 deQueue() throws EmptyQueueException {
	if(front == -1 && rear == -1) //queue empty
	{
		throw new EmptyQueueException("Queue is Empty!");
	}
	if(front == rear) //only one element in queue
	{
		Employee1 x = queue[front];
		front = rear = -1;
		return x;
	}
	return queue[front++];   //more elements in queue
}

public Employee1 peek() throws EmptyQueueException {
	if(front == -1 && rear == -1)
	{
		throw new EmptyQueueException("Queue is Empty!");
	}
	return queue[front];
}

public void display()
{
	for(int i=front;i<=rear;i++)
	{
		System.out.println(queue[i]+"  ");
	}
}

}

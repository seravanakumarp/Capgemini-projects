package Queue;


import Queue.EmptyQueueException;

public class IntQueue
{
	private int[] queue;
	private int front;
	private int rear;
	
	public IntQueue(int size)
	{
		this.queue=new int[size];
		front=-1;
		rear=-1;
	}
	
	public void enQueue(int ele)
	{
		if(front==-1) //queue empty
		{
			front++;
		}
		else
			if(rear==queue.length-1) //queue is full-resize queue
			{
				int[] newQueue=new int[queue.length*2];
				System.arraycopy(queue, 0, newQueue, 0, queue.length);
				queue=newQueue;
				System.out.println("Queue is growing dynamically!!!");
			}
		queue[++rear]=ele;
	}

	public int deQueue() throws EmptyQueueException
	{
		int x;
		if(front==-1)//Queue empty
		{
			throw new EmptyQueueException("Queue Empty!!");
			
		}
		if(front==rear) //only one element
		{
			x=queue[front];
			front=-1;
			rear=-1;
		}
		else
			x=queue[front++];
		return x;
	}
	
	public int peek() throws EmptyQueueException
	{
		int x;
		if(front==-1)//Queue empty
		{
			throw new EmptyQueueException("Queue Empty!!");
			
		}		
			x=queue[front];
		return x;
	}
	
	public void display()
	{
		for(int i=front;i<=rear;i++)
			System.err.print(queue[i]+" ");
	}
	public static void main(String[] args) {
	IntQueue iq = new IntQueue(3);
//	iq.enQueue(10);
//	try {
//		System.out.println("popped ele="+iq.deQueue());
//	} catch (EmptyQueueException e) {
//		System.out.println("Queue Empty");
//		
//	}
	iq.enQueue(10);
	iq.enQueue(20);
	iq.enQueue(30);
	iq.enQueue(40);
	iq.enQueue(50);
	iq.enQueue(60);
	iq.enQueue(70);
	iq.display();
	

	}

}

package Queue;


public class EmptyQueueException extends Exception {

    // Default constructor
    public EmptyQueueException() {
        super("Queue is empty!");
    }

    // Constructor with custom message
    public EmptyQueueException(String message) {
        super(message);
    }
}

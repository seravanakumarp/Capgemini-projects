package authentication;


import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class Preemptiveauthentication {
    public static void main(String[] args) {
        RestAssured.baseURI = "https://httpbin.org";

        given().
            auth().preemptive().basic("user", "passwd").
        when().
            get("/basic-auth/user/passwd").
        then().
            statusCode(200).
            log().all();
    }
}

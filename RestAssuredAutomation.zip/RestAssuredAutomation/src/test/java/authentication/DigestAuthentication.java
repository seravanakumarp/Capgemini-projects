package authentication;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class DigestAuthentication {
    public static void main(String[] args) {
        RestAssured.baseURI = "https://httpbin.org";

        given().
            auth().digest("user", "passwd").
        when().
            get("/digest-auth/auth/user/passwd").
        then().
            statusCode(200).
            log().all();
    }
}

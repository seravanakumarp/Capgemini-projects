package authentication;


import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.json.simple.JSONObject;

public class BearerTokenAuth {
    public static void main(String[] args) {
        RestAssured.baseURI = "https://reqres.in/api";

        JSONObject loginPayload = new JSONObject();
        loginPayload.put("email", "eve.holt@reqres.in");
        loginPayload.put("password", "cityslicka");

        Response response = RestAssured
            .given()
                .header("Content-Type", "application/json")
                .header("x-api-key","reqres-free-v1")
                .body(loginPayload.toJSONString())
            .when()
                .post("/login");

        System.out.println("Response: " + response.asString());

        String token = response.jsonPath().getString("token");
        System.out.println("Token: " + token);
    }
}

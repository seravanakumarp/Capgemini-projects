package authentication;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.*;

public class BasicAuthenticationRestAssured {
    public static void main(String[] args) {
        RestAssured.baseURI = "https://httpbin.org";

        given().
            auth().basic("user", "passwd").
            accept(ContentType.JSON).
        when().
            get("/basic-auth/user/passwd").
        then().
            statusCode(200).
            log().all();
    }
}

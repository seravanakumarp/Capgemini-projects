package tests;

import io.restassured.RestAssured;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;

public class BasicAuthenticationRestAssured 
{

	public void basicAuthentication()
	
	{
		//way 1 
		RestAssured.baseURI = "https://postman-echo.com/basic-auth";
		RequestSpecification requestSpec = RestAssured.given();
		
		Response response=requestSpec.get();
		
		System.out.println(response.getBody().asPrettyString());
		
//		JsonPath jsonPath = response.jsonPath();
//		
//		String authenticated=jsonPath.getString("authenticated");
//		
//		Assert.assertEquals(response.statusCode(),200);
//		Assert.assertEquals(authenticated,"true");
		//way2
		
			
		
	}
}

package Test22;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBrowserMaximization {

	public static void main(String[] args) throws Exception
	{
		//Way1 - Chrome
		
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver=new ChromeDriver();
//		Thread.sleep(3000);
//		
//		driver.manage().window().maximize();
//		driver.get("https://www.google.com/");
//		
		
		//Edge
//		WebDriverManager.edgedriver().setup();
//		WebDriver driver=new EdgeDriver();
//		Thread.sleep(3000);
//		
//		driver.manage().window().maximize();
//		driver.get("https://www.google.com/");
//		
		//Way2 -Chrome
//		WebDriverManager.chromedriver().setup();
//		ChromeOptions options=new ChromeOptions();
//		options.addArguments("start-maximized");
//		WebDriver driver=new ChromeDriver(options);
//		Thread.sleep(3000);
//		driver.get("https://www.google.com/");
//		
		//Edge
		WebDriverManager.edgedriver().setup();
		EdgeOptions options=new EdgeOptions();
		options.addArguments("start-maximized");
		WebDriver driver=new EdgeDriver(options);
		Thread.sleep(3000);
		driver.get("https://www.google.com/");
		
		
	
		
		
		
	}

}

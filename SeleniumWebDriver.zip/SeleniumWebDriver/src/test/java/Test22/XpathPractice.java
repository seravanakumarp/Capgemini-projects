package Test22;

import java.nio.Buffer;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class XpathPractice
{
	private static WebDriver driver;
	public static void main(String[] args)
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		//chapter2();
		//chapter3();
		//chapter4();
		//chapter5();
		//chapter6();
		//chapter7();
		//chapter8();
		chapter9();
	}

	public static void highlight(WebDriver driver, Object object) {
	    JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
	    jsExecutor.executeScript("arguments[0].setAttribute('style', 'border: 2px solid red; background: yellow;')", object);
	}
	
	//Types of XPath
	public static void chapter2()
	{
		driver.get("https://www.w3schools.in/");
		//Absolute XPath
		//highlight(driver, driver.findElement(By.xpath("/html/body/div[2]/div[1]/form[1]")));
		
		//Relative XPath
		highlight(driver, driver.findElement(By.xpath("//a[text()='Example Programs']")));
		
	}
	
	public static void chapter3()
	{
		driver.get("https://www.w3schools.com");
		//highlight(driver,driver.findElement(By.xpath("//div[@id='tnb-login-btn']")));
		highlight(driver,driver.findElement(By.xpath("//input[@placeholder=\"Search...\"]")));

	}
	
	public static void chapter4()
	{
		driver.get("https://www.hyrtutorials.com/p/add-padding-to-containers.html");
		driver.findElement(By.xpath("//input[@maxlength=10]")).sendKeys("Test");
		
		driver.findElement(By.xpath("//input[@maxlength!=10]")).sendKeys("Test2");
		
		List<WebElement> elements=driver.findElements(By.xpath("//input[@maxlength<=15]"));
		for(WebElement element:elements)
		{
			highlight(driver, element);
		}
	}
	
	public static void chapter5()
	{
		driver.get("https://www.hyrtutorials.com/p/add-padding-to-containers.html");
//		List<WebElement> elements=driver.findElements(By.xpath("//input[@maxlength<=15 and @name='name' and @type='text']"));
//		System.out.println(elements.size());
//		List<WebElement> elements2=driver.findElements(By.xpath("//input[@maxlength<=15 and @name='name' or @type='tt']"));
//		System.out.println(elements2.size());
//		
		List<WebElement> elements3=driver.findElements(By.xpath("//input[not(@maxlength=10)]"));
		System.out.println(elements3.size());
		
	}
	
	public static void chapter6()
	{
		driver.get("https://www.hyrtutorials.com/p/add-padding-to-containers.html");
		highlight(driver, driver.findElement(By.xpath("(//table[@id='contactList']/tbody/tr/td)[23]")));
			
	}
	
	public static void chapter7()
	{
		driver.get("https://www.hyrtutorials.com/p/add-padding-to-containers.html");

		//highlight(driver, driver.findElement(By.xpath("//a[text()='Sign in']")));
		
		//highlight(driver, driver.findElement(By.xpath("//a[contains(text(),'account')]")));
		
		//highlight(driver, driver.findElement(By.xpath("//div[contains(@class,'signin')]")));
		
		//highlight(driver, driver.findElement(By.xpath("//a[starts-with(text(),'Sign in into')]")));
		
		//highlight(driver, driver.findElement(By.xpath("//label[normalize-space(text())='First Name']")));
		
		//highlight(driver, driver.findElement(By.xpath("(//table[@id='contactList']/tbody/tr)[last()]")));
		
		List<WebElement> rows = driver.findElements(By.xpath("//table[@id='contactList']/tbody/tr[position()>2]"));

		for (WebElement row : rows) {
		    highlight(driver, row); // Assuming highlight is defined
		}

		System.out.println("Number of rows after the second row: " + rows.size());
		
	}
	
	public static void chapter8()
	{
		driver.get("https://www.hyrtutorials.com/p/add-padding-to-containers.html");
		//highlight(driver, driver.findElement(By.xpath("//label[text()='Email']/following-sibling::input[@type='text']")));

		driver.findElement(By.xpath("//td[text()='Maria Anders']/preceding-sibling::td/input")).click();

		//parent identification
		//highlight(driver, driver.findElement(By.xpath("//td[text()='Helen Bennett']/parent::tr")));
		//highlight(driver,driver.findElement(By.xpath("//td[text()='Helen Bennett']/ancestor-or-self::*")));
		//table[@id='contactList']/descendant-or-self::*
		
		//preceding and following
		//highlight(driver,driver.findElement(By.xpath("//label[text()='Password']/parent::div/following::input")));
		highlight(driver,driver.findElement(By.xpath("//label[text()='Password']/parent::div/preceding::input[1]")));
		

	}
	//shortcuts
	public static void chapter9()
	{
		driver.get("https://www.hyrtutorials.com/p/add-padding-to-containers.html");
		
		//text() -> .
//		highlight(driver,driver.findElement(By.xpath("//h1[.='Register']")));
//		highlight(driver,driver.findElement(By.xpath("//a[contains(.,'account')]")));
//		highlight(driver,driver.findElement(By.xpath("//td[starts-with(.,'Maria')]")));
//		highlight(driver,driver.findElement(By.xpath("//label[normalize-space(.)='First Name']")));
//		
		//child -> /
		
		//highlight(driver,driver.findElement(By.xpath("//div[@class='container']/h1")));
		
		//parent ->/..
		//highlight(driver,driver.findElement(By.xpath("//h1[.='Register']/..")));
		
		//descendant  ->//
		List<WebElement> elements=driver.findElements(By.xpath("//table[@id='contactList']//td"));
		for(WebElement element:elements)
		{
			highlight(driver, element);
		}
	}
}

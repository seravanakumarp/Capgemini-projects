package Test22;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.Alert;
import java.time.Duration;


import io.github.bonigarcia.wdm.WebDriverManager;
/**
 * 
 * How to perform below operations using Selenium WebDriver?
 * MoveToElement or MouseHover,
 * Click,
 * Double Click, 
 * Right click or Context Click 
 */
public class TestActions {

	public static void main(String[] args) throws InterruptedException
	{
		
		        // Setup ChromeDriver
		        io.github.bonigarcia.wdm.WebDriverManager.chromedriver().setup();
		        WebDriver driver = new ChromeDriver();
		        driver.manage().window().maximize();
		        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		        // Navigate to demo site
		        driver.get("https://demo.guru99.com/test/simple_context_menu.html");
		        Thread.sleep(2000); // Delay after page load

		        // Initialize Actions class
		        Actions actions = new Actions(driver);

		        // 1. Right Click (Context Click)
		        WebElement rightClickBtn = driver.findElement(By.xpath("//span[text()='right click me']"));
		        actions.contextClick(rightClickBtn).perform();
		        Thread.sleep(2000); // Delay after right click

		        WebElement editOption = driver.findElement(By.xpath("//li[contains(@class,'context-menu-item')]/span[text()='Edit']"));
		        editOption.click();
		        Thread.sleep(1000); // Delay before handling alert

		        Alert alert = driver.switchTo().alert();
		        System.out.println("Right Click Alert: " + alert.getText());
		        alert.accept();
		        Thread.sleep(2000); // Delay after alert

		        // 2. Double Click
		        WebElement doubleClickBtn = driver.findElement(By.xpath("//button[text()='Double-Click Me To See Alert']"));
		        actions.doubleClick(doubleClickBtn).perform();
		        Thread.sleep(1000); // Delay before handling alert

		        Alert doubleClickAlert = driver.switchTo().alert();
		        System.out.println("Double Click Alert: " + doubleClickAlert.getText());
		        doubleClickAlert.accept();
		        Thread.sleep(2000); // Delay after alert

		        // 3. Mouse Hover (simulated by moving to element)
		        actions.moveToElement(doubleClickBtn).perform();
		        System.out.println("Mouse hover performed.");
		        Thread.sleep(2000); // Delay after hover

		        // 4. Click (simple click)
		        rightClickBtn.click();
		        System.out.println("Simple click performed.");
		        Thread.sleep(2000); // Delay after click

		        // Close browser
		        driver.quit();
		    }
				

	

}

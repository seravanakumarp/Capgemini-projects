package Test22;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * 
 * How to handle alerts in a web page using Selenium WebDriver?
 */

public class TestAlerts {

	public static void main(String[] args) throws Exception
	{
		//Alerts: Alert Box:missing fields updation, Confirm Box:confirmation, Prompt Box: used to take input
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.hyrtutorials.com/p/alertsdemo.html");
		
		//alert box
		System.out.println(driver.findElement(By.id("output")).getText());
		driver.findElement(By.id("alertBox")).click();
		Thread.sleep(3000);
		System.out.println(driver.switchTo().alert().getText());
		driver.switchTo().alert().accept(); //works like ok
		System.out.println(driver.findElement(By.id("output")).getText());

		//confirm box
		System.out.println(driver.findElement(By.id("output")).getText());
		driver.findElement(By.id("confirmBox")).click();
		Thread.sleep(3000);
		System.out.println(driver.switchTo().alert().getText());
		driver.switchTo().alert().accept(); //works like ok
		System.out.println(driver.findElement(By.id("output")).getText());
		
		
		System.out.println(driver.findElement(By.id("output")).getText());
		driver.findElement(By.id("confirmBox")).click();
		Thread.sleep(3000);
		System.out.println(driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss(); //works like cancel
		System.out.println(driver.findElement(By.id("output")).getText());
		
		//prompt box
		
		System.out.println(driver.findElement(By.id("output")).getText());
		driver.findElement(By.id("promptBox")).click();
		Thread.sleep(3000);
		System.out.println(driver.switchTo().alert().getText());
		driver.switchTo().alert().sendKeys("welcome to selenium");
		driver.switchTo().alert().accept(); //works like ok
		System.out.println(driver.findElement(By.id("output")).getText());
		
		
		
		driver.findElement(By.id("promptBox")).click();
		System.out.println(driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss(); //works like cancel
		System.out.println(driver.findElement(By.id("output")).getText());
		
		Thread.sleep(3000);
		driver.quit();
	}

}

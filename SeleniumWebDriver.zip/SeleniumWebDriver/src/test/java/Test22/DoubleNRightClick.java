package Test22;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DoubleNRightClick {

	public static void main(String[] args)
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		
		driver.get("https://demo.guru99.com/test/simple_context_menu.html");
		
		//double click 
		
		WebElement doubleClickButton=driver.findElement(By.xpath("//*[@id=\"authentication\"]/button"));
		
		Actions actions=new Actions(driver);
		
//		actions.doubleClick(doubleClickButton).build().perform();
//
//		
//		System.out.println("Double click alert message"+driver.switchTo().alert().getText());
		
		
		//Right click

		WebElement rightClickButton=driver.findElement(By.xpath("//*[@id=\"authentication\"]/span"));
		
		actions.contextClick(rightClickButton).perform();
		
		driver.findElement(By.xpath("//*[@id=\"authentication\"]/ul/li[3]/span")).click();
		
		
	}

}

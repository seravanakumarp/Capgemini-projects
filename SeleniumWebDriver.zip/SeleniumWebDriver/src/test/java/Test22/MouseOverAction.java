package Test22;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MouseOverAction {

	public static void main(String[] args) 
	{

		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		

		// Open the target website
		driver.get("https://demoqa.com/menu");
		

		// Wait for the menu to be visible
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement menuItem = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Main Item 2']")));

		// Perform hover using Actions
		Actions actions = new Actions(driver);
		actions.moveToElement(menuItem).perform();


		// Wait to observe the hover effect
		try {
		Thread.sleep(3000);
		} catch (InterruptedException e) {
		 e.printStackTrace();
		}
	


	}

}

package Test22;

import javax.lang.model.element.Element;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.w3c.dom.xpath.XPathResult;

import io.github.bonigarcia.wdm.WebDriverManager;

public class JavaScriptExecutor {

	public static void main(String[] args) throws Exception
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.toolsqa.com");
		
		JavascriptExecutor jsExecutor=(JavascriptExecutor)driver;
		
//		WebElement element=(WebElement)jsExecutor.executeScript("return document.getElementById('subscriber-email')");
//		element.sendKeys("id"); 

		
//		WebElement element=(WebElement)jsExecutor.executeScript("return document.querySelector('#subscriber-email')");
//		element.sendKeys("css"); 
//		
//		WebElement element = (WebElement) jsExecutor.executeScript(
//			    "return document.evaluate(\"//input[@id='subscriber-email']\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;"
//			);
//			element.sendKeys("css");
//
//			jsExecutor.executeScript("document.getElementById('subscriber-email').value='JAVA';");
//			Thread.sleep(3000);
//
//			jsExecutor.executeScript("var el = document.getElementsByName('subscriber-email')[0]; if (el) el.value = 'name';");
//			Thread.sleep(3000);
//
//			jsExecutor.executeScript("var el = document.getElementsByClassName('subscriber_email')[0]; if (el) el.value = 'classname';");
//			Thread.sleep(3000);
//
//			jsExecutor.executeScript("var el = document.getElementsByTagName('input')[0]; if (el) el.value = 'classname';");
//			Thread.sleep(3000);
//
//			jsExecutor.executeScript("document.querySelector('#subscriber-email').value='css';");
//			Thread.sleep(3000);
//			
//			jsExecutor.executeScript("document.evaluate(\"//input[@id='subscriber-email']\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;"
//				);
//			Thread.sleep(3000);
//
			jsExecutor.executeScript("document.getElementsByName('login')[0].click()");
			
			//scroll operations
			//scroll/scrollto
			//scrollBy
			//scrollintoview
			//h y r tutorial
			jsExecutor.executeScript("window.scrollTo(0,500)");
			Thread.sleep(3000);
			jsExecutor.executeScript("window.scrollBy(0,500)");
			//need to take screenshot
			jsExecutor.executeScript("document.getElementById('ty_footer').scrollIntoView();");
			
			
			
			

	}

}

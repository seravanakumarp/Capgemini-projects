package Test22;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestExplicitWait {

	public static void main(String[] args) throws Exception
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.saucedemo.com");
		driver.manage().window().maximize();
		
		WebElement username=driver.findElement(By.id("user-name"));
		username.sendKeys("standard_user");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("secret_sauce");
		
		//click login
		
		WebElement login_btn=driver.findElement(By.id("login-button"));
		login_btn.click();
		
		//click on hamburger menu
		WebElement hamburger_icon=driver.findElement(By.id("react-burger-menu-btn"));
		hamburger_icon.click();
		
		//Thread.sleep(3000);
		
		WebDriverWait obj=new WebDriverWait(driver,Duration.ofSeconds(10));
		obj.until(ExpectedConditions.visibilityOfElementLocated(By.id("logout_sidebar_link")));
		//click on Logout
		
		WebElement logout=driver.findElement(By.id("logout_sidebar_link"));
		logout.click();
		
	}

}

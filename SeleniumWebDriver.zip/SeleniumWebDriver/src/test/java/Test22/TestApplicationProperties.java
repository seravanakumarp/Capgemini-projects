package Test22;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestApplicationProperties {

	public static void main(String[] args) 
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.seleniumhq.org");
		
		
		//URL
		String currentURL=driver.getCurrentUrl();
		System.out.println("Current URL:"+currentURL);
		
		
		//Title
		String title=driver.getTitle();
		System.out.println("Title:"+title);
		
		//Page Source
		String pagesource=driver.getPageSource();
		System.out.println("page Source:"+pagesource);
		
		
		driver.quit();
		
	}

}

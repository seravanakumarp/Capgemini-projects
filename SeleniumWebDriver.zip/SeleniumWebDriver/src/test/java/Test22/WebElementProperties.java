package Test22;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebElementProperties {

	public static void main(String[] args) throws Exception
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		//how to get Tagname,HTML attribute value,text,css value using Selenium webdriver
		
		driver.get("https://www.github.com/login");
		//tagname
		System.out.println(driver.findElement(By.name("commit")).getTagName());
		
		//attribute value
		System.out.println(driver.findElement(By.name("commit")).getAttribute("type"));
		
		
		WebElement usernameTxt=driver.findElement(By.id("login_field"));
		usernameTxt.sendKeys("test@gmail.com");
		Thread.sleep(2000);
		
		//text box text in console
		
		System.out.println(usernameTxt.getAttribute("value"));
		
		System.out.println(driver.findElement(By.xpath("//input[@id='login_field']/preceding-sibling::label")).getText());
		Thread.sleep(2000);
		
		//background color: CSS value
		
		System.out.println(driver.findElement(By.name("commit")).getCssValue("background-color"));
		//driver.quit();
		Thread.sleep(2000);
	}

}

package Test22;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

// Navigation Methods in Selenium WebDriver
public class NavigationMethods {

	public static void main(String[] args) throws Exception
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.google.com/");
		Thread.sleep(3000);
		
		driver.findElement(By.name("q")).sendKeys("Welcome to Java");
		driver.findElement(By.name("q")).submit();
		
		//Navigation methods: navigate interface methods: to(),refresh(),back(),forward()
		Thread.sleep(3000);
		
		driver.navigate().to("https://www.udemy.com/join/passwordless-auth/?srsltid=AfmBOoovZrs3HxHWhBnBbRKF5n6ZE3oU2pSwflXfAcChoMPGfvyiku31");
		Thread.sleep(3000);
		
		driver.findElement(By.name("email")).sendKeys("test@gmail.com");
		Thread.sleep(3000);
		
		driver.navigate().refresh();
		Thread.sleep(3000);
		
		driver.navigate().back();
		Thread.sleep(3000);
		
		driver.navigate().forward();
		Thread.sleep(3000);
		
		driver.quit();
		
	}

}

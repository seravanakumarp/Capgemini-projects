package Test22;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragAndDrop {

	public static void main(String[] args)
	{
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://crossbrowsertesting.github.io/drag-and-drop");
		
		WebElement source=driver.findElement(By.id("draggable"));
		WebElement target=driver.findElement(By.id("droppable"));
		
		Actions actions=new Actions(driver);
		
		//actions.dragAndDrop(source, target).perform();
		
		//actions.dragAndDropBy(source,100, 100).perform();
		
		//actions.clickAndHold(source).moveToElement(target).release().perform();
		
		actions.clickAndHold(source).moveByOffset(100, 100).release().perform();
		
	}

}

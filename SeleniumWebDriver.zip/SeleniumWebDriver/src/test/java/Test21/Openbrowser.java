package Test21;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Openbrowser {

	public static void main(String[] args) throws Exception
	{
		// create the chrome driver
		WebDriver driver = new ChromeDriver();
		//create the edge driver
		//WebDriver driver1=new EdgeDriver();
		// url mention
		driver.get("https://www.google.com/");
		Thread.sleep(5000);
		driver.close();
	}

}

package Test21;
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.util.List;
public class Radiobuttons {

	public static void main(String[] args) 
	{
		
		        WebDriver driver = new ChromeDriver();

		        try {
		            // Load local HTML file
		            File file = new File("C:/Users/sekumarp/Documents/Finishing School Selenium/DAY1/Radiobuttons.html");
		            driver.get("file:///" + file.getAbsolutePath());

		            // Find all radio buttons
		            List<WebElement> radioButtons = driver.findElements(By.xpath("//input[@type='radio']"));

		            // Print details of each radio button
		            for (WebElement radio : radioButtons) {
		                System.out.println("Radio Button: value=" + radio.getAttribute("value") +
		                                   ", selected=" + radio.isSelected());
		            }

		        } catch (Exception e) {
		            e.printStackTrace();
		        } finally {
		            driver.quit();
		        }
	
	}

}

package Test21;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Xpathdemo {

	public static void main(String[] args) throws Exception
	{
	
		        // Initialize WebDriver
		        WebDriver driver = new ChromeDriver();

		        // Navigate to the login page
		        driver.get("https://practicetestautomation.com/practice-test-login/");

		        // Maximize the browser window
		        driver.manage().window().maximize();

		        // Locate elements using XPath and interact with them

		        // 1. Username field
		        WebElement username = driver.findElement(By.xpath("//input[@id='username']"));
		        username.sendKeys("student");

		        // 2. Password field
		        WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
		        password.sendKeys("Password123");

		        // 3. Submit button
		        WebElement submitButton = driver.findElement(By.xpath("//button[@id='submit']"));
		        submitButton.click();

		        // Optional: Add a wait or validation step here
		        	Thread.sleep(4000);
		        // Close the browser
		        driver.quit();
		

	}

}

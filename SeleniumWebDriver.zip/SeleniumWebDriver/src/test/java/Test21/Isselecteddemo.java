package Test21;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Isselecteddemo {

	public static void main(String[] args)
	{
		WebDriver driver = new ChromeDriver();
		driver.get("http://test.rubywatir.com/radios.php/");
		
		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div/div[2]/p/input[1]"))
		.click();
		
		boolean logo = driver.findElement(By.xpath("//*[@id=\"content\"]/div/div/div[2]/p/input[1]"))
		.isSelected();
		if (logo == true) {
		System.out.println("button is selected");
		} else {
		System.out.println("not selected");
		}
	}

}

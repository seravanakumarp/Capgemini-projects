package Test21;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

/*
 *   Test Case
 *   
 *   1. Launch Browser(chrome)
 *   2. Open URL: https://the-internet.herokuapp.com/dynamic_loading
 *   3. Validate titles should be "The Internet"
 *   4. Close Browser
 */

public class FirstTestCase {

	public static void main(String[] args) throws Exception
	{
		//1. Launch Browser(chrome)
		
		WebDriver driver=new ChromeDriver();
		//WebDriver driver=new EdgeDriver();
		//WebDriver driver=new FireFoxDriver();
		
		 //2. Open URL: https://demo.opencart.com/
		
		driver.get("https://the-internet.herokuapp.com/dynamic_loading");
		
		 //3. Validate titles should be "The Internet"

		String act_title=driver.getTitle();
		
		if(act_title.equals("The Internet"))
			System.out.println("test pass");
		else
			System.out.println("test fail");
		
		//4. To get the title of current web page
		String title = driver.getTitle();
		System.out.println("Title: "+title);

		//5.To get the url of current web page
		String url = driver.getCurrentUrl();
		System.out.println("URL: "+url);

		
		//6. Close Browser
		
		//driver.close();
		Thread.sleep(10000);
		driver.quit();
	
	}

}

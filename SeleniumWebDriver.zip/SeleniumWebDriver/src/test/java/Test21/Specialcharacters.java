package Test21;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.File;

public class Specialcharacters {

	public static void main(String[] args) {
	

		        WebDriver driver = new ChromeDriver();

		        try {
		            // Load the local HTML file
		            File file = new File("C:/Users/sekumarp/Documents/Finishing School Selenium/DAY1/Specialcharacters.html");
		            driver.get("file:///" + file.getAbsolutePath());

		            // Locate element containing '&' using contains()
		            WebElement terms = driver.findElement(By.xpath("//*[contains(text(),'&')]"));
		            System.out.println("Found: " + terms.getText());

		            // Locate element containing non-breaking space (rendered as normal space)
		            WebElement privacy = driver.findElement(By.xpath("//*[contains(text(),'Privacy')]"));
		            System.out.println("Found: " + privacy.getText());

		        } catch (Exception e) {
		            e.printStackTrace();
		        } finally {
		            driver.quit();
		        }
		

	}

}

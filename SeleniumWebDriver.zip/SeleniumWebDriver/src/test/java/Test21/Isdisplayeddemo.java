package Test21;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Isdisplayeddemo {

	public static void main(String[] args) 
	{
		//WebDriverManager.edgedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/broken");
		
		boolean logo=driver.findElement(By.xpath("//*[@id=\"app\"]/div/div/div/div[2]/div[2]/img[1]")).isDisplayed();	
		
		if(logo==true)
		{ 
		System.out.println("logo is available");
		}
		else{
		System.out.println("logo is not available");
		}
		


	}

}

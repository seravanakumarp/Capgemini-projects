package Test21;

import java.awt.Dimension;
import java.awt.Point;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class CookiesWindowMaximize {

	public static void main(String[] args) throws Exception
	{
		//To open the browser
		
		WebDriver driver = new ChromeDriver();
		Thread.sleep(2000);
		
		//To delete cookies
		driver.manage().deleteAllCookies();
		
		
		//To set the size of the window
		ChromeOptions options = new ChromeOptions();
		options.addArguments("window-size=500,500");
		WebDriver driver1 = new ChromeDriver(options);

		Thread.sleep(2000);
		
		
		//To set the position of the window

		ChromeOptions options1= new ChromeOptions();
		options.addArguments("window-position=250,250");
		WebDriver driver2 = new ChromeDriver(options1);

		Thread.sleep(2000);
		//To maximize the window
		driver.manage().window().maximize();
	}

}

package Test21;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Printselectedvalue {

	public static void main(String[] args) 
	{
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://demoqa.com/automation-practice-form");
		List<WebElement> w = driver.findElements(By.xpath("//input[@type='checkbox']"));
		
		for (int i = 0; i < w.size(); i++) {
			if (w.get(i).getAttribute("value").equals("Sports")
			|| w.get(i).getAttribute("value").equals("Music")) {
			w.get(i).click();
			}
			if (w.get(i).isSelected()) {
			System.out.println(w.get(i).getAttribute("value"));
			}
			
		}

	}

}

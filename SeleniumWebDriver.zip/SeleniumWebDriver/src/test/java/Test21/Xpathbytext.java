package Test21;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Xpathbytext {

	public static void main(String[] args) throws Exception
	{
		

		
		        WebDriver driver = new ChromeDriver();

		        try {
		            // Open a sample webpage
		            driver.get("https://www.example.com");
		            Thread.sleep(3000);

		            // XPath using exact text match
		            WebElement element = driver.findElement(By.xpath("//h1[text()='Example Domain']"));
		            Thread.sleep(3000);

		            // Print the text of the matched element
		            System.out.println("Found element text: " + element.getText());

		        } catch (Exception e) {
		            e.printStackTrace();
		        } finally {
		            driver.quit();
		        }
	

	}

}

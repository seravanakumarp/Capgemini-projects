package Test21;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Navigationcommands {

	public static void main(String[] args) throws Exception
	{
		//open the browser
	
		WebDriver driver = new ChromeDriver();
		
		//To maximize the window
		driver.manage().window().maximize();
		
		
		//To delete the cookies
		driver.manage().deleteAllCookies();
		driver.get("https://www.google.com/");

		//To enter the url
		driver.navigate().to("https://www.toolsqa.com/");
		Thread.sleep(3000);
		
		//To navigate to previous page
		driver.navigate().back();
		Thread.sleep(3000);
		
		//To navigate to next page
		driver.navigate().forward();
		Thread.sleep(3000);
		
		//Refresh current web page
		driver.navigate().refresh();

	}

}

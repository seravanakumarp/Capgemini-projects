package Day3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Autosuggestions {

	public static void main(String[] args) throws Exception
	{
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		
		driver.manage().window().maximize();
		driver.findElement(By.name("q")).sendKeys("selenium");
		Thread.sleep(2000);

		// To get address of all the suggestions
		String xp = "//span[contains(text(),'selenium')]";
		List<WebElement> allSuggestions = driver.findElements(By.xpath(xp));
		
		// To count number of suggestions
		int count = allSuggestions.size();
		System.out.println(count);
		
		// To print all the suggestions
		for (int i = 0; i < count; i++) {
		WebElement suggestion = allSuggestions.get(i);
		String text = suggestion.getText();
		System.out.println(text);
		}

		// To click on last suggestion
		allSuggestions.get(count - 1).click();
		
		
	}

}

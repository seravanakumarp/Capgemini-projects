package Day3.Webtable;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Particulardata {

	public static void main(String[] args) 
	{
		WebDriver driver = new ChromeDriver();
		driver.get("https://practice.expandtesting.com/tables");

		List<WebElement> tRows = driver.findElements(By.tagName("tr"));

		for (WebElement row : tRows) {
		    List<WebElement> tData = row.findElements(By.tagName("td"));
		    for (WebElement cell : tData) {
		        if (cell.getText().equals("Tim")) {
		            System.out.println(cell.getText());
		        }
		    }
		}

	}

}

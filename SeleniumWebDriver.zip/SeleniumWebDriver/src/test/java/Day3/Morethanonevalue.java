package Day3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Morethanonevalue {

	public static void main(String[] args) 
	{
		
		        WebDriver driver = new ChromeDriver();
		        driver.get("https://demoqa.com/automation-practice-form/");

		        // Select specific hobbies
		        String[] hobbiesToSelect = {"Sports", "Music","Reading"};

		        for (String hobby : hobbiesToSelect) {
		            WebElement label = driver.findElement(By.xpath("//label[text()='" + hobby + "']"));
		            label.click();
		        }

		        // Find all checkboxes under hobbies
		        List<WebElement> checkboxes = driver.findElements(By.xpath("//div[@id='hobbiesWrapper']//input[@type='checkbox']"));

		        System.out.println("Selected hobbies:");
		        for (WebElement checkbox : checkboxes) {
		            if (checkbox.isSelected()) {
		                String id = checkbox.getAttribute("id");
		                WebElement label = driver.findElement(By.xpath("//label[@for='" + id + "']"));
		                System.out.println(label.getText());
		            }
		        }

		        //driver.quit();
		 

	}

}

package Day3.JavaScriptExecutor;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pagedown {

	public static void main(String[] args) 
	{
		WebDriver driver=new ChromeDriver(); 
		driver.get("https://dhtmlx.com/docs/products/dhtmlxTree/"); 
		JavascriptExecutor j=(JavascriptExecutor) driver;
		WebElement w = driver.findElement(By.xpath("/html/body/div/div[6]/div[4]/div/div[1]/div[1]/div[3]/a"));
		w.sendKeys(Keys.PAGE_DOWN);

	}

}

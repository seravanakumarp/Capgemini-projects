package Day3.JavaScriptExecutor;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scrolldownandupupto50px {

	public static void main(String[] args) throws Exception
	{
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.seleniumhq.org/download/");
		JavascriptExecutor j = (JavascriptExecutor) driver;
		
		//To scroll down
		for (int i = 0; i < 10; i++) {
		j.executeScript("window.scrollBy(0,50)");
		Thread.sleep(500);
		}
		Thread.sleep(3000);
		//To scroll up
		for (int i = 0; i < 10; i++) {
		j.executeScript("window.scrollBy(0,-50)");
		Thread.sleep(500);
		}

	}

}

package Day3.JavaScriptExecutor;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Textboxvalueclick {

	public static void main(String[] args) 
	{
		WebDriver driver = new ChromeDriver();
		driver.get("https://github.com/login");
		// JavaScript declaration
		JavascriptExecutor js = (JavascriptExecutor) driver;

		// Set value for the input field with ID 'login_field'
		js.executeScript("document.getElementById('login_field').setAttribute('value','Hello')");

		// Get the value from the input field with ID 'email'
		Object s = js.executeScript("return document.getElementById('login_field').getAttribute('value')");
		System.out.println(s);

		// Click the button with name 'commit'
		js.executeScript("document.getElementsByName('commit')[0].click()");

	}

}

package Day3.JavaScriptExecutor;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scrolldownandupusingpixel {

	public static void main(String[] args) throws Exception
	{
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.seleniumhq.org/download/");
		JavascriptExecutor j = (JavascriptExecutor) driver;
		//To scroll down
		j.executeScript("window.scrollBy(0,500)");
		Thread.sleep(3000);
		//To scroll up
		j.executeScript("window.scrollBy(0,-500)");
	}

}

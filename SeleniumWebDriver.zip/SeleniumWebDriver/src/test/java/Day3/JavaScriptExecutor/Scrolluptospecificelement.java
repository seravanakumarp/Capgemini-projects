package Day3.JavaScriptExecutor;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Scrolluptospecificelement {

	public static void main(String[] args) throws InterruptedException
	{
		WebDriver driver=new ChromeDriver(); 
		driver.get("https://dhtmlx.com/docs/products/dhtmlxTree/"); 
		JavascriptExecutor j=(JavascriptExecutor) driver;
		
		// Locate the element up to which you want to scroll
		WebElement targetElement = driver.findElement(By.xpath("/html/body/div/div[6]/div[3]/div/div[1]/div[1]/div"));

		// Scroll to the element using JavaScript
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", targetElement);

		// Wait for the scroll to complete (optional but helps with stability)
		Thread.sleep(2000);

		WebElement button = driver.findElement(By.xpath("//*[text()='View more demos']"));
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("arguments[0].click();", button);

//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		WebElement button1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='View more demos']")));
//		button1.click();

		js.executeScript("window.scrollBy(0, 200);"); // scrolls down a bit more

	}

}

package Day3.JavaScriptExecutor;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Screenshot {

	public static void main(String[] args) throws Exception
	{
		WebDriver driver = new ChromeDriver();
		driver.get("https://github.com/login");
		driver.findElement(By.id("login_field")).sendKeys("Hello");
		//screenshot declaration
		TakesScreenshot tk=(TakesScreenshot) driver;
		File source= tk.getScreenshotAs(OutputType.FILE);
		File des=new File("C:/Users/sekumarp/Documents/Finishing School Selenium/2.jpeg");
		FileUtils.copyFile(source,des);
	}

}

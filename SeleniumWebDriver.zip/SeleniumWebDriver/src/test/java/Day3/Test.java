package Day3;

public class Test {

	public static void main(String[] args) 
	{
		//addition of two numbers
		
		int a;
		int b;
		int result;
		
		System.out.println("");
		
		
		
		
		
	}

}

package Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SVGExample {

	public static void main(String[] args)
	{
	
		        // Initialize the ChromeDriver
		        WebDriver driver = new ChromeDriver();

		        // Navigate to the web page containing the notification container
		        driver.get("https://www.geeksforgeeks.org/");

		        // Maximize the browser window
		        driver.manage().window().maximize();

		        try {
		            // Locate the SVG element using XPath
		        	WebElement svgElement = driver.findElement(By.xpath("//div[@class='notification_container']"));

		        	// Click on the SVG element
		            svgElement.click();

		            System.out.println("SVG element clicked successfully.");
		        } catch (Exception e) {
		            System.out.println("An error occurred: " + e.getMessage());
		        } finally {
		            // Close the browser
		          //  driver.quit();
		        }
		    }
	
	

	

}

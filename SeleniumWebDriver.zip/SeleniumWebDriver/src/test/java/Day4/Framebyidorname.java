package Day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Framebyidorname {

	public static void main(String[] args) throws InterruptedException
	{
		
		        WebDriver driver = new ChromeDriver();
		        try {
		            driver.get("https://demo.automationtesting.in/Frames.html");

		            // Example: Assume the iframe has id="singleframe"
		            driver.switchTo().frame("singleframe"); // You can use id or name here
		            Thread.sleep(3000);

		            driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Hello iframe by ID/Name");
		            Thread.sleep(3000);

		            // Switch back to the main content
		            driver.switchTo().defaultContent();
		        } finally {
		            //driver.quit();
		        }
		
	}

}

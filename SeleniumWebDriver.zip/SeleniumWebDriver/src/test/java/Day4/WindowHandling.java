package Day4;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowHandling {

	public static void main(String[] args) throws InterruptedException
	{
		
		        WebDriver driver = new ChromeDriver();

		        try {
		            driver.get("https://demo.guru99.com/popup.php");

		            // Click the link to open a new window
		            driver.findElement(By.linkText("Click Here")).click();

		            // Store the parent window id
		            String parentWindowId = driver.getWindowHandle();
		            System.out.println("Parent Window ID: " + parentWindowId);

		            // Get all window handles
		            Set<String> allWindowIds = driver.getWindowHandles();

		            // Loop through all windows
		            for (String windowId : allWindowIds) {
		                if (!parentWindowId.equals(windowId)) {
		                    System.out.println("Child Window ID: " + windowId);
		                    // Switch to child window
		                    driver.switchTo().window(windowId);
		                    Thread.sleep(2000);

		                    // Enter email and submit (demo action)
		                    driver.findElement(By.name("emailid")).sendKeys("test@example.com");
		                    driver.findElement(By.name("btnLogin")).click();
		                    Thread.sleep(2000);

		                    // Close the child window
		                    driver.close();
		                }
		            }

		            // Switch back to parent window
		            driver.switchTo().window(parentWindowId);
		            System.out.println("Switched back to parent window.");
		            Thread.sleep(2000);

		        } finally {
		          //  driver.quit();
		        }
	

	}

}

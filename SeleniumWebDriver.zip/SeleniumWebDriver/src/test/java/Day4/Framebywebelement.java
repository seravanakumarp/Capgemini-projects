package Day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Framebywebelement {

	public static void main(String[] args) throws InterruptedException
	{
	
		        WebDriver driver = new ChromeDriver();
		        try {
		            driver.get("https://demo.automationtesting.in/Frames.html");

		            // Locate the iframe as a WebElement (using id, xpath, or any other locator)
		            WebElement iframe = driver.findElement(By.id("singleframe"));
		            Thread.sleep(3000);
		            // Switch to the iframe using the WebElement
		            driver.switchTo().frame(iframe);
		            Thread.sleep(3000);
		            
		            // Interact with elements inside the iframe
		            driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Switched by WebElement!");

		            // Switch back to the main content
		            driver.switchTo().defaultContent();
		        } 
		        finally {
		            //driver.quit();
		        }
		   
	}

}

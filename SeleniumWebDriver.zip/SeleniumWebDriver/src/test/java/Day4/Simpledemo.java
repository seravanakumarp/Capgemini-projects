package Day4;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Simpledemo {

	public static void main(String[] args) 
	{
		
		        // Set up ChromeDriver (ensure chromedriver is in your PATH)
		        WebDriver driver = new ChromeDriver();

		        try {
		            // Open a demo page with an alert (replace with your page if needed)
		            driver.get("https://demo.guru99.com/test/delete_customer.php");

		            // Enter a value, then click submit to trigger alert
		            driver.findElement(By.name("cusid")).sendKeys("12345");
		            driver.findElement(By.name("submit")).click();

		            // Switch to alert and print its text
		            Alert alert = driver.switchTo().alert();
		            System.out.println("Alert text is: " + alert.getText());

		            // Accept the alert (click OK)
		            alert.accept();

		            // Optionally, handle the next alert if any
		            // Alert alert2 = driver.switchTo().alert();
		            // alert2.accept();

		        } finally {
		            // Close the browser after a short pause
		            try { Thread.sleep(2000); } catch (InterruptedException e) {}
		            //driver.quit();
		        }
		
	}

}

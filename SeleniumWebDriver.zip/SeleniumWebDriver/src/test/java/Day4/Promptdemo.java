package Day4;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Promptdemo {

	public static void main(String[] args) throws InterruptedException
	{
		
		        WebDriver driver = new ChromeDriver();

		        try {
		            // Open a demo page with prompt alert
		            driver.get("https://the-internet.herokuapp.com/javascript_alerts");

		            // Click the button to trigger the prompt alert
		            driver.findElement(By.xpath("//button[text()='Click for JS Prompt']")).click();

		            // Switch to the prompt alert
		            Alert alert = driver.switchTo().alert();

		            // Print alert text
		            System.out.println("Alert text is: " + alert.getText());

		            // Send text to the prompt alert
		            alert.sendKeys("yes");
		            
		       

		            // Wait for 3 seconds
		            Thread.sleep(3000);
		            
		      

		            // Dismiss the alert (click Cancel)
		            alert.accept();

		            // (Optional) Get the result message from the page
		            String result = driver.findElement(By.id("result")).getText();
		            System.out.println("Result after dismiss: " + result);

		        } finally {
		            driver.quit();
		        }
		 

	}

}

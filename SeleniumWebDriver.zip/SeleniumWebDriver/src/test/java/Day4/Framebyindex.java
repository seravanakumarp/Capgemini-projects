package Day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Framebyindex {

	public static void main(String[] args) throws InterruptedException
	{
		
		        // Set up ChromeDriver (make sure chromedriver is in your PATH)
		        WebDriver driver = new ChromeDriver();

		        try {
		            // Open a demo page with an iframe
		            driver.get("https://demo.automationtesting.in/Frames.html");

		            // Click "Single Iframe" tab if not selected (optional)
		            driver.findElement(By.xpath("//a[contains(text(),'Single Iframe')]")).click();
		            Thread.sleep(3000);

		            // Switch to the iframe by index or by xpath
		            driver.switchTo().frame(0);
		            Thread.sleep(2000);

		            // Enter text in the input field inside the iframe
		            driver.findElement(By.xpath("//input[@type='text']")).sendKeys("vengat");
		            Thread.sleep(2000);

		            // Switch back to the main content
		            driver.switchTo().defaultContent();

		        } 
		        finally {
		          //  driver.quit();
		        }
		 
	}

}

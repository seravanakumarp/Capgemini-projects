package Day4;

import java.net.HttpURLConnection;
import java.net.URL;

public class Brokenlinks1 {

	public static void main(String[] args) throws Exception
	{
		URL url = new URL("http://www.google.com");
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		int code = con.getResponseCode(); //if code is 200, then link is not broken
		System.out.println(code);
		String msg = con.getResponseMessage(); //if msg is Ok, then link is not broken
		System.out.println(msg);

	}

}

package Day4;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Confirmdemo {

	public static void main(String[] args) throws InterruptedException
	{
		
		        WebDriver driver = new ChromeDriver();

		      
		                try {
		                    driver.get("https://the-internet.herokuapp.com/javascript_alerts");

		                    // Click the button to trigger the confirm alert
		                    driver.findElement(By.xpath("//button[text()='Click for JS Confirm']")).click();

		                    // Switch to the alert
		                    Alert alert = driver.switchTo().alert();

		                    // Print alert text
		                    System.out.println("Alert text is: " + alert.getText());
		                    Thread.sleep(3000);

		                    // Dismiss the alert ("Cancel")
		                    alert.dismiss();

		                    // (Optional) Verify the result message on the page
		                    String result = driver.findElement(By.id("result")).getText();
		                    System.out.println("Result after dismissing alert: " + result);

		                } finally {
		                    //driver.quit();
		                }
		     
	}

}

package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class NopCommerceRegistrationPage {

    WebDriver driver;

    public NopCommerceRegistrationPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locators
    By genderMale = By.id("gender-male");
    By firstName = By.id("FirstName");
    By lastName = By.id("LastName");
    By email = By.id("Email");
    By password = By.id("Password");
    By confirmPassword = By.id("ConfirmPassword");
    By registerButton = By.id("register-button");
    By successMessage = By.cssSelector(".result");

    // Actions
    public void selectGenderMale() {
        driver.findElement(genderMale).click();
    }

    public void enterFirstName(String fname) {
        driver.findElement(firstName).sendKeys(fname);
    }

    public void enterLastName(String lname) {
        driver.findElement(lastName).sendKeys(lname);
    }

    public void enterEmail(String emailAddress) {
        driver.findElement(email).sendKeys(emailAddress);
    }

    public void enterPassword(String pwd) {
        driver.findElement(password).sendKeys(pwd);
        driver.findElement(confirmPassword).sendKeys(pwd);
    }

    public void clickRegisterButton() {
        driver.findElement(registerButton).click();
    }

    public boolean isRegistrationSuccess() {
        return driver.findElement(successMessage).isDisplayed();
    }
}

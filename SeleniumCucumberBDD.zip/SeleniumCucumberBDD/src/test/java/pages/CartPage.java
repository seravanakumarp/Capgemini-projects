package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class CartPage {

    WebDriver driver;
    WebDriverWait wait;

    // Locators
    By cartLink = By.cssSelector(".ico-cart");
    By cartItems = By.cssSelector("table.cart tbody tr"); // Updated selector

    public CartPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // Open the cart and wait for the items to load
    public void openCart() {
        driver.findElement(cartLink).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(cartItems));
    }

    // Check if at least one product exists in the cart
    public boolean isProductInCart() {
        return driver.findElements(cartItems).size() > 0;
    }
}

package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SearchPage {

    WebDriver driver;

    public SearchPage(WebDriver driver) {
        this.driver = driver;
    }

    By firstProductLink = By.cssSelector(".product-title a");

    public void selectFirstProduct() {
        driver.findElement(firstProductLink).click();
    }
}

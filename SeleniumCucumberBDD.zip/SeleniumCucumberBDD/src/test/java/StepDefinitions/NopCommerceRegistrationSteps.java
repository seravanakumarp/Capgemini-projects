package StepDefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.NopCommerceRegistrationPage;

public class NopCommerceRegistrationSteps {

//    WebDriver driver;
//    NopCommerceRegistrationPage registrationPage;
//
//    @Given("User is on the NopCommerce registration page")
//    public void user_is_on_the_nopcommerce_registration_page() {
//        driver = new ChromeDriver();
//        driver.get("https://demo.nopcommerce.com/register");
//        registrationPage = new NopCommerceRegistrationPage(driver);
//    }
//
//    @When("User enters valid registration details")
//    public void user_enters_valid_registration_details() {
//        registrationPage.selectGenderMale();
//        registrationPage.enterFirstName("John");
//        registrationPage.enterLastName("Doe");
//        registrationPage.enterEmail("john" + System.currentTimeMillis() + "@test.com");
//        registrationPage.enterPassword("Password123");
//    }
//
//    @When("User clicks on the register button")
//    public void user_clicks_on_the_register_button() {
//        registrationPage.clickRegisterButton();
//    }
//
//    @Then("User should see the registration success message")
//    public void user_should_see_the_registration_success_message() {
//        if (!registrationPage.isRegistrationSuccess()) {
//            throw new AssertionError("Registration failed!");
//        }
//        driver.quit();
//    }
}

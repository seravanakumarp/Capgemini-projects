package StepDefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.CartPage;
import pages.HomePage;
import pages.ProductPage;
import pages.SearchPage;

public class ShoppingSteps {

    WebDriver driver;
    HomePage homePage;
    SearchPage searchPage;
    ProductPage productPage;
    CartPage cartPage;

    @Given("User is on the nopCommerce homepage")
    public void user_is_on_the_nopcommerce_homepage() {
        driver = new ChromeDriver();
        driver.get("https://demo.nopcommerce.com/");
        homePage = new HomePage(driver);
        searchPage = new SearchPage(driver);
        productPage = new ProductPage(driver);
        cartPage = new CartPage(driver);
    }

    @When("User searches for {string}")
    public void user_searches_for(String productName) {
        homePage.searchProduct(productName);
    }

    @When("User selects the product from search results")
    public void user_selects_the_product_from_search_results() {
        searchPage.selectFirstProduct();
    }

    @When("User adds the product to the cart")
    public void user_adds_the_product_to_the_cart() {
        productPage.addToCart();
    }

    @Then("Product should be visible in the shopping cart")
    public void product_should_be_visible_in_the_shopping_cart() {
        cartPage.openCart();
        if (!cartPage.isProductInCart()) {
            throw new AssertionError("Cart is empty!");
        }
        driver.quit();
    }
}

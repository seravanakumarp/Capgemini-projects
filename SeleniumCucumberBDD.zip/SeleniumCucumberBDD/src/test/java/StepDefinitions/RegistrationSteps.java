package StepDefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pagefactory.RegistrationPage;

public class RegistrationSteps {

    WebDriver driver;
    RegistrationPage registrationPage;

    @Given("User is on the nopCommerce registration page")
    public void user_is_on_registration_page() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://demo.nopcommerce.com/register");
        registrationPage = new RegistrationPage(driver);
    }

    @When("User enters valid registration details")
    public void user_enters_registration_details() {
        registrationPage.selectGenderMale();
        registrationPage.enterFirstName("John");
        registrationPage.enterLastName("Doe");
        registrationPage.enterEmail("john" + System.currentTimeMillis() + "@test.com");
        registrationPage.enterPassword("Password123");
    }

    @When("User clicks on the register button")
    public void user_clicks_register() {
        registrationPage.clickRegister();
    }

    @Then("User should see the registration success message")
    public void user_sees_success_message() {
        if (!registrationPage.isRegistrationSuccessful()) {
            throw new AssertionError("Registration failed!");
        }
        driver.quit();
    }
}

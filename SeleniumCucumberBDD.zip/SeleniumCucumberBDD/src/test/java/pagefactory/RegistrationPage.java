package pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPage {

    WebDriver driver;

    public RegistrationPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // PageFactory locators
    @FindBy(id = "gender-male")
    WebElement genderMale;

    @FindBy(id = "FirstName")
    WebElement firstNameField;

    @FindBy(id = "LastName")
    WebElement lastNameField;

    @FindBy(id = "Email")
    WebElement emailField;

    @FindBy(id = "Password")
    WebElement passwordField;

    @FindBy(id = "ConfirmPassword")
    WebElement confirmPasswordField;

    @FindBy(id = "register-button")
    WebElement registerButton;

    @FindBy(css = ".result")
    WebElement successMessage;

    // Page actions
    public void selectGenderMale() {
        genderMale.click();
    }

    public void enterFirstName(String fname) {
        firstNameField.sendKeys(fname);
    }

    public void enterLastName(String lname) {
        lastNameField.sendKeys(lname);
    }

    public void enterEmail(String email) {
        emailField.sendKeys(email);
    }

    public void enterPassword(String pwd) {
        passwordField.sendKeys(pwd);
        confirmPasswordField.sendKeys(pwd);
    }

    public void clickRegister() {
        registerButton.click();
    }

    public boolean isRegistrationSuccessful() {
        return successMessage.isDisplayed();
    }
}

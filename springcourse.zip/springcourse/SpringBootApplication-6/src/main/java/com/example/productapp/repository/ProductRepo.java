package com.example.productapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.productapp.model.Product;

public interface ProductRepo extends JpaRepository<Product, Long> {
}

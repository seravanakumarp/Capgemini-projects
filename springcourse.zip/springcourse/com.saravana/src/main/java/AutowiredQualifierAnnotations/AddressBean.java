package AutowiredQualifierAnnotations;

public class AddressBean 
{
	private int hno;
	private String citName;
	private String stateName;
	//PDC+PPC+toString();
	public AddressBean() {
		super();
	}
	
	public int getHno() {
		return hno;
	}

	public void setHno(int hno) {
		this.hno = hno;
	}

	public String getCitName() {
		return citName;
	}

	public void setCitName(String citName) {
		this.citName = citName;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	@Override
	public String toString() {
		return "AddressBean [hno=" + hno + ", citName=" + citName + ", stateName=" + stateName + "]";
	}

}

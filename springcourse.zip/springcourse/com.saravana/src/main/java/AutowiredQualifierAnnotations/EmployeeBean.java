package AutowiredQualifierAnnotations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class EmployeeBean 
{
	private int eid;
	private String ename;
	private double salary;
	//DI in the form Object 
	
	@Autowired
	@Qualifier("tempraryAddress")
	private AddressBean addr;
	//PDC+PPC+BM
	public EmployeeBean() {
		super();
	}
	
	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public AddressBean getAddr() {
		return addr;
	}
	//@Autowired
	public void setAddr(AddressBean addr) {
		this.addr = addr;
	}

	public void printEmployee()
	{
		System.out.println(eid+"\t"+ename+"\t"+salary);
		System.out.println(addr);
	}

}

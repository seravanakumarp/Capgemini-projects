package AutowiredQualifierAnnotations;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class App3 {

	public static void main(String[] args) 
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("spconfig3.xml");
		EmployeeBean e1=(EmployeeBean)ctx.getBean("id2");
		e1.printEmployee();

	}

}

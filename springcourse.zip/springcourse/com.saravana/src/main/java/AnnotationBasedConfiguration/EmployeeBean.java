package AnnotationBasedConfiguration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("id2")
@Scope("prototype")
public class EmployeeBean 
{
	private int id;
	private String name;
	
	public EmployeeBean() {
		System.out.println("EmployeeBean.EmployeeBean()");
	}
	@Value("120")
	public void setId(int id) {
		this.id = id;
	}

	
	@Value("Saravana")
	public void setName(String name) {
		this.name = name;
	}
	public void printEmployee() {
		System.out.println(id+"\t"+name);
	}

}

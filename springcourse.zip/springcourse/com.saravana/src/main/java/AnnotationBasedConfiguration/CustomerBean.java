package AnnotationBasedConfiguration;

import org.springframework.stereotype.Component;

@Component("id1")
public class CustomerBean 
{

	public CustomerBean()
	{
		System.out.println("CutomerBean.CutomerBean()");
	}

}

package AnnotationBasedConfiguration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("AnnotationBasedConfiguration")
public class App5 {

	public static void main(String[] args) 
	{
		System.out.println("HELLO MAIN CLASS WELCOME");
		ApplicationContext ctx=new AnnotationConfigApplicationContext(App5.class);
		CustomerBean CB1=(CustomerBean)ctx.getBean("id1");
		EmployeeBean eb1=(EmployeeBean)ctx.getBean("id2");
		EmployeeBean eb2=(EmployeeBean)ctx.getBean("id2");
		EmployeeBean eb3=(EmployeeBean)ctx.getBean("id2");
		System.out.println(eb1);
		System.out.println(eb2);
		System.out.println(eb3);
		eb1.printEmployee();

	}

}

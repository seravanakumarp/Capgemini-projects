package JavaBasedConfiguration;

public class ProductBean 
{
	private int pid;
	private String pname;
	private double price;
	private int quantity;
	//PDC+PSM+PGM+BM
	public ProductBean() {
		super();
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public void printInvoice()
	{
		System.out.println(pid+"\t"+pname+"\t"+price+"\t"+quantity);
		double total=0.0,discount=0.0;
		total=price*quantity;
		if(total<5000)
		{
			discount=(total*15)/100;
		}
		else if(total>=5000)
		{
			discount=(total*23)/100;
		}
		double invoice=total-discount;
		System.out.println(total+"\t"+discount);
		System.out.println(invoice);
	}

}

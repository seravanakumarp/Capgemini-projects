package JavaBasedConfiguration;

import java.util.Scanner;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig 
{
	@Bean("id1")
	public ProductBean getProductBean()
	{
		ProductBean p1=new ProductBean();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter pid,pnamenprice and Quantity values");
		int pid=sc.nextInt();
		String pname=sc.next();
		double price=sc.nextDouble();
		int quantity=sc.nextInt();
		p1.setPid(pid);
		p1.setPname(pname);
		p1.setPrice(price);
		p1.setQuantity(quantity);
		return p1;
	}

}

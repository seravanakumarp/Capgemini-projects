package JavaBasedConfiguration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App4 {

	public static void main(String[] args)
	{
		ApplicationContext ctx=new AnnotationConfigApplicationContext(JavaConfig.class);
		ProductBean pb=(ProductBean)ctx.getBean("id1");
		pb.printInvoice();


	}

}

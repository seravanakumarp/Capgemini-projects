package SetterInjection;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class CollegeBean 
{
	private List<String> studentNames;
	private Set<Integer> studentRollNos;
	private Map<String,Integer> branchDetails;
	private Properties branchInfos;
	//PDC+PSM+PGM+BM 
	public CollegeBean() {
		super();
	}
	public List<String> getStudentNames() {
		return studentNames;
	}
	public void setStudentNames(List<String> studentNames) {
		this.studentNames = studentNames;
	}
	public Set<Integer> getStudentRollNos() {
		return studentRollNos;
	}
	public void setStudentRollNos(Set<Integer> studentRollNos) {
		this.studentRollNos = studentRollNos;
	}
	public Map<String, Integer> getBranchDetails() {
		return branchDetails;
	}
	public void setBranchDetails(Map<String, Integer> branchDetails) {
		this.branchDetails = branchDetails;
	}
	public Properties getBranchInfos() {
		return branchInfos;
	}
	public void setBranchInfos(Properties branchInfos) {
		this.branchInfos = branchInfos;
	}
	
	public void printStudentNames()
	{
		System.out.println("=====PRINT STUDENT NAMES=============");
		for(String studentName:studentNames)
		{
			System.out.println(studentName);
		}
	}
	public void printStudentRollNos()
	{
		System.out.println("============PRINT STUDENT ROLL NOS=========");
		for(Integer studentRollNo:studentRollNos)
		{
			System.out.println(studentRollNo);
		}
	}
public void printBranchDetails()
	{
		System.out.println("----------BRANCH DETAILS ARE------------");
		for(Map.Entry<String,Integer> entry:branchDetails.entrySet())
		{
			System.out.println(entry.getKey()+"-->"+entry.getValue());
		}
	}
	public void printBranchInfo()
	{
		System.out.println("----------BRANCH INFO ARE------------");
		Set<String> keys = branchInfos.stringPropertyNames();
	    for (String key : keys) {
	      System.out.println(key + "-->" + branchInfos.getProperty(key));
	    }
	}

}

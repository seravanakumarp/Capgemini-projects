package SetterInjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App2 {

	public static void main(String[] args) 
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("spconfig2.xml");
    	CollegeBean ex=(CollegeBean)ctx.getBean("id1");
    	ex.printStudentNames();
    	ex.printStudentRollNos();

	}

}

package ConstructorInjection;

public class EmployeeBean 
{
	private int eid;
	private String ename;
	private double salary;
	//DI in the form Object 
	private AddressBean addr;
	
	public EmployeeBean() {
		super();
	}
	public EmployeeBean(int eid, String ename, double salary, AddressBean addr) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.salary = salary;
		this.addr = addr;
	}
	public void printEmployee()
	{
		System.out.println(eid+"\t"+ename+"\t"+salary);
		System.out.println(addr);
	}

}

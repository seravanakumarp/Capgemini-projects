package ConstructorInjection;

public class AddressBean 
{
	private int hno;
	private String citName;
	private String stateName;

	public AddressBean() {
		super();
	}
	public AddressBean(int hno, String citName, String stateName) {
		super();
		this.hno = hno;
		this.citName = citName;
		this.stateName = stateName;
	}
	@Override
	public String toString() {
		return "AddressBean [hno=" + hno + ", citName=" + citName + ", stateName=" + stateName + "]";
	}

}

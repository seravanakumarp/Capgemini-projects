package com.example.bookcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication(scanBasePackages = "com.example.bookcrud")

public class BookCrudRestApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(BookCrudRestApiApplication.class, args);
    }
}

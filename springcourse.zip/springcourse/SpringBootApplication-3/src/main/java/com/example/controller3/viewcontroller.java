package com.example.controller3;



import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class viewcontroller{

    @GetMapping("/")
    public String showForm() {
        return "index";
    }

    @PostMapping("/fullname")
    public String showFullName(@RequestParam String firstName,
                               @RequestParam String lastName,
                               Model model) {
        String fullName = firstName + " " + lastName;
        model.addAttribute("fullName", fullName);
        return "result";
    }
}


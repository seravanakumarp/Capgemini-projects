

import org.testng.Assert;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class DepedentOnMethods {
    @Test
    @Parameters({"UserName", "Password"})
    public void sample1(String name, String password) {
        System.out.println("the user name is " + name);
        System.out.println("the password is " + password);
        System.out.println(Thread.currentThread().getName());
        Assert.assertTrue(true);
        //Assert.assertTrue(false);
        
    }

    @Test(dependsOnMethods = "sample1")
    @Parameters({"User", "Pass"})
    public void samp1(@Optional("velmurugan") String name, @Optional("vel2215") String pass) {
        System.out.println("Test with normal method");
        System.out.println("the second test name is " + name);
        System.out.println("the second test pass is " + pass);
        System.out.println(Thread.currentThread().getName());
    }
}

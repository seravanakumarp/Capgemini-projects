import org.testng.annotations.Test;

public class Priority 
{
	@Test(priority=-8)
	public void sample()
	{
		System.out.println("Test Method with Priority -8");
	}
	@Test(priority=10)
	public void sample1()
	{
		System.out.println("Test Method with Priority 10");
	}
	@Test(priority=10)
	public void sample2()
	{
		System.out.println("Test Method with Priority 10");
	}
	@Test
	public void sample3()
	{
		System.out.println("Test Method with Default Priority");
	}
	@Test(priority=100)
	public void sample4()
	{
		System.out.println("Test Method with Priority 100");
	}
}

import org.testng.annotations.Test;

public class Invocationcount 
{
	@Test(invocationCount = 10,enabled=true)
	public void sample()
	{
		System.out.println("Test Method with Invocation Count");
	}
	@Test
	public void sample1()
	{
		System.out.println("Test Method with Default Invocation Count");
	}
}

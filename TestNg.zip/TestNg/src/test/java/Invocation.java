import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Invocation 
{
@Test()
@Parameters({"UserName", "Password"})
public void login(String username, String password) {
	System.out.println("Logging in with username: " + username + " and password: " + password);
}
@Test()
@Parameters({"UserName", "Password"})
public void login2(String username, String password) 
{
	System.out.println("Test with normal method");
	System.out.println("Logging in with username: " + username + " and password: " + password);
}
@Test()
@Parameters({"User", "Password"})
public void login3(@Optional("velmurugan")String username, String password) 
{
	System.out.println("Test with normal method");
	System.out.println("Logging in with username: " + username + " and password: " + password);
}
}

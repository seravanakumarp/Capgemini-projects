import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Sample 
{
	@BeforeSuite
	public void sample()
	{
		System.out.println("Before Suite");
	}
	@AfterSuite
	public void sample2()
	{
		System.out.println("After Suite");
	}	
	@AfterClass	
	public void sample3()
	{
		System.out.println("After Class");
	}
	@BeforeGroups("group1")
	public void sample4()
	{
	    System.out.println("Before Groups");
	}

	@AfterMethod
	public void sample5()
	{
		System.out.println("After Method");
	}	
	@AfterTest
	public void sample6()
	{
		System.out.println("After Test");
	}	
	@BeforeClass	
	public void sample7()
	{
		System.out.println("Before Class");
	}
	@BeforeMethod	
	public void sample8()
	{
		System.out.println("Before Method");
	}
	@BeforeTest
	public void sample9()
	{
		System.out.println("Before Test");
	}	
	@Test(groups = {"group1"})
	public void sample10()
	{
	    System.out.println("Test Method");
	}

	
	
	
}

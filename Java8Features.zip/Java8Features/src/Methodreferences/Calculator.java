package Methodreferences;

public interface Calculator 
{
	void calculate(int x,int y); //abstract method

}

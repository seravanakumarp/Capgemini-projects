package Methodreferences;
import java.util.*;

class User {
    String name;

    public User(String name) {
        this.name = name;
    }

    public void print() {
        System.out.println(name);
    }
}

public class Methodarbitary {

	public static void main(String[] args) {
		// Lambda approach
        Arrays.asList(new User("sachin"), new User("kapil"))
            .forEach((user) -> user.print());

        // Method reference approach
        Arrays.asList(new User("sachin"), new User("kapil"))
            .forEach(User::print);

        // Lambda approach for string toLowerCase
        Arrays.asList("C", "JAVA", ".NET")
            .stream()
            .map(s -> s.toLowerCase())
            .forEach(System.out::println);

        // Method reference approach for string toLowerCase
        Arrays.asList("C", "JAVA", ".NET")
            .stream()
            .map(String::toLowerCase)
            .forEach(System.out::println);

	}

}

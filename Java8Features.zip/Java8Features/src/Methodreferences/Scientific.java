package Methodreferences;

public class Scientific 
{
	public static void findSum(int x,int y)
	{
		System.out.println("Sum="+(x+y));
	}
	
	public  void findProduct(int x,int y)
	{
		System.out.println("Product="+(x*y));
	}

}

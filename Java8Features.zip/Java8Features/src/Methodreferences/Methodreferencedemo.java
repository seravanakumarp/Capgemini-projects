/* Method References:


 * 
 * 1. They are used to refer methods of other classes.
 * 2. They are compact and more readable
 * 3. :: operator is used for method reference.
 * 
 * Definition: Method reference means referring to static,
 * non-static method or a constructor instead of implementing
 * abstract method using lambda expressions or anonymous classes.
 * 
 * Example: interface calculator
 * 			{
 * 				public void calculator();
 * 			} 
 * 
 * Four types of Method References:
 * 1. Reference to a static method.
 *		Ex:Containingclass::staticMethodName
 * 2. Reference to a instance method of a 
 * 	  particular object.
 * 		Ex:containingObject::instanceMethodName
 * 3. Reference to an instance method of an
 * 	  arbitrary object of a particular type.
 * 		Ex:ContainingType::methodName
 * 4. Reference to a constructor.
 * 		Ex:ClassName::new
 */

package Methodreferences;

public class Methodreferencedemo {

	public static void main(String[] args) {
		
				//reference to a static method
		
				Calculator calc=Scientific::findSum;
				calc.calculate(10,20);
				
				//reference to a instance method
				
				//Scientific sc=new Scientific();
				
				Calculator calc1=new Scientific()::findProduct;
				
				//Calculator calc1=sc::findProduct;
				calc1.calculate(5,7);
				
	}

}

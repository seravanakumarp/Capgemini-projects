package Methodreferences;
interface Shapeimpl
{
	Shape getShape(int x);
}
class Shape
{
	int x;
	public Shape(int x) //parameterized constructor
	{
		//super();
		this.x = x;
	}
	void area() //instance method
	{
		System.out.println("area:"+x*x);
	}
	
}

public class Methodreferencedemo1 {

	public static void main(String[] args)
	{
		//implementing through lambda expression
				/*Shapeimpl si=(x)->{
				return new Shape(x);
				};
				Shape shape=si.getShape(20);
				shape.area(); */
				
				//reference to a constructor
				Shapeimpl si=Shape::new;
				Shape shape=si.getShape(20);
				shape.area();
	}

}

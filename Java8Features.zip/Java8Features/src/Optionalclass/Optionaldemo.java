package Optionalclass;
import java.util.Arrays;

import java.util.Optional;
public class Optionaldemo {

	public static void main(String[] args) {
		//of, empty, ofNullable -methods for creation of optional object
		
				Customer1 customer=new Customer1(101,"john","abc@gmail.com",Arrays.asList("3846832648","648724823"));
				
				//three ways to create optional object
				
				//empty,of,ofNullable

				/*Optional<Object> emptyoptional=Optional.empty();
				System.out.println(emptyoptional);
				
				Optional<String> emailoptional=Optional.of(customer.getEmail());
				System.out.println(emailoptional);
				*/
				
				Optional<String> emailoptional2=Optional.ofNullable(customer.getEmail());
				System.out.println(emailoptional2);
				/*if(emailoptional2.isPresent())
				{
					System.out.println(emailoptional2.get());
					
				}
				
				System.out.println(emailoptional2.orElse("default@gmail.com"));
				*/
				
				//System.out.println(emailoptional2.orElseThrow(()->new IllegalArgumentException("email not present")));
				
				
				//System.out.println(emailoptional2.map(String::toUpperCase).orElseGet(()->"default email..."));
				
				
				

	}

}

//Creating an Optional with a Non-null Value:
package Optionalclass;

import java.util.Optional;

public class Example5 {

	public static void main(String[] args) 
	{
		String value = "Hello, World!";
		Optional<String> optionalValue = Optional.of(value);
		// If the value is present, print it
		optionalValue.ifPresent(System.out::println);
	}

}

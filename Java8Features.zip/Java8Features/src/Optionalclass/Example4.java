//Check the String has null value or Not:
package Optionalclass;
import java.util.*;

public class Example4 {

	public static void main(String[] args)
	{
		String value = null;
		Optional<String> optionalValue = Optional.ofNullable(value);
		System.out.println(optionalValue.isPresent());
	}

}

/*						Optional class

 * 1. it is a optional utility class available in util 
 * package.
 * 2. It helps in handling null checks and NullPointerExceptions.
 * 3. You can view optional as single-value container that
 * 	  either contains a value or does not.
 * 4. of, empty, ofNullable -methods for creation of optional object
 * 
 */
package Optionalclass;
class Customer
{
	int id;
	String name;
	Customer(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
class Example1
{
	public static void main(String args[])
	{
		Customer customer1=new Customer(101,"sachin");
		int id=customer1.getId(); // we will get data
		System.out.println(id);
		
		Customer customer2=new Customer(102,null);
		String name=customer2.getName(); //gives null
		System.out.println(name);
		
		//make uppercase
		
		name.toUpperCase(); //gives NullPointerException
	}
}

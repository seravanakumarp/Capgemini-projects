//displaying the value of string only if it is not null
package Optionalclass;
import java.util.*;
public class Example2
{
	public static void main(String[] args) 
	{
		String value="sathya";
		Optional<String> optionalValue = Optional.of(value);
		System.out.println(optionalValue.get()); 
	}

}

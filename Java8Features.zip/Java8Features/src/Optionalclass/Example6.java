//Creating an Optional with a Nullable Value:
package Optionalclass;
import java.util.*;
public class Example6 {

	public static void main(String[] args) 
	{
		String value = null;
		Optional<String> optionalValue = Optional.ofNullable(value);
		optionalValue.ifPresentOrElse(System.out::println, () -> 
		System.out.println("Default Value"));

	}

}

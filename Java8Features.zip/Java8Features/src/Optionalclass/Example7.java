//Performing an Action on the Value if Present:
package Optionalclass;
import java.util.*;
public class Example7 {

	public static void main(String[] args) 
	{
		Integer number = 42;
		Optional<Integer> optionalNumber = Optional.of(number);
		optionalNumber.ifPresent(num -> {
		 int incrementedValue = num + 10;
		 System.out.println("Incremented value: " + incrementedValue);
		});

	}

}

//Display the default value in place of String if the string value is NULL:
package Optionalclass;
import java.util.*;
public class Example3 {

	public static void main(String[] args)
	{
		String value = null;
		Optional<String> optionalValue = Optional.ofNullable(value);
		System.out.println(optionalValue.orElse("Default")); 
	}

}

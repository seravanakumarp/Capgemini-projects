//Checking if a LinkedList contains a specific value
package foreach;
import java.util.*;
public class Example6 {

	public static void main(String[] args) 
	{
		LinkedList<Integer> numbers = new LinkedList<>(Arrays.asList(11, 23, 30, 45, 92));
		int target = 45;
		numbers.forEach(n -> {
		if (n == target) {
		System.out.println("Found: " + n);
	
		}
		});

	}

}

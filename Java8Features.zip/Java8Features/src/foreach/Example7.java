//Removing all elements from a HashSet that are less than 10
package foreach;
import java.util.*;
public class Example7 {

	public static void main(String[] args) 
	{
		HashSet<Integer> numbers = new HashSet<>(Arrays.asList(1, 4, 6, 20));
		numbers.removeIf(x->x<10);
		System.out.println(numbers);
	}

}

//Removing all odd numbers from an ArrayList
package foreach;
import java.util.*;
public class Example4 
{
	public static void main(String[] args) 
	{
		ArrayList<Integer> numbers = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
		numbers.removeIf(x->x%2==1);
		System.out.println(numbers);
	}
}

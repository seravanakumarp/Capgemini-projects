package foreach;
import java.util.*;
public class Example9 {

	public static void main(String[] args) 
	{
		ArrayList<String> strings = new ArrayList<>(Arrays.asList("Java", "Oracle", "Dotnet", 
				"Java"));
				String target = "Java";
				 int count[]= {0};
				
				strings.forEach(s -> {
					
				if (s.equals(target))
				{
					count[0]++;
				}
				});
		
				System.out.println("Occurrences of"+" "+ target +":"+count[0]);
	}

}

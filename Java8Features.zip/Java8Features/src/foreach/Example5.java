//Converting all strings in a TreeSet to uppercase
package foreach;
import java.util.*;
public class Example5 
{
	public static void main(String[] args) 
	{
		TreeSet<String> set = new TreeSet<>(Arrays.asList("java", "oracle", "dotnet"));
		set.forEach(s -> {
		String upperCase = s.toUpperCase();
		System.out.println(upperCase);
		});

	}

}

package foreach;
import java.util.*;
public class IteratingList {

	public static void main(String[] args)
	{
		List<Integer> list = new ArrayList<>(Arrays.asList(10,30,20,50,40));
		list.forEach(x->System.out.println(x));
	}

}

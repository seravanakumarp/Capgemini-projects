package foreach;
import java.util.*;
public class IteratingMap 
{
	public static void main(String[] args) 
	{
		Map<Integer,String> map = new HashMap<>();
		map.put(1, "Python");
		map.put(2, "Dotnet");
		map.put(3, "Java");
		map.forEach((k, v)->System.out.println(k + " = " + v));
	}

}

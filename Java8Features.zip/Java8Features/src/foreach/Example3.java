//Checking if any string in a HashSet starts with "J"
package foreach;
import java.util.*;
public class Example3 
{
	public static void main(String args[])
	{
		HashSet<String> set = new HashSet<>(Arrays.asList("Oracle", "Python", "Java"));
		set.forEach(s -> {
		if (s.startsWith("J")) {
		System.out.println(s);
		}
		});
	}
}

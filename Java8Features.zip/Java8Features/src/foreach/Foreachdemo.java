 /*           forEach() Method




 * 1. forEach() is introduced in Java8 to iterate 
 * collections easily.
 * 2. forEach() is available in both Iterable 
 * interface and Stream interface
 * 3. forEach() is default method.
 * 		Syntax: default void forEach(Consumer<T>)
 * 4. You can pass lambda expression or method 
 * reference as argument
 * */
 
package foreach;
import java.util.*;
public class Foreachdemo {

	public static void main(String[] args)
	{
				// Iterating List
		List<Integer> rollnos=Arrays.asList(10,11,12);
		System.out.println(rollnos);
		
				//using Lambda Expressions
		rollnos.forEach(rollno->System.out.println(rollno));
		
				//using method reference
		rollnos.forEach(System.out::println);
		//shortcut of lambda expressions
		//names.forEach(name -> System.out.println(name));

		
				//Iterating Set
		Set<String> names=new HashSet<String>();
		names.add("Python");
		names.add("SQL");
		names.add("JAVA");
		names.add("SQL");
		
		System.out.println(names);
		
			//using lambda expression
		names.forEach(name->System.out.println(name));
		
			//using method reference
		names.forEach(System.out::println);
		
			// iterating Map
			
		Map<Integer,String> mapnames=new HashMap<Integer,String>();
		
		mapnames.put(1,"sachin");
		mapnames.put(2,"rahul");
		mapnames.put(3,"kapil");
		
		mapnames.forEach((key,value)->System.out.println(key+" "+value));
		
		     // iterating Map using entrySet
		
			 //The entrySet() method returns the set of key-value mappings. 
		
		mapnames.entrySet().forEach(entry->
		System.out.println(entry.getKey()+" "+entry.getValue()));
		
		
		
		
				
	}

}

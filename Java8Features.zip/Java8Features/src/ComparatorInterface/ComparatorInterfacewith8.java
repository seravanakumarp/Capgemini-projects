package ComparatorInterface;
import java.util.*;
public class ComparatorInterfacewith8 {

	public static void main(String[] args) 
	{
		ArrayList<Student> al=new ArrayList<Student>();
		int rno[]= {1,2,3,4,5};
		String nm[]= {"sachin","anil","rahul","bhanu","dravid"};
		int ages[]= {35,45,55,44,22};
		
		for(int i=0;i<rno.length;i++)
		{
			Student s=new Student();
			s.setRollno(rno[i]);
			s.setName(nm[i]);
			s.setAge(ages[i]);
			
			al.add(s);
		}
		
		Comparator<Student> cm=Comparator.comparing(Student::getName);
		Collections.sort(al,cm);
		
		for(Student s1:al)
			System.out.println(s1.getRollno()+" "+s1.getName()+" "+s1.getAge());
		
		Comparator<Student> cm1=Comparator.comparing(Student::getAge);
		Collections.sort(al,cm1);
		
		for(Student s1:al)
			System.out.println(s1.getRollno()+" "+s1.getName()+" "+s1.getAge());
		
		Comparator<Student> cm2=Comparator.comparing(Student::getRollno);
		Collections.sort(al,cm2);
		
		for(Student s1:al)
			System.out.println(s1.getRollno()+" "+s1.getName()+" "+s1.getAge());
		
		
		
		
	}

}

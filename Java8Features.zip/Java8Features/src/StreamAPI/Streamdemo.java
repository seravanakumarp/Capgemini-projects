/*                      Stream

 * 1. Stream is a flow of data.
 * 2. Stream API helps in filtering the data easily 
 * 3. Stream is not a data structure and does not hold
 * 	  any information.
 * 4. Stream will not modify the collection object.
 * 5. Stream will process the elements of an object.
 * 
 * 	Creation of Stream:
 * 		Ex: List<Integer> l=new ArrayList<Integer>();
 * 			l.add(20);
 * 			l.add(10);
 * 			l.add(40);
 * 			Stream<Integer> s=l.stream();
 * 
 * stream(): it is going to return stream of any
 * 			 collection object
 * 	
 * 	Creation of Stream for Array:
 * 
 * 		Ex: Integer a[]={3,21,5};
 * 			Stream<Integer> s=Arrays.stream(a);
 * 
 * Stream Operations:
 * 1. Intermediate operation:
 * 		a. Intermediate operations are operations that 
 * 		   transform and filter the stream 
 * 		   in some way. 
 * 		b. Intermediate operations return a 
 * 		   new stream and do not modify the 
 * 		   original stream.
 * 		Ex: map(), filter(), distinct(), sorted(),limit()
 * 
 * 2. Terminal operation:
 * 	  a. Terminal operations are operations that produce 
 * 		 a result such as printing or collecting the 
 * 		 stream into a collection or a single value.
 *	
 *		Ex: forEach(), collect(),reduce(),count()
 *
 *	map() method of Stream class:
 *
 *	1. It takes lambda expression as its only argument.
 *	2. Used to change every element in stream.
 *	3. It returns new stream object containing changed
 *	   values.
 *
 *	Ex: Map to convert all elements in array of Strings to lowercase:
 *
 *		String a[]=new String[]{"PYTHON","ORACLE,"JAVA"};
 *		Stream<String> s=Arrays.stream(a);
 *		Stream<String> ns=s.map(x->x.toLowerCase());
 *
 *	filter() method:
 *	1. filter() method returns the stream after 
 *	   filtering the data.
 *	2. it takes lambda expression and return boolean value.
 *	3. if the value is true, element entered into
 *	   resultant stream.
 *
 *	Collectors Class:
 *
 *	1. It is a final class.
 *	2. It provides methods to collect the filtered 
 *	   elements into various collections.
 *	3. We can perform operations on collected data such
 *	   as counting,reverse,sort etc.
 *
 *		
 */
//Displaying the stream information
package StreamAPI;
import java.util.*;
import java.util.stream.*;
public class Streamdemo {

	public static void main(String[] args) 
	{
		List<Integer> l=new ArrayList<Integer>(Arrays.asList(20,30,10,40,50));
		
		Stream<Integer> s=l.stream();
		
		s.forEach(x->System.out.println(x));
		
		//l.stream().forEach(x->System.out.println(x));
	}
}

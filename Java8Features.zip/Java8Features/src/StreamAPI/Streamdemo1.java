package StreamAPI;
import java.util.*;



import java.util.stream.Collectors;
public class Streamdemo1 {

	public static void main(String[] args) 
	{
		//map method
		List<String> names = Arrays.asList("Agarkar", "Rahul", "David", "Sachin");
		List<String> uppercaseNames = names.stream()
		                                   .map(String::toUpperCase)
		                                   .collect(Collectors.toList());
		System.out.println(uppercaseNames);
		
		//filter method
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		List<Integer> evenNumbers = numbers.stream()
		                                    .filter(n -> n % 2 == 0)
		                                    .collect(Collectors.toList());
		System.out.println(evenNumbers);
		
		//distinct method
		List<Integer> numbers1 = Arrays.asList(1, 2, 3, 2, 4, 3, 5, 6, 5);
		List<Integer> uniqueNumbers = numbers1.stream()
		                                     .distinct()
		                                     .collect(Collectors.toList());
		System.out.println(uniqueNumbers);
		
			// sort method
		List<String> names2= Arrays.asList("sachin", "anil", "dravid", "kumble");
		List<String> sortedNames = names2.stream()
		                                .sorted()
		                                .collect(Collectors.toList());
		System.out.println(sortedNames);
		
			// limit method
		List<Integer> numbers3 = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		numbers3.stream()
		       .filter(number -> number % 2 == 0)
		       .limit(3)
		       .forEach(number -> System.out.println(number));
		
			//collect method
		List<String> names4 = Arrays.asList("sachin", "dhoni", "anil", "kumble");
		String commaSeparatedNames = names4.stream()
		                                  .collect(Collectors.joining(","));
		System.out.println(commaSeparatedNames);
		
			//reduce method
		List<Integer> numbers5 = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		int sum = numbers5.stream()
		                 .reduce(0, (a, b) -> a + b);
		System.out.println(sum);
		
			//count method
		List<String> names6 = Arrays.asList("sachin", "Rahul", "kapil", "Dhoni");
		long count = names6.stream().count();
		System.out.println("Number of names: " + count);
		
			//parallelstreams
		
		List<Integer> numbers7 = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		int sum1 = numbers.parallelStream()
		                 .mapToInt(Integer::intValue)
		                 .sum();
		System.out.println("Sum of numbers: " + sum1);
	}

}

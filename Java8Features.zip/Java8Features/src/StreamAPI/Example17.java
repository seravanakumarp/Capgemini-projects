//Parallel stream with Array:
package StreamAPI;
import java.util.*;
public class Example17 {

	public static void main(String[] args) 
	{
		String[] names = {"Alice", "Bob", "Charlie", "David", "Eve"};
		Arrays.stream(names).parallel().forEach(System.out::println);

	}

}

package StreamAPI;
import java.util.*;

import java.util.stream.Collectors;
public class Example 
{

	public static void main(String[] args) 
	{
		List<String> l=Arrays.asList("sachin","anil","kapil");
		List<String> ll=l.stream()
				.map(String::toUpperCase)
				.collect(Collectors.toList());
		
		System.out.println(ll);
		
	}

}

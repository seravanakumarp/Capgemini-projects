/*                map() vs flatMap():






 * map():
 * 1. it processes stream of values.
 * 2. it does only mapping.
 * 3. its mapper function produces single value for
 * 	  each input value.
 * 4. it is a one-to-one mapping.
 * 5. Data transformation: stream to stream
 * Usage: Use it only when mapper function is producing single 
 * value for each input value
 * 
 * flatMap():
 * 1. it processes stream of stream of values.
 * 2. it performs mapping as well as flattening.
 * 3. its mapper function produces multiple values
 * for each input value.
 * 4. it is a one-to-many mapping.
 * 5. Data transformation: from Stream<Stream> to stream.
 * Usage: use only when mapper function is producing multiple 
 * values for each input value.
 */

package StreamAPI;
import java.util.*;

import java.util.stream.Collectors;
public class Mainclass 
{

	public static void main(String[] args)
	{
			List<Customer> customers=KartDatabase.getAll();
			
			//List<Customer> convert List<String>
			//mapping: one to one 
			//customer to customer.getEmail()
			List<String> emails=customers
					.stream()
					.map(customer->customer.getEmail())
					.collect(Collectors.toList());
			System.out.println(emails);
			
			//customer to customer.getPhonenumbers()
			//mapping: one to many
			List<List<Integer>> phonenos=customers
					.stream()
					.map(customer->customer.getPhonenumbers())
					.collect(Collectors.toList());
			System.out.println(phonenos);
			
			List<Integer> phones=customers
					.stream()
					.flatMap(customer->customer.getPhonenumbers().stream())
					.collect(Collectors.toList());
			System.out.println(phones);

			
			//
			
			
	}

}

//Filter and map a list of integers, then calculate their average:

package StreamAPI;
import java.util.*;
import java.util.stream.Collectors;

public class Example13 {

	public static void main(String[] args) 
	{
		List<Integer> numbers = Arrays.asList(3, 1, 4, 2, 12);
		double average = numbers.stream()
		 .filter(n -> n % 2 == 0)
		 .mapToInt(Integer::intValue)
		 .average()
		 .orElse(0);
		System.out.println(average);
	}

}

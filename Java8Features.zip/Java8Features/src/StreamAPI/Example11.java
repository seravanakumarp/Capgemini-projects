//Filter and map a list of strings to their lengths:
package StreamAPI;
import java.util.*;

import java.util.stream.Collectors;

public class Example11 {

	public static void main(String[] args)
	{
		List<String> words = Arrays.asList("dotnet", "java", "oracle", "python");
		List<Integer> wordLengths = words.stream()
		 .filter(s -> s.startsWith("j"))
		 .map(String::length)
		 .collect(Collectors.toList());
		System.out.println(wordLengths);
	}

}

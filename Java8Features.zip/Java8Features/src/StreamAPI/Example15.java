//Filter and map a list of strings to their uppercase versions, then sort them:

package StreamAPI;
import java.util.*;

import java.util.stream.Collectors;

public class Example15 {

	public static void main(String[] args) 
	{
		List<String> words = Arrays.asList( "python","dotnet", "java", "oracle");
		List<String> sortedUpperCaseWords = words.stream()
		 //.filter(s -> !s.isEmpty())
		 .map(String::toUpperCase)
		 .sorted()
		 .collect(Collectors.toList());
		System.out.println(sortedUpperCaseWords);
	}

}

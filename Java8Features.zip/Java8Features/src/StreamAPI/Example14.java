//Filter and map a list of strings to their lengths, then find the maximum length:

package StreamAPI;
import java.util.*;

import java.util.stream.Collectors;

public class Example14 {

	public static void main(String[] args) 
	{
		List<String> words = Arrays.asList("dotnet", "java", "oracle", "python");
		int maxLength = words.stream()
		 .filter(s -> s.length() > 5)
		 .mapToInt(String::length)
		 .max()
		 .orElse(0);
		System.out.println(maxLength);
	}

}

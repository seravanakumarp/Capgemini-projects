//square all the numbers in a list of integers
package StreamAPI;
import java.util.*;
import java.util.stream.*;
public class Example2 
{
	public static void main(String[] args)
	{
		List<Integer> numbers = Arrays.asList(5, 4, 3, 8, 15);
		List<Integer> sqnums = numbers.stream()
		 .map(num -> num * num)
		 .collect(Collectors.toList());
		System.out.println(sqnums);
	}

}

//Convert a list of strings into uppercase
package StreamAPI;
import java.util.*;

import java.util.Arrays;
import java.util.stream.*;
public class Example1 
{
	public static void main(String[] args) 
	{
		List<String> l=new ArrayList<String>(Arrays.asList("sachin","rahul","dravid"));
		
		List<String> result=l.stream()
				.map(String::toUpperCase)
				.collect(Collectors.toList());
		
		System.out.println(result);
	}
}

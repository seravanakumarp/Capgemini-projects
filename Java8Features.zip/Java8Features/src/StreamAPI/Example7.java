//Program to display only odd numbers in the list
package StreamAPI;
import java.util.*;
public class Example7 {

	public static void main(String[] args) 
	{
		int[] arr = {5, 2, 8, 9, 3, 7, 1, 4, 6};
		List<Integer> list = new ArrayList<Integer>();
		for(int x : arr)
		list.add(x);
		System.out.println("List is : " + list);
		System.out.println("Odd numbers list is : ");
		list.stream().filter(s->s%2==1).forEach(System.out::println);
		
	}

}

//Filter and map a list of objects:
package StreamAPI;
import java.util.*;
import java.util.stream.Collectors;
class student
{
	private String name;
	private int age;

	student(String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}
	
	
}

public class Example10 {

	public static void main(String[] args) 
	{
		List<student> students = Arrays.asList(
				 new student("anil", 25),
				 new student("karthik", 30),
				 new student("srujan", 40)
				);
				List<String> namesAboveThirty =students.stream()
				 .filter(p -> p.getAge() > 30)
				 .map(student::getName)
				 .collect(Collectors.toList());
				System.out.println(namesAboveThirty);
	}

}

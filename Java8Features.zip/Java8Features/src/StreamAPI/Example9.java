//Filter and map strings to their uppercase versions:

package StreamAPI;
import java.util.*;

import java.util.stream.Collectors;

public class Example9 {

	public static void main(String[] args) {
		List<String> words = Arrays.asList("pencil", "eraser", "sharpner", "rubber");
		List<String> upperCaseWords = words.stream()
		 .filter(s -> s.length() > 3)
		 .map(String::toUpperCase)
		 .collect(Collectors.toList());
		System.out.println(upperCaseWords);
	}

}

//Display string whose length is 6:

package StreamAPI;
import java.util.*;
public class Example6 {

	public static void main(String[] args) 
	{
		String[] arr = {"sachin", "sehwag", "Saurav", "karthik", "dhoni"};
		List<String> list = new ArrayList<String>();
		for(int i=0 ; i<arr.length ; i++)
		list.add(arr[i]);
		list.stream().filter(s->s.length()==6).forEach(System.out::println);

	}

}

//Get the first character of each string in a list:
package StreamAPI;
import java.util.*;

import java.util.stream.*;

public class Example4 {

	public static void main(String[] args) 
	{
		List<String> words = Arrays.asList("cat", "dog", "bird");
		List<Character> firstChar = words.stream()
		.map(s -> s.charAt(0))
		.collect(Collectors.toList());
		System.out.println(firstChar);
	}

}

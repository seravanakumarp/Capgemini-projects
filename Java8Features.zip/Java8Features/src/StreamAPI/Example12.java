//Filter and map a list of strings to their 
//lengths, removing duplicates:

package StreamAPI;
import java.util.*;
import java.util.stream.Collectors;

public class Example12 {

	public static void main(String[] args) 
	{
		List<String> words = Arrays.asList("dotnet", "java", "oracle", "python","ruby","oracle","python");
		List<Integer> distinctWordLengths = words.stream()
		 .filter(s -> s.length() > 4)
		 .map(String::length)
		 .distinct()
		 .collect(Collectors.toList());
		System.out.println(distinctWordLengths);
	}

}

//Extract the lengths of strings in a list:
package StreamAPI;
import java.util.*;
import java.util.stream.*;

public class Example3 {

	public static void main(String[] args) {
		List<String> stationary = Arrays.asList("sharpner", "welcome to java world", "pencil");
		List<Integer> l=stationary.stream()
				.map(String::length)
				.collect(Collectors.toList());
		System.out.println(l);
	}

}

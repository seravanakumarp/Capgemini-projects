package StreamAPI;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public class KartDatabase
{
	public static List<Customer> getAll()
	{
		return Stream.of(
				new Customer(1,"sachin","sachin@gmail.com",Arrays.asList(45674365,36434624)),
				new Customer(2,"rahul","rahul@gmail.com",Arrays.asList(4457347,45743975)),
				new Customer(3,"dhoni","dhoni@gmail.com",Arrays.asList(4682374,34768326)),
				new Customer(4,"kapil","kapil@gmail.com",Arrays.asList(2934474,24632864)),
				new Customer(5,"anil","anil@gmail.com",Arrays.asList(3493274,2372347))
				
				).collect(Collectors.toList());
				
	}
}

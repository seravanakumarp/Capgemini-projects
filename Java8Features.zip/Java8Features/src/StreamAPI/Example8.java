//Filter and map positive integers to their squares:

package StreamAPI;
import java.util.*;
import java.util.stream.Collectors;
public class Example8 {

	public static void main(String[] args)
	{
		List<Integer> numbers = Arrays.asList(2, -4, 3, -9, 5);
		List<Integer> squaresOfPositiveNumbers = numbers.stream()
		 .filter(n -> n > 0)
		.map(n -> n * n)
		.collect(Collectors.toList());
		System.out.println(squaresOfPositiveNumbers);
	}

}

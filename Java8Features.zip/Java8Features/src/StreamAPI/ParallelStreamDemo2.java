package StreamAPI;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

public class ParallelStreamDemo2 {

	public static void main(String[] args)throws IOException

	{
		// Creating a File object  
		File f = new File("D:/sample.java");  
		  
		// Reading the lines of the file parallelstream.txt by  
		// making a List by invoking the method readAllLines()  
		List<String> text = Files.readAllLines(f.toPath());  
		  
		// Creating different parallel streams by making a List  
		// by invoking the method readAllLines()  
		text.parallelStream().forEach(System.out::println);  
	}

}

//forEachOrdered():
package StreamAPI;
import java.util.*;
public class Example19 
{

	public static void main(String[] args)
	{
		List<String> list = Arrays.asList("Anil","chetan","dhoni","sravan","puneeth");
		list.stream().parallel().forEach( System.out::println );
		list.stream().parallel().forEachOrdered( System.out::println );
	}

}

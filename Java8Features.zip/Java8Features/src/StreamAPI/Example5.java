//Program to filter the Strings starts with “k” in a list:

package StreamAPI;
import java.util.*;
import java.util.stream.*;

public class Example5 {

	public static void main(String[] args) 
	{
		List<String> list = new ArrayList<String>();
		list.add("Rahul");
		list.add("Kapil");
		list.add("Sachin");
		list.add("Sehwag");
		list.add("Suryakumar");
		list.add("Kohli");
		Stream<String> st = list.stream();
		Stream<String> res = st.filter(s->s.startsWith("K"));
		res.forEach(System.out::println);
	}

}

package LambdaExpressions;
/*class Test implements Runnable
{
	public void run()
	{
		for(int i=1;i<=100;i++)
			System.out.print(i+" ");
	}
}*/

public class Lambdawithrunnable {

	public static void main(String[] args) 
	{
		//Test t=new Test();
		
//		Thread td=new Thread(t);
//		td.start();
		
		Runnable r=() ->
		{
			for(int i=1;i<=100;i++)
				System.out.print(i+" ");
		};
		Thread tdlambda=new Thread(r);
		tdlambda.start();
	}

}

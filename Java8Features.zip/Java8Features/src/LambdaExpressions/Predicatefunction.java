package LambdaExpressions;
import java.util.function.Predicate;

public class Predicatefunction implements Predicate<Integer>
{
	@Override
	public boolean test(Integer t) 
	{
		if(t>=18)
			return true;
		else
			return false;
	}

	public static void main(String[] args) 
	{
		Predicatefunction pfd=new Predicatefunction();
		boolean result1=pfd.test(22);
		
		if(result1)
			System.out.println("eligible for voting");
		else
			System.out.println("not eligible for voting");
		
		//lambda expression for predicate functional interface
		
		Predicate<Integer> predicate=(t) ->
		{
			if(t>=18)
				return true;
			else
				return false;
		};
		boolean result2=predicate.test(12);
		
		if(result2)
			System.out.println("eligible for voting");
		else
			System.out.println("not eligible for voting");
		

	}

}

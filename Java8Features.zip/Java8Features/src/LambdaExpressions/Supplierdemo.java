package LambdaExpressions;
import java.time.LocalDateTime;
import java.util.function.Supplier;

public class Supplierdemo implements Supplier<LocalDateTime>
{

	@Override
	public LocalDateTime get() 
	{
		return LocalDateTime.now();
	}

	public static void main(String[] args)
	{
		Supplierdemo sd=new Supplierdemo();
		System.out.println(sd.get());
		
		//lambda expression for supplier functional interface
		
		Supplier<LocalDateTime> supplier=()->LocalDateTime.now();
		System.out.println(supplier.get());// TODO Auto-generated method stub

	}

}

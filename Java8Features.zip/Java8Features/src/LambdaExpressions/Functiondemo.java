package LambdaExpressions;
import java.util.function.Function;

public class Functiondemo implements Function<String,Integer>
{
	@Override
	public Integer apply(String t)
	{
		return t.length();
	}

	public static void main(String[] args)
	{
		Functiondemo fd=new Functiondemo();
		int length=fd.apply("sachin tendulkar");
		System.out.println("length of the given string="+length);
		
		//lambda expression  for function functional interface
		Function<String,Integer> function=(String t)->t.length();
		int length2=function.apply("rahul dravid");
		System.out.println("length of the given string="+length2);
		
	}

}

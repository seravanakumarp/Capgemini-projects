/*
 * Lambda Expression:
 * 
 * -> Lambda Expressions is an anonymous function. 
 * -> A function without a name which does not belongs to any class 
 * is called anonymous function.
 * -> The main purpose of Lambda Expression is to implement the 
 * functional interface.
 * 
 * Functional Interface:
 * -> An interface which contains only one abstract method is called
 * functional interface.
 * 
 * ->A functional interface can have any number of default methods as well as 
 * static methods but can have only one abstract method.
 * 
 * Method vs Lambda:
 * A method is the one which belongs to a class or an object whereas
 * Lambda does not belongs to any class or object.
 * 
 * Parts of a Method                          Parts of Lambda
 * 1. Method name                             1.Lambda will not have 
 *                                              any name
 * 2. Parameter list                          2. Lambda has parameter list
 * 3. return type                             3. we don't generally have
 *                                               return type. Java 8+ 
 *                                               compilers will automatically
 *                                               recognizes the return types.
 * 4. Method has body                         4. Lambda has body of 
 *    of statements                              statements 
 *    
 *   Lambda:
 *        ()                 ->                       {}
 *     Lambda                Lambda Symbol          Lambda body
 *     parameters
 * 
 * 
 * 
 */

package LambdaExpressions;
interface Shape
{
	void draw();
}

public class LambdaExample1 {

	public static void main(String[] args) 
	{
		print(() ->System.out.println("Draw method of Rectangle class"));
		print(() ->System.out.println("Draw method Triangle class"));
		print(() ->System.out.println("Draw method of Circle class"));
	}
	public static void print(Shape shape)
	{
		shape.draw();
	}
}

package LambdaExpressions;
interface Shape1
{
	void draw();
}
/*class Rectangle implements Shape
{
	public void draw()
	{
		System.out.println("draw method of Rectangle class");
	}
}
class Triangle implements Shape
{
	public void draw()
	{
		System.out.println("draw method of Trianlge class");
	}
}
class Circle implements Shape
{
	public void draw()
	{
		System.out.println("draw method of Circle class");
	}
}*/

public class Lambdaexpressiondemo {

	public static void main(String[] args) {
		
		/*Rectangle r=new Rectangle();
		r.draw();
		Triangle t=new Triangle();
		t.draw();
		Circle c=new Circle();
		c.draw(); */
		
//		Shape1 rect=()->System.out.println("draw method of Rectangle class");
//		rect.draw();
//		Shape1 tria=()->System.out.println("draw method of Trianlge class");
//		tria.draw();
//		Shape1 cir=()->System.out.println("draw method of Circle class");
//		cir.draw();
		
		display(()->System.out.println("draw method of Rectangle class")); //calling method
		display(()->System.out.println("draw method of Trianlge class"));
		display(()->System.out.println("draw method of Circle class"));

	}
	private static void display(Shape1 shape)
	{
		shape.draw();
	}
}

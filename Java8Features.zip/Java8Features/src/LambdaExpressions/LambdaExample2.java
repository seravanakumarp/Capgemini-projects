package LambdaExpressions;
interface Operations
{
	int multiply(int a,int b);
}
/*class Multiplication implements Operations
{
	public int multiply(int a,int b)
	{
		return a*b;
	}
}*/

public class LambdaExample2 {

	public static void main(String[] args) 
	{
		//traditional approach
				/*Multiplication m=new Multiplication();
				int result=m.multiply(10, 20);
				System.out.println(result);
				*/
				//lambda expression
				Operations op=(a,b) ->
				{
					return a*b;
				};
				int result2=op.multiply(10,20);
				System.out.println(result2);
				
	}

}

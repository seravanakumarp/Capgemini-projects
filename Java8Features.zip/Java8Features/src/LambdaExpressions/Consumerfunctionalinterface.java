package LambdaExpressions;
import java.util.function.Consumer;

public class Consumerfunctionalinterface implements Consumer<String>
{
	@Override
	public void accept(String s) {
		System.out.println(s);
		
	}

	public static void main(String[] args)
	{
		Consumerfunctionalinterface cfi=new Consumerfunctionalinterface();
		cfi.accept("qedge");
		
		//lambda expression for consumer functional interface
		
		Consumer<String> consumer=(s)-> System.out.println(s);
			consumer.accept("technologies");
		
	}
}

package LambdaExpressions;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;

class Bipredicate1 implements BiPredicate<Integer,Integer>
{
	@Override
	public boolean test(Integer t, Integer u) 
	{
		if(t>=0&& u>=0)
			return true;
		else
			return false;
	}
}
class Bipredicate2 implements BiPredicate<Integer,Integer>
{
	@Override
	public boolean test(Integer t, Integer u) 
	{
			if(t%2==0 && u%2==0)
				return true;
			else
				return false;
	}
}

public class Bipredicateandornegate {

	public static void main(String[] args) 
	{
		Bipredicate1 bip1=new Bipredicate1();
		Bipredicate2 bip2=new Bipredicate2();
		
		BiPredicate<Integer,Integer> bip3=bip1.or(bip2);
		boolean result1=bip3.test(4, 5);
		
		System.out.println(result1);
		
		BiPredicate<Integer, Integer> res=bip3.negate();
		boolean x=res.test(10,20);
		
		System.out.println(x);
		
		BiPredicate<Integer,Integer> bip4=bip1.and(bip2);
		boolean result2=bip4.test(4, 5);
		
		System.out.println(result2);
			
		//lambda expression for BiPredicate functional interface
		
		BiPredicate<Integer,Integer> bip5=(t,u) ->
		{
			if(t>=0&& u>=0)
				return true;
			else
				return false;
		};
		BiPredicate<Integer,Integer> bip6=(t,u)-> 
	{
			if(t%2==0 && u%2==0)
				return true;
			else
				return false;
	};
		BiPredicate<Integer,Integer> bip10=bip5.or(bip6);
		boolean result5=bip10.test(4, 5);
		System.out.println(result5);
		

	}

}

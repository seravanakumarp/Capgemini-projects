/*
 * Unchecked Exception:
 * -> These are the exceptions which are generated due to the logical errors.
 * -> It is responsibility of the programmer to handle this logical errors.
 * -> Compiler will not through any error even an abnormal termination of a
 * a program takes place.
 * -> It is better to handle those exception to prevent from abnormal 
 * termination of a program
 * 
 * Checked Exception:
 * -> Whenever we connect to the resources(file,server,database,IO) to 
 * an program, there may be possibility of causing checked exceptions.
 * -> It is the role of the programmer to release the resource upon usage
 * to prevent from loss of data.
 * -> These resources are not a part of program or application, hence
 * we to handle these exception during their occurrence.
 * -> If not, compiler will not execute a program and does not generate
 * class file.
 * 
 *  
 */
package Exceptionhandling;
import java.io.*;
public class Checkedvsunchecked 
{

	public static void main(String[] args) throws Exception
	{
		FileInputStream fis=new FileInputStream("D:/sample.java");
		System.out.println("file opened");
		fis.close();
		System.out.println("file closed");
	}

}

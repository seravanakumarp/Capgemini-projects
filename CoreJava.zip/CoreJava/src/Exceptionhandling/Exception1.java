package Exceptionhandling;

public class Exception1 {

	public static void main(String[] args) 
	{
		try
		{
			int a=20,b=0,c;
			c=a/b;
		}
		catch(ArithmeticException ae)
		{
			System.out.println("denominator never be with a value zero");
		}
	}

}

package Exceptionhandling;

import java.io.FileInputStream;

import java.io.FileNotFoundException;

public class Exception2 {

	public static void main(String[] args) throws Exception
	{
			FileInputStream fis=null;
			try
			{
				fis=new FileInputStream("C:/Users/sekumarp/Documents/PYTHON/decorator2.txt");
				System.out.println("file opened successfully");
			}
			catch(FileNotFoundException fe)
			{
				System.out.println("file does not exist");
			}
			finally
			{
				fis.close();
			}
	}

}

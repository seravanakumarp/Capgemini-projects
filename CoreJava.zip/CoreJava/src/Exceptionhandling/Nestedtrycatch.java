/*nested try:
 * A try inside an another try is called nested try.
 * It is used to handle a part of code containing one exception and 
 * other part of code containing another exception.
 */
package Exceptionhandling;

public class Nestedtrycatch {

	public static void main(String[] args) 
	{
		try
		{
			try
			{
				int a=100/0;
				System.out.println(a);
			}
			catch(ArithmeticException ae)
			{
				ae.printStackTrace();
			}
			try
			{
				int a[]=new int[10];
				a[10]=121;
			}
			catch(ArrayIndexOutOfBoundsException aie)
			{
				aie.printStackTrace();
			}
			try
			{
				int c[]=null;
				System.out.println(c.length);
			}
			catch(NullPointerException npe)
			{
				npe.printStackTrace();
			}
			System.out.println(20/0);
		}
		catch(ArithmeticException ae)
		{
			System.out.println("denominator cannot be zero");
		}
	}

}

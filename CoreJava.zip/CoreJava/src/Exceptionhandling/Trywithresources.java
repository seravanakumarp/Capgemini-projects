package Exceptionhandling;

import java.io.FileInputStream;


public class Trywithresources 
{

	public static void main(String[] args) throws Exception
	{
		try(FileInputStream fis=new FileInputStream("C:/Users/sekumarp/Documents/PYTHON/decorator4.txt"))
		{
			int ch;
			
			while((ch=fis.read())!=-1)
			{
				System.out.print((char)ch);
			}
		}
	}

}

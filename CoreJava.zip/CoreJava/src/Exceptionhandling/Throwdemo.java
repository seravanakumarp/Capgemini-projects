package Exceptionhandling;
class MyException extends Exception
{
	String name;
	MyException(String name)
	{
		this.name=name;
	}
	public String getErrorMessage()
	{
		return this.name;
	}
}
public class Throwdemo 
{

	public static void main(String[] args) 
	{
		try
		{
			MyException me=new MyException("Invalidpin");
			throw me;
		}
		catch(MyException m)
		{
			System.out.println(m.getErrorMessage());
		}
	}

}

/*
 * throws keyword:

 * when a method is not able to handle the exception,
 * it can throw that exception.
 * throws is used in checked exception
 * the calling method must handle that exception, if not,
 * 
 * in a hierarchy the next calling method should handle that exception
 * 
 * suppose if none of the methods are not handling the exception,
 * it will be routed to JVM.
 * JVM -> default exception handler.
 * 
 * throw keyword:
 * 
 * It is used to throw the user defined exception object explicitly.
 * 
 * Syntax: class UserdefinedExceptionclass extends RunTimeException
 * 		{ 
 * 		}
 * 			class MyException extends Exception
 * 			{
 * 			}
 * syntax: throw<throwable_object>
 * 
 * 
 *  
 */

package Exceptionhandling;

import java.io.IOException;

class Test
{
	public void z() throws IOException
	{
		throw new IOException("FILE ERROR");
	}
	public void y() throws IOException
	{
		z();
	}
	public void x()
	{
		try
		{
			y();
		}
		catch(Exception e)
		{
			System.out.println("Exception handled");
		}
	}
}
public class Throwsdemo {

	public static void main(String[] args) 
	{
		Test t=new Test();
		t.x();
		
	}

}

/*
 * this:

 * 1. this reference variable is used to refer the instance members of
 * a class.
 * 2. this reference variable can be used inside the constructor
 * as well as instance method.
 */
package Constructors;
class Productinfo
{
	int id;
	String name;
	float price;
	
	Productinfo(int id,String name,float price) //constructor
	{
		this.id=id;
		this.name=name;
		this.price=price;
	}
	void display() //instance method
	{
		System.out.println(this.id+" "+this.name+" "+this.price);
	}
}
public class Parameterizedconstructor {

	public static void main(String[] args) 
	{
			Productinfo pi=new Productinfo(101,"pen",35);
			pi.display();
			
			Productinfo pi1=new Productinfo(102,"eraser",5);
			pi1.display();
			
	}

}

package Constructors;
class Singleton
{
	static Singleton s=new Singleton();
	
	private Singleton()
	{
		
	}
	static Singleton getInstance()
	{
		return s;
	}
}
public class Singletonclass {

	public static void main(String[] args) 
	{
			Singleton s1=Singleton.getInstance();
			Singleton s2=Singleton.getInstance();
			
			if(s1==s2)
				System.out.println("objects are same");
	}

}

/*
 * super: it is a keyword used to refer the
 * immediate parent class members.
 * 
 * super: super is used to refer both variables and methods
 * of immediate parent class.
 * super(): it is used to invoke parent class constructor
 * from child class constructor.
 */


package Constructors;
class A
{
	int a;
	int b;
	A(int a,int b)
	{
		this.a=a;
		this.b=b;
	}
	
}
class B extends A
{
	int c;
	int d;
	B(int a,int b,int c,int d)
	{
		super(a,b);
		this.c=c;
		this.d=d;
	}
	void display()
	{
		System.out.println(super.a);
		System.out.println(super.b);
		System.out.println(this.c);
		System.out.println(this.d);
	}
}
public class Superdemo {

	public static void main(String[] args) 
	{
			B b=new B(10,20,30,40);
			b.display();
	}

}

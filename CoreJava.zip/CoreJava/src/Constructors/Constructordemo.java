/*  Constructor:



 *  1. It is a special kind of method.
 *  2. It is invoked during the creation of object time.
 *  3. A default constructor will be created implicitly by
 *  the compiler.
 *  4. Constructors are used to initialize the instance variables.
 *  
 *  Rules:
 *  1. Constructor name is same as that of class name
 *  2. Constructor don't have any return type like int,float including
 *     void
 *  3. Constructor can have access modifiers like private,
 *  	public, protected and default.
 *  4. A java constructor can't have static,final,abstract and 
 *  	synchronized.
 *  
 *  Types of Constructors:
 *  1. Default constructor.
 *  2. Zero parameterized constructor.
 *  3. Parameterized constructor.
 *  
 *  NOTE: no copy constructor in java.But we will implement
 *  copy constructor.
 *  4. Constructor chaining
 *  5. private constructor
 *  
 *  
 * 
 */

package Constructors;
class Student10
{
	int rollno;
	String name;
	float marks;
	
	
	void display()
	{
		System.out.println(rollno+" "+name+" "+marks);
	}
}
public class Constructordemo {

	public static void main(String[] args) 
	{
			Student10 s=new Student10();
			s.display();
	}

}

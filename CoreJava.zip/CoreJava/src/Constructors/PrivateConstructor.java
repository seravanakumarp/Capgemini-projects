/* Private Constructor:


 * 
 * 1. A private constructor allows us to create an
 * object with in the class itself.
 * 2. A class with private constructor whose object can't
 * be created in an another class.
 * 
 * Advantage: Implementing of Singleton class.
 * 
 * A singleton class is a class which can contain only one object.
 * 
 */

package Constructors;
class Demo
{
	int x;
	int y;
	private Demo(int x,int y)
	{
		this.x=x;
		this.y=y;
	}
	void display()
	{
		System.out.println(this.x+" "+this.y);
	}
}
public class PrivateConstructor 
{
	int x;
	int y;
	
	private PrivateConstructor(int x,int y)
	{
		this.x=x;
		this.y=y;
	}
	void display()
	{
		System.out.println(this.x+" "+this.y);
	}
	public static void main(String[] args)
	{
		  PrivateConstructor pc=new PrivateConstructor(10,20);
		  pc.display();
		  Demo d=new Demo(30,40);
	}

}

/*
 * this keyword:
 * -> It is used to refer the current class object.
 * -> It can be used to access the instance members(instance variables
 * and instance methods) of a given class.
 * -> this keyword is an optional if there is no confusion between 
 * instance variable and the local variable.
 * -> this keyword is mandatory if the local variable and instance variable
 * have the same name which can cause a confusion.
 *
 */
package Constructors;

public class Thisdemo 
{
	int x;
	int y;
	
	public void display()
	{
		int x=20;
		int y=30;
		
		System.out.println(this.x);
		System.out.println(this.y);
		
		System.out.println(x);
		System.out.println(y);
	}
	public static void main(String[] args)
	{
			Thisdemo td=new Thisdemo();
			td.display();
	}

}

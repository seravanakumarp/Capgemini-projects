/*
 * Constructor Chaining:


 * 
 * 1. It is a process of invoking one constructor from an another
 * constructor.
 * 2. this() is used for invoking an constructor.
 * 
 * Advantages:
 * 1. Readability.
 * 2. Constructor overloading.
 */

package Constructors;
class Demo
{
	Demo()
	{
		this(10);
		System.out.println(" default parent constructor");
	}
	Demo(int x)
	{
		System.out.println("value of x="+x);
	}
}
class Sample extends Demo
{
	Sample()
	{
		this(10); //constructor call
		System.out.println("default constructor");
	}
	Sample(int x) //x=10
	{
		this(10,20); //constructor call
		System.out.println("value of x="+x);
	}
	Sample(int x,int y) //x=10 y=20
	{
		this("sachin"); //constructor call
		System.out.println("value of x="+x+"value of y="+y);
	}
	Sample(String s)
	{
		super();
		System.out.println(s); //sachin
	}
}

public class Constructorchaining {

	public static void main(String[] args) 
	{
		Sample s=new Sample();
	}

}

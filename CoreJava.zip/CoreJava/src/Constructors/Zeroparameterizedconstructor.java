package Constructors;
class Employee10
{
	int empid=123;
	String name="sachin";
	String designation="programmer";
	float salary=55000;
	
	Employee10()
	{
		System.out.println(empid+" "+name+" "+designation+" "+salary);
	}
	void display(int empid,String name,String designation,float salary)
	{
		this.empid=empid;
		this.name=name;
		this.designation=designation;
		this.salary=salary;
		
		System.out.println(this.empid+" "+this.name+" "+this.designation+" "+this.salary);
	}
}
public class Zeroparameterizedconstructor 
{

	public static void main(String[] args) 
	{
		Employee10 e=new Employee10();
		
		e.display(124,"rohan","analyst",45000);
		
		
	}

}

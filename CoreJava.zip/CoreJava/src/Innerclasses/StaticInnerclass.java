package Innerclasses;

public class StaticInnerclass 
{
	static class Inner
	{
		public void innerMethod()
		{
			System.out.println("inner class method");
		}
	}
	public static void main(String[] args) 
	{
		Inner i=new Inner();
		i.innerMethod();

	}

}

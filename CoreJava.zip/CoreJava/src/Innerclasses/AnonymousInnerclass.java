package Innerclasses;
class Outer
{
	public void display()
	{
		System.out.println("Outer class display method");
	}
}
public class AnonymousInnerclass {

	public static void main(String[] args)
	{
		Outer o=new Outer();
		o.display();
		
		Outer o1=new Outer()
				{
					public void display()
					{
						System.out.println("display method of inner class");
						print();
					}
					public void print()
					{
						System.out.println("hello");
					}
				};
				o1.display();
				
				
	}

}

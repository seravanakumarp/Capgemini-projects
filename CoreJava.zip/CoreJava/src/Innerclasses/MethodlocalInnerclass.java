package Innerclasses;
class Outerclass1
{
	public void outerMethod()
	{
		class Innerclass1
		{
			public void innerMethod()
			{
				System.out.println("inner class method");
			}
			
		}
		Innerclass1 i=new Innerclass1();
		i.innerMethod();
		
	}
}
public class MethodlocalInnerclass {

	public static void main(String[] args) 
	{
			Outerclass1 o1=new Outerclass1();
			o1.outerMethod();
	}

}

/*
 * Inner classes:
 * A class defined inside an another class is called inner class or 
 * nested class.
 * Advantange:
 * 
 * -> An inner class can able to access all the members of outer class
 * including private.
 * -> Less line of code.
 * -> Readability and maintainable
 * -> A class which is useful another class but may not needed for all
 * the rest of the classes can be made as inner classes.
 * 
 * Types of Inner classes:
 * 1. Regular Inner class.
 * 2. Method Local Inner class.
 * 3. Anonymous Inner class
 * 4. Static Inner class
 * 
 * 
 * 
 */
package Innerclasses;
class Outerclass
{
	class Innerclass
	{
		public void innerMethod()
		{
			System.out.println("inner class method");
		}
	}
	public void outerMethod()
	{
		System.out.println("Outer class method");
	}
}
public class Innerclassdemo {

	public static void main(String[] args) 
	{
		Outerclass o=new Outerclass();
		o.outerMethod();
		
		Outerclass.Innerclass i=new Outerclass().new Innerclass();
		i.innerMethod();

	}

}

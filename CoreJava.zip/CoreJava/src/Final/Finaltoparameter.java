package Final;

public class Finaltoparameter 
{

	public static void main(String[] args) 
	{
		float length=30,breadth=40;
		area_of_rectangle(length,breadth);
	}
	public static void area_of_rectangle(final float length,float breadth)
	{
		float area;
		area=length*breadth;
		System.out.println("area of rectangle"+area);
		
		breadth=50;
		length=100; //error
		area=length*breadth;
		System.out.println("area of rectangle"+area);
		
		
	}
}

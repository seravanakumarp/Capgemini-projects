/*
 * final keyword:
 * A final is a keyword which can be applied to a variable,method and a
 * class.
 * 
 * final variable:
 * A final to a variable does not changes its value.
 * A final variable in java is nothing a constant value.
 * A final can applied to instance variables, static variables,local
 * variables and reference variables.
 * 
 * final to instance variables:
 * A final to instance variable does not initialize with default values.
 * The programmer must explicitly initialize the final instance variables.
 * 
 * The final instance variable whose value can't be reassigned.
 * 
 * final to static variables:
 * A final to static variable does not initialize with default values.
 * The programmer must explicitly initialize the final static variables.
 * 
 * The final static variables whose value can't be reassigned.
 * 
 * final to local variables:
 * Local variables are to be initialized explicitly by the programmer.
 * A final to a local variable can't be reassigned. 
 * 
 */
package Final;

public class Finaldemo 
{
	int x=10;
	final int y=20;
	static int z=30;
	final static int p=40;
	public static void main(String[] args) 
	{
			Finaldemo fd=new Finaldemo();
			
			System.out.println("value of x="+fd.x);
			System.out.println("value of y="+fd.y);
			
			fd.y=30; //error
			
			System.out.println("value of z="+z);
			System.out.println("value of p="+p);
			
			p=100; //error
			
			int a=100;
			final int b;
			
			System.out.println("value of a="+a);
			
			b=300;
			
			System.out.println("value of b="+b);
			
			b=450;
			
			
	}

}

/* Instance block:
 * 
 * -> If a group of statements are defined in a curly braces without any 
 * keyword, then it is called as instance block.
 * 
 *  Syntax: {
 *  			statements;
 *  		}
 * -> The main use of instance block is to instantiate the instance variables.
 * -> A class can contain any number of instance blocks and placed 
 * anywhere in a class.
 * -> All the instance blocks are executed from top to bottom, one time
 * when an object is created.
 * 
 * -> When an instance variable is declared but not initialized, then it
 * will be initialized with the default values. If you do not want to
 * have the default values, then explicitly initialize them during
 *     -> variable declaration
 *     -> constructor definition
 *     -> instance block
 *     
 *-> When an object is created, the JVM will start moving from beginning
 *of the class and go through all the instance variables and instance blocks.
 *When a instance variables occur, JVM will allocate the memory for
 *the instance variables and execute the instance blocks upon occurrence.
 *
 *-> once the instance variables whose memory is allocated and instance 
 *blocks are executed, the constructors of the class get executed by
 *the JVM.
 *
 *Static block:
 *-> If a group of statements are defined in a curly braces with a static
 *keyword, then it is called as static block.
 *
 *             Syntax: static
 *             			{
 *             				statements;
 *             			}
 *-> The main use of static blocks are to initialize the static variables.
 *-> A class can contain any number of static blocks and can placed in 
 *any order in the class.
 *-> All the static blocks gets executed from top to bottom one time
 *during class loading time.
 *
 *-> If the static variables are declared but not initialized,they will
 *be initialized with default values. If we do not want to initialize
 *with default values, then explicitly initialize them during
 *   -> variable declaration
 *   -> inside the static blocks.
 *
 *-> When a class is loaded, the JVM will start from the beginning of the
 *class and go through all the static variables and static blocks. If a
 *static variable is occurred, JVM will allocate the memory for
 *static variables and if static blocks occurs they get executed.
 *
 *-> If all the static variables are allocated with memory and static 
 *blocks are executed then JVM will try to execute the main() method.
 
 */
package Final;

public class Instanceblock 
{
	static
	{
		System.out.println("static block1");
	}
	static 
	{
		System.out.println("static block2");
	}
	{
		System.out.println("instance block1");
	}
	Instanceblock()
	{
		System.out.println("zero parameterized constructor");
	}
	Instanceblock(int x)
	{
		System.out.println("parameterized constructor");
	}
	public static void main(String[] args) 
	{
		Instanceblock ib=new Instanceblock();
		Instanceblock ib1=new Instanceblock(20);
	}
	{
		System.out.println("instance block2");
	}

}

package Basicprograms;
import java.io.*;	
class Basicelements
{
	public static void main(String args[])
	{
		int a=10; //assigning value 10 to a
		System.out.println(a);
		System.out.println("value of a="+a);

		int b=0234; //octal literal
		System.out.println("value of b="+b);
		

		int c=0x34f; //hexadecimal literal
		System.out.println("value of c="+c);

		int d=0b1111; //binary literal
		System.out.println("value of d="+d);

		float e=3.142578776567f;
		System.out.println("value of e="+e);

		char f=' ';
		System.out.println("value of f="+f);
		int g=f;
		System.out.println("value of g="+g);
		

		String h="sathya";
		System.out.println("value of h="+h);

		boolean i=true;
		System.out.println("value of i="+i);

		String j=null; //null is used to represent the absence of an object
		System.out.println("value of j="+j);

		int k=65;
		char l=(char)k;
		System.out.println("value of l="+l);

		short m=3276;
		System.out.println("value of m="+m);

		long o=64832843894793L;
		System.out.println("value of o="+o);

		byte p=100;
		System.out.println("value of p="+p);

		double q=4.54795749544;
		System.out.println("value of q="+q);

		int r=100;
		String s2="sathya";

		System.out.println(r+s2);


		int a1=20;
		int b1=30;

		System.out.println("sum of a1 and b1="+a1+b1);
		
		System.out.println("sum of a1 and b1="+(a1+b1));


		int c1=100;
		String d1="200";

		System.out.println(c1+d1);

		System.out.println(c1+Integer.parseInt(d1));

		int e1=3000;
		String f1="4000";

		System.out.println(f1+Integer.toString(e1));
	}
}
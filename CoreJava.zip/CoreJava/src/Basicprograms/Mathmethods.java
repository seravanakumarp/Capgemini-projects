//Java program demonstrating the concept of Math class methods
package Basicprograms;
import java.io.*;
import java.lang.*;
class Mathmethods
{
	public static void main(String args[])
	{
		int a=4,b=-5,d=10;
		float c=3.142f;
		

		System.out.println(Math.sqrt(a));
		System.out.println(Math.cbrt(a));
		System.out.println(Math.abs(b));
		System.out.println(Math.max(a,b));
		System.out.println(Math.min(a,b));
		System.out.println(Math.floor(c));
		System.out.println(Math.ceil(c));
		System.out.println(Math.pow(a,3));
		System.out.println(Math.exp(a));
		System.out.println(Math.log(a)); //natural logarithm base e(Euler's number=2.71828)
		System.out.println(Math.log10(d)); //common logarithm base 10

		System.out.println(Math.random());

		int min=100,max=200;

		System.out.println((int)(Math.random()*(max-min+1))+min);
		
	}
}


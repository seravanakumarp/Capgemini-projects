//Java program to check whether the given three digit number is //palindrome or not
package Basicprograms;
import java.io.*;
class Palindrome
{
	public static void main(String args[])
	{
		int n=124;
		String result=""; //empty string
		
		result=(n/100==n%10)?"Palindrome":"not a Palindrome";
		
		System.out.println(result);
	}
}
		
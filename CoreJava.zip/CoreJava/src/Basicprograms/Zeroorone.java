//Java program to print '1' if input character is capital letter otherwise 0
package Basicprograms;
import java.io.*;
class Zeroorone
{
	public static void main(String args[])
	{
		char ch='T';
		int result;

		result=(ch>='A' && ch<='Z')?1:0;

		System.out.println(result);
	}
}
		
		
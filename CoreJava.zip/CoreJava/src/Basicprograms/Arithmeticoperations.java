//Java program which reads two integer values from the keyboard and perform
// the arithmetic operations
package Basicprograms;
import java.io.*;
import java.util.*;

class Arithmeticoperations
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);

		int a,b;

		System.out.println("Enter the values of a and b");
		a=sc.nextInt();
		b=sc.nextInt();

		System.out.println("Addition of two numbers="+(a+b));
		System.out.println("Subtraction of two numbers="+(a-b));
		System.out.println("Multiplication of two numbers="+(a*b));
		System.out.println("Quotient of two numbers="+(a/b));
		System.out.println("Remainder of two numbers="+(a%b));
	}
}
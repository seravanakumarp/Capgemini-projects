//Java program to find largest of two numbers using conditional operator
package Basicprograms;
import java.io.*;
class Largestoftwo
{
	public static void main(String args[])
	{
		int a=45,b=31,c;

		c=(a>b)?a:b;

		System.out.println("largest of two numbers="+c);
	}
}

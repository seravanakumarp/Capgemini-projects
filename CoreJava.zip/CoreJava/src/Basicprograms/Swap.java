//Java program which reads two integer values from the keyboard and swap these values
//i. using temporary variable
//ii. without using temporary variable
package Basicprograms;
import java.io.*;
import java.util.*;

class Swap
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);

		int a,b,temp;

		System.out.println("Enter the values of a and b");
		a=sc.nextInt();
		b=sc.nextInt();

		System.out.println("Before Swapping:a="+a+"b="+b);

		//with temporary variable
		/*temp=a;
		a=b;
		b=temp; */

		//without temporary variable
		a=a+b;
		b=a-b;
		a=a-b;

		System.out.println("After swapping:a="+a+"b="+b);
	}
}
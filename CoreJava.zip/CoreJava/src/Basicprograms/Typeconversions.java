//Java program to demonstrate the concept of data type conversions
package Basicprograms;
import java.io.*;
class Typeconversions
{
	public static void main(String args[])
	{
		//Implicit type conversion

		float a=3.142f;
		double d=a;

		System.out.println(d);

		int c=64785;
		long l=c;

		System.out.println(l);

		//Explicit type conversion

		float f=3.142f;
		int g=(int)f;
		System.out.println(g);

		double h=5.4858934759843;
		float i=(float)h;

		System.out.println(i);

		double p=6.3846832489327;
		long q=(long)p;

		System.out.println(q);

		
	}
}
//Java program to find sum of all the digits of three digit number
package Basicprograms;
import java.io.*;
class Sumofdigits
{
	public static void main(String args[])
	{
		int n=123,p,q,r,s,sum;

		p=n%10; //3

		q=n/10; //12

		r=q%10; //2

		s=q/10; //1

		sum=p+r+s;

		System.out.println(sum);
	}
}
		
//Java program to find the largest of three numbers using conditional operator
package Basicprograms;
import java.io.*;
class Largestofthree
{
	public static void main(String args[])
	{
		int a=45,b=12,c=90,result;

		result=((a>b)&&(a>c))?a:((b>c)?b:c);

		//result=((a>b)&&(a>c))?a:c;

		System.out.println("largest of three numbers="+result);
	}
}
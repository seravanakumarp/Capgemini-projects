package Strings;

public class Stringmethods {

	public static void main(String[] args) 
	{
			String s="welcome to qedge technologies";
			
			String s1="qedge";
			
			String s2="QEDGE";
			
			System.out.println(s.charAt(5));
			
			System.out.println(s.length());
			
			System.out.println(s.equals(s1));
			
			System.out.println(s1.equalsIgnoreCase(s2));
			
			System.out.println(s1.concat(s));
			
			System.out.println(s1);
			
			System.out.println(s1.isEmpty());
			
			System.out.println(s.replace('e','a'));
			
			System.out.println(s.substring(7));
			
			System.out.println(s.substring(6, 14));
			
			System.out.println(s.indexOf('e'));
			
			System.out.println(s.lastIndexOf('e'));
			
			System.out.println(s.toUpperCase());
			
			System.out.println(s.toLowerCase());
			
		    //split(): it is used to convert a string into string array
			
			String str[]=s.split(" ");
			
			for(int i=0;i<str.length;i++)
				System.out.println(str[i]);
			
			//trim(): it is used to remove extra at beginning and end of string
			
			String s10="     welcome to qedge technologies      ";
			
			System.out.println(s10.trim());
			
			//toCharArray(): It is used to convert a string into character array
			
			String s11="qedge";
			
			char ch[]=s11.toCharArray();
			
			for(int i=0;i<ch.length;i++)
				System.out.println(ch[i]);
			
			
			
			
	}

}

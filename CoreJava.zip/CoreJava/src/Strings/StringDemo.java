package Strings;
import java.lang.*;
public class StringDemo 
{
	public static void main(String[] args) 
	{
		String s="sathya";
		System.out.println(s);
		
		String s1=s.concat("tech");
		
		System.out.println(s1);
		
		
		String s2=new String("java world");
		System.out.println(s2);
		
		s2.concat("best");
		
		System.out.println(s2);
		
	}

}

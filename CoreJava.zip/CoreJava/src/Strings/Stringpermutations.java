package Strings;
import java.util.*;
public class Stringpermutations
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		String str;
		
		System.out.println("Enter the string");
		str=sc.next();
		
		permutations(str); //abc

	}
	public static void permutations(String s)
	{
		int n=s.length(); //3
		int f=factorial(n); //6
		int temp;
		for(int i=0;i<f;i++) //i=1
		{
			//temp=i; //0 1
			StringBuffer sb=new StringBuffer(s); //String object to StringBuffer object
			
			for(int div=n;div>=1;div--) //3>=1 2>=1 1>=1 0>=1 3>=1 2>=1 1>=1
			{
				//int q=i/div;  //q=0/3=0 //q=0/2=0 q=0 q=1/3=0 q=1/2=0 q=1/1=1
				int r=i%div;  //r=0%3=0 //r=0%2=0 r=0 r=1%3=1 r=1%2=1 r=1%1=0
				
				System.out.print(sb.charAt(r)); //abc bca
				sb.deleteCharAt(r); //abc bca
				
			}
			System.out.println("");
		}
		
		
	}
	public static int factorial(int n)
	{
		int fact=1,i;
		
		if(n==0)
			return 1;
		else
		{
			fact=1;
			for(i=1;i<=n;i++)
				fact=fact*i;
			return fact;
			
		}
		/*
		 * if(n==0)
		 *  return 1;
		 *  else
		 *    return n*factorial(n-1);
		 */
		
	}
	

}

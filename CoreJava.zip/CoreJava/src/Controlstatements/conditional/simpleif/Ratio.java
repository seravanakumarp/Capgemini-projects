package Controlstatements.conditional.simpleif;
import java.util.*;
public class Ratio 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		float a,b,ratio,temp;
		
		System.out.println("Enter the value of a and b");
		a=sc.nextFloat();
		b=sc.nextFloat();
		
		ratio=a/b;
		
		if(ratio>0)
		{
			temp=a;
			a=b;
			b=temp;
		}
		
		System.out.println("The value of a is "+a+" and b is "+b);
	}
}

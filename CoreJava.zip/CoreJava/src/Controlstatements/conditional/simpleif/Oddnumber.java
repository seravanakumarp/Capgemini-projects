package Controlstatements.conditional.simpleif;
import java.util.*;
public class Oddnumber {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n;
		
		System.out.println("Enter the number");
		n=sc.nextInt();
		
		if(n%2==1)
		{
			System.out.println(n+" is an odd number");
		}
		
	}

}

package Controlstatements.conditional.switchcase;
import java.util.*;
public class Temperatureconversions 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("*******TEMPERATURE CONVERSIONS******");
		System.out.println("C:CELSIUS TEMPERATURE");
		System.out.println("F:FAHRENHEIT TEMPERATURE");
		System.out.println("K:KELVIN TEMPERATURE");
		
		float ft=0,ct=0,kt=0,it;
		char choice;
		
		System.out.println("Enter the initial temperature");
		it=sc.nextFloat();
		
		System.out.println("Enter the choice");
		choice=sc.next().charAt(0);
		
		if(choice=='F'||choice=='C'||choice=='K')
		{
		switch(choice)
		{
			case 'F':ft=it;
					 ct=(ft-32.0f)*5/9;
					 kt=ct+273.03f;
					 break;
			case 'C':ct=it;
					 ft=(ct*9)/5+32.0f;
					 kt=ct+273.03f;
					 break;
			case 'K':kt=it;
					 ct=kt-273.03f;
					 ft=(ct*9)/5+32.0f;
					 break;
			
		}
		
		System.out.println("Fahrenheit temperature="+ft);
		System.out.println("Celsius temperature="+ct);
		System.out.println("Kelvin temperature="+kt);
		
		}
		else
			System.out.println("Invalid choice");
	}

}

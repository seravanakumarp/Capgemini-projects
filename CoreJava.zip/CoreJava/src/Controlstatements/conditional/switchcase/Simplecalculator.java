package Controlstatements.conditional.switchcase;
import java.util.*;
public class Simplecalculator {

	public static void main(String[] args) 
	{
			Scanner sc=new Scanner(System.in);
			
			System.out.println("*******SIMPLE CALCULATOR********");
			System.out.println("+:ADDITION");
			System.out.println("-:SUBTRACTION");
			System.out.println("*:MULTIPLICATION");
			System.out.println("/:QUOTIENT");
			System.out.println("%:REMAINDER");
			
			int a,b,result;
			char choice;
			
			System.out.println("Enter the values of a and b");
			a=sc.nextInt();
			b=sc.nextInt();
			
			System.out.println("Enter the choice");
			choice=sc.next().charAt(0);
			
			switch(choice)
			{
				case '+': result=a+b;
						  System.out.println("Addition of two numbers="+result);
						  break;
				case '-': result=a-b;
						  System.out.println("Subtraction of two numbers="+result);
						  break;
				case '*': result=a*b;
						  System.out.println("Multiplication of two numbers="+result);
						  break;
				case '/': result=a/b;
						  System.out.println("Quotient of two numbers="+result);
						  break;
				case '%': result=a%b;
						  System.out.println("Remainder of two numbers="+result);
						  break;
				default : System.out.println("Invalid choice");
			}
			
	}

}

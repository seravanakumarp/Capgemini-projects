package Controlstatements.conditional.ifelseifladder;
import java.util.*;
public class Nearestnumber {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n,r;
		
		System.out.println("enter the value of n");
		n=sc.nextInt(); //28 27
		
		if(n%5==0)
		{
			System.out.println(n+" "+"is divisible by 5");
		}
		else
		{
			r=n%5;
			if(r>2)
				System.out.println("nearest number="+(n-r+5));
			else
				System.out.println("nearest number="+(n-r));
		}

	}

}

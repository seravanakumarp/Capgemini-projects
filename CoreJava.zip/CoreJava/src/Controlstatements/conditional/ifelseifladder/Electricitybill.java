package Controlstatements.conditional.ifelseifladder;
import java.util.*;
public class Electricitybill {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int current_units,previous_units,total_units;
		float e_bill;
		
		System.out.println("Enter the current meter reading");
		current_units=sc.nextInt();
		
		System.out.println("Enter the previous meter reading");
		previous_units=sc.nextInt();
		
		total_units=current_units-previous_units;
		
		if(total_units>=0 && total_units<=100)
			e_bill=total_units*0.8f;
		else if(total_units>=101 && total_units<=200)
			e_bill=80+(total_units-100)*1.2f;
		else if(total_units>=201 && total_units<=300)
			e_bill=200+(total_units-200)*1.5f;
		else
			e_bill=350+(total_units-300)*1.8f;
		
		System.out.println("Electricity bill="+e_bill);
		
		
		
	}

}

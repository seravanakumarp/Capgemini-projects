package Controlstatements.looping.dowhileloop;
import java.util.*;
public class Fibonacciseries 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int fib1=0,fib2=1,fib3,count,limit;
		
		System.out.println("Enter the limit of fibonacci series");
		limit=sc.nextInt(); //10
		
		System.out.print(fib1+" "+fib2+" "); //0 1
		
		count=2;
		do
		{
			fib3=fib1+fib2; //fib3=0+1=1 fib3=1+1=2
			System.out.print(fib3+" "); //1 2
			fib1=fib2; //fib1
			fib2=fib3; //fib2=1
			count++;
		}while(count<limit);
	}

}

package Controlstatements.looping.whileloop;
import java.util.*;
public class Sumofnegandpos 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n,num,psum=0,nsum=0,i;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
		i=1;
		while(i<=n)
		{
			System.out.println("Enter the number");
			num=sc.nextInt();
			
			if(num>0)
				psum=psum+num;
			else
				nsum=nsum+num;
			i++;
		}
		System.out.println("Sum of positive numbers="+psum);
		System.out.println("Sum of negative numbers="+nsum);
	}

}

package Controlstatements.looping.whileloop;
import java.util.*;
public class Soduntilsingledigit {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int n,rem,sum=0;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt(); //3456
		
		while(n>0 || sum>9) //3456>0 || 0>9
		{
			if(n==0)
			{
				n=sum; //n=18
				sum=0; //sum=0
			}
			rem=n%10;//rem=6
			sum=sum+rem; //sum=0+6=6
			n=n/10; //n=345
		}
		System.out.println(sum);
	}

}

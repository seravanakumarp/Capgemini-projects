package Controlstatements.looping.whileloop;
import java.util.*;
public class Sumofoddnumbers {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int i,n,sum=0;
		
		System.out.println("enter the value of n");
		n=sc.nextInt();
		
		i=1;
		do
		{
			sum=sum+i;
			i=i+2;
		}while(i<n);
		
		System.out.println("sum of odd numbers="+sum);
	}

}

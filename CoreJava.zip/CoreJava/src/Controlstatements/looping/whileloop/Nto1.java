package Controlstatements.looping.whileloop;
import java.util.*;
public class Nto1 {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
	
		/*while(n>=1)
		{
			System.out.print(n+" ");
			n--;
		}*/
		int i=1;
		while(i<=n)
		{
			System.out.print(i+" ");
			i++;
		}
	}

}

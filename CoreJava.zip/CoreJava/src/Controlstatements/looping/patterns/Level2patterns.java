package Controlstatements.looping.patterns;
import java.util.*;
public class Level2patterns {

	public static void main(String[] args) 
	{
		 /*
		  *       *
		  *      **
		  *     ***
		  *    ****
		  *   *****
		  */
		
		//char i,j;
		
		/*for(i=1;i<=5;i++)
		{
			for(j=1;j<=5-i;j++)
				System.out.print(" ");
			for(j=1;j<=i;j++)
				System.out.print("*");
			System.out.println("");
		}*/
		
		/*      A
		 *     BB
		 *    CCC
		 *   DDDD
		 *  EEEEE
		 *   
		 */
		
		/*for(i='A';i<='E';i++)
		{
			for(j=i;j<'E';j++)
				System.out.print(" ");
			for(j='A';j<=i;j++)
				System.out.print(i);
			System.out.println("");
		}*/
		
		
		/*       A
		 *      BA
		 *     CBA
		 *    DCBA
		 *   EDCBA
		 * 
		 */
		
		/*for(i='A';i<='E';i++)
		{
			for(j=i;j<'E';j++)
				System.out.print(" ");
			for(j=i;j>='A';j--)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*       A
		 *      AB
		 *     ABC
		 *    ABCD
		 *   ABCDE
		 * 
		 */
		
		/*for(i='A';i<='E';i++)
		{
			for(j=i;j<'E';j++)
				System.out.print(" ");
			for(j='A';j<=i;j++)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*        E
		 *       DD
		 *      CCC
		 *     BBBB
		 *    AAAAA
		 * 
		 */
		
		/*for(i='E';i>='A';i--)
		{
			for(j='A';j<i;j++)
				System.out.print(" ");
			for(j='E';j>=i;j--)
				System.out.print(i);
			System.out.println("");
		}*/
		
		/*        E
		 *       DE
		 *      CDE
		 *     BCDE
		 *    ABCDE
		 * 
		 */
		
		/*for(i='E';i>='A';i--)
		{
			for(j='A';j<i;j++)
				System.out.print(" ");
			for(j=i;j<='E';j++)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*
		 *       E
		 *      ED
		 *     EDC
		 *    EDCB
		 *   EDCBA
		 */
		
		/*for(i='E';i>='A';i--)
		{
			for(j='A';j<i;j++)
				System.out.print(" ");
			for(j='E';j>=i;j--)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*        1
		 *       22
		 *      333
		 *     4444
		 *    55555
		 */
		
		/*int i,j;
		
		for(i=1;i<=5;i++)
		{
			for(j=1;j<=5-i;j++)
				System.out.print(" ");
			for(j=1;j<=i;j++)
				System.out.print(i);
			System.out.println("");
		}*/
		
		/*      1
		 *     12
		 *    123
		 *   1234
		 *  12345
		 * 
		 */
		
		/*for(i=1;i<=5;i++)
		{
			for(j=1;j<=5-i;j++)
				System.out.print(" ");
			for(j=1;j<=i;j++)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*      1
		 *     21
		 *    321
		 *   4321
		 *  54321
		 * 
		 */
		
		/*for(i=1;i<=5;i++)
		{
			for(j=1;j<=5-i;j++)
				System.out.print(" ");
			for(j=i;j>=1;j--)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*      5
		 *     44
		 *    333
		 *   2222
		 *  11111
		 * 
		 */
		
		/*for(i=5;i>=1;i--)
		{
			for(j=1;j<i;j++)
				System.out.print(" ");
			for(j=i;j<=5;j++)
				System.out.print(i);
			System.out.println("");
				
		}*/
		
		/*       5
		 *      45
		 *     345
		 *    2345
		 *   12345
		 *     
		 */
		
		/*for(i=5;i>=1;i--)
		{
			for(j=1;j<i;j++)
				System.out.print(" ");
			for(j=i;j<=5;j++)
				System.out.print(j);
			System.out.println("");
				
		}*/
		
		/*      5
		 *     54
		 *    543
		 *   5432
		 *  54321 
		 */
		
		/*for(i=5;i>=1;i--)
		{
			for(j=1;j<i;j++)
				System.out.print(" ");
			for(j=5;j>=i;j--)
				System.out.print(j);
			System.out.println("");
				
		}*/
		
		/*         *
		 *        * *
		 *       * * *
		 *      * * * *
		 *       * * *
		 *        * *
		 *         *
		 * 
		 */
		
		/*for(i=1;i<=4;i++)
		{
			for(j=1;j<=4-i;j++)
				System.out.print(" ");
			for(j=1;j<=i;j++)
				System.out.print("*"+" ");
			System.out.println("");
		}
		for(i=3;i>=1;i--)
		{
			for(j=1;j<=4-i;j++)
				System.out.print(" ");
			for(j=1;j<=i;j++)
				System.out.print("*"+" ");
			System.out.println("");
		}*/
		
		
		/*         1
		 *        2 2
		 *       3 3 3
		 *      4 4 4 4
		 *       3 3 3
		 *        2 2 
		 *         1
		 *             
		 */
		
		/*for(i=1;i<=4;i++)
		{
			for(j=1;j<=4-i;j++)
				System.out.print(" ");
			for(j=1;j<=i;j++)
				System.out.print(i+" ");
			System.out.println("");
		}
		for(i=3;i>=1;i--)
		{
			for(j=1;j<=4-i;j++)
				System.out.print(" ");
			for(j=1;j<=i;j++)
				System.out.print(i+" ");
			System.out.println("");
		}*/
		
		/*     4
		 *    3 3
		 *   2 2 2
		 *  1 1 1 1
		 *   2 2 2
		 *    3 3 
		 *     4
		 */
		
		/*for(i=4;i>=1;i--)
		{
			for(j=1;j<i;j++)
				System.out.print(" ");
			for(j=4;j>=i;j--)
				System.out.print(i+" ");
			System.out.println("");
		}
		for(i=2;i<=4;i++)
		{
			for(j=1;j<i;j++)
				System.out.print(" ");
			for(j=i;j<=4;j++)
				System.out.print(i+" ");
			System.out.println("");
		}*/
		
		/*         A
		 *        B B
		 *       C C C
		 *      D D D D
		 *       C C C 
		 *        B B
		 *         A
		 * 
		 */
		
		/*char i,j;
		
		for(i='A';i<='D';i++)
		{
			for(j=i;j<'D';j++)
				System.out.print(" ");
			for(j='A';j<=i;j++)
				System.out.print(i+" ");
			System.out.println("");
		}
		for(i='C';i>='A';i--)
		{
			for(j='C';j>=i;j--)
				System.out.print(" ");
			for(j='A';j<=i;j++)
				System.out.print(i+" ");
			System.out.println("");
		}*/
		
		/*            D
		 *           C C
		 *          B B B
		 *         A A A A
		 *          B B B
		 *           C C 
		 *            D
		 *        
		 */
		
		/*for(i='D';i>='A';i--)
		{
			for(j='A';j<i;j++)
				System.out.print(" ");
			for(j='D';j>=i;j--)
				System.out.print(i+" ");
			System.out.println("");
		}
		for(i='B';i<='D';i++)
		{
			for(j='A';j<i;j++)
				System.out.print(" ");
			for(j=i;j<='D';j++)
				System.out.print(i+" ");
			System.out.println("");
		}*/
		
		
		/*     1
		 *     2 3
		 *     4 5 6
		 *     7 8 9 10
		 *     11 12 13 14 15
		 * 
		 */
		
		int i,j,k=1;
		
		for(i=1;i<=5;i++)
		{
			for(j=1;j<=i;j++)
				System.out.print(k++ +" ");
			System.out.println("");
		}
		
		/*    1
		 *    10
		 *    101
		 *    1010
		 *    10101
		 */
		
		for(i=1;i<=5;i++)
		{
			for(j=1;j<=i;j++)
			{
				if(j%2==0)
					System.out.print("0");
				else
					System.out.print("1");
			}
			System.out.println("");
		}
		
		/*  0
		 *  01
		 *  010
		 *  0101
		 *  01010
		 * 
		 */
		
		for(i=1;i<=5;i++)
		{
			for(j=1;j<=i;j++)
			{
				if(j%2==1)
					System.out.print("0");
				else
					System.out.print("1");
			}
			System.out.println("");
		}
		
	/*  *****
		*   *
		*   *
		*   *
		*****
	*/
		
		for(i=1;i<=5;i++)
		{
			for(j=1;j<=5;j++)
			{
				if(i==1||i==5||j==1||j==5)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println("");
		}
		
		/*  *****
		 *  ** **
		 *  * * *
		 *  ** **
		 *  *****
		 * 
		 */
		
		
		for(i=1;i<=5;i++)
		{
			for(j=1;j<=5;j++)
			{
				if(i==1||i==5||j==1||j==5||i==j||j==5-i+1)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println("");
		}
		
		  /*     *****
		   *    *****
		   *   *****
		   *  *****
		   * *****
		   * 
		   */
		
			for(i=1;i<=5;i++)
			{
				for(j=1;j<=5-i;j++)
					System.out.print(" ");
				for(j=1;j<=5;j++)
					System.out.print("*");
				System.out.println("");
			}
		
			/*     *****
			 *      *****
			 *       *****
			 *        *****
			 *         *****
			 * 
			 */
			
			for(i=1;i<=5;i++)
			{
				for(j=1;j<i;j++)
					System.out.print(" ");
				for(j=1;j<=5;j++)
					System.out.print("*");
				System.out.println("");
			}
		
		    /*       *****
		     *      *   *
		     *     *   *
		     *    *   *
		     *   *****
		     * 
		     */
			
			for(i=1;i<=5;i++)
			{
				for(j=1;j<=5-i;j++)
					System.out.print(" ");
				for(j=1;j<=5;j++)
				{
					if(i==1||i==5||j==1||j==5)
						System.out.print("*");
					else
						System.out.print(" ");
				}
				System.out.println("");
			}
			
			/*     *****
			 *      *   *
			 *       *   *
			 *        *   *
			 *         *****
			 * 
			 */
			
			for(i=1;i<=5;i++)
			{
				for(j=1;j<i;j++)
					System.out.print(" ");
				for(j=1;j<=5;j++)
				{
					if(i==1||i==5||j==1||j==5)
						System.out.print("*");
					else
						System.out.print(" ");
				}
				System.out.println("");
			}
			
			/*         *
			 *        ***
			 *       *****
			 *      *******
			 *     *********
			 *      *******
			 *       *****
			 *        ***
			 *         *
			 * 
			 */
			
			for(i=1;i<=5;i++)
			{
				for(j=1;j<=5-i;j++)
					System.out.print(" ");
				for(j=1;j<=2*i-1;j++)
					System.out.print("*");
				System.out.println("");
			}
			for(i=4;i>=1;i--)
			{
				for(j=1;j<=5-i;j++)
					System.out.print(" ");
				for(j=1;j<=2*i-1;j++)
					System.out.print("*");
				System.out.println("");
			}
			
			/*         *
			 *         **
			 *         ***
			 *         ****
			 *         *****
			 *         ****
			 *         ***
			 *         **
			 *         *
			 * 
			 */
			
			for(i=1;i<=9;i++)
			{
				if(i<=5)
				{
					for(j=1;j<=i;j++)
						System.out.print("*");
				}
				else
				{
					for(j=i;j<=9;j++)
						System.out.print("*");
				}
				System.out.println("");
			}
			
			/*          *
			 *         **
			 *        ***
			 *       ****
			 *      *****
			 *       ****
			 *        ***
			 *         **
			 *          *
			 * 
			 */
			
			for(i=1;i<=9;i++)
			{
				if(i<=5)
				{
					for(j=i;j<5;j++)
						System.out.print(" ");
					for(j=1;j<=i;j++)
						System.out.print("*");
				}
				else
				{
					for(j=i;j>5;j--)
						System.out.print(" ");
					for(j=i;j<=9;j++)
						System.out.print("*");
				}
				System.out.println("");
			}
			
			/*      *****
			 *      ****
			 *      ***
			 *      **
			 *      *
			 *      **
			 *      ***
			 *      ****
			 *      *****
			 *  
			 */
			
			for(i=1;i<=9;i++)
			{
				if(i<=5)
				{
					for(j=i;j<=5;j++)
						System.out.print("*");
				}
				else
				{
					for(j=i;j>=5;j--)
						System.out.print("*");
				}
				System.out.println("");
			}
			
			/*       *
			 *      * *
			 *     *   *
			 *    *     *
			 *   *********
			 * 
			 */
			
			for(i=1;i<=5;i++)
			{
				for(j=1;j<=5-i;j++)
					System.out.print(" ");
				for(j=1;j<=2*i-1;j++)
				{
					if(j==1||i==1||i==5||j==2*i-1)
						System.out.print("*");
					else
						System.out.print(" ");
				}
				System.out.println("");
			}
			
			/*         1
			 *        1 1
			 *       1 2 1
			 *      1 3 3 1
			 *     1 4 6 4 1
			 * 
			 */
			  int c=0;
			  for(i=0;i<5;i++) //i=1 i=2 i=3 i=4
			  {
				  for(j=1;j<5-i;j++)
					  System.out.print(" ");
				  for(j=0;j<=i;j++) //0<=1 1<=1 2<=1 0<=2 1<=2 2<=2 0<=3 1<=3 2<=3  3<=3 
				  {                 //0<=4 1<=4 2<=4 3<=4 4<=4
					  if(i==0||j==0) 
					  {
						 c=1; //c=1 c=1
					  }//c=1
					  else
					  {
						  c=c*(i-j+1)/j; //c=1 c=2 c=1 c=3 c=3 c=1 c=4 c=6 c=4 c=1
					  }
				      System.out.print(c+" "); //1 1 1 1 2 1 1 3 3 1 1 4 6 4 1
						  
				  }
				  System.out.println("");
			  }
	}

}

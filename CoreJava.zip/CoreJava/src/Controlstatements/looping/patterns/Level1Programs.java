/*
 *           *****
 *           *****
 *           *****
 *           *****
 *           *****
 */
package Controlstatements.looping.patterns;
import java.util.*;
public class Level1Programs {

	public static void main(String[] args) 
	{
		char i,j;
		
		/*for(i=1;i<=5;i++) //1<=5 2<=5 3<=5 4<=5 5<=5
		{
			for(j=1;j<=5;j++) //1<=5 2<=5 3<=5 4<=5 5<=5 6<=5
				System.out.print("*"); //***** ***** ***** ***** *****
			System.out.println("");
			
		}*/
		
		/*
		 *    11111
		 *    22222
		 *    33333
		 *    44444
		 *    55555
		 */
		
		/*for(i=1;i<=5;i++) //1<=5 2<=5 3<=5 4<=5 5<=5
		{
			for(j=1;j<=5;j++) //1<=5 2<=5 3<=5 4<=5 5<=5 6<=5
				System.out.print(i); //***** ***** ***** ***** *****
			System.out.println("");
			
		}*/
		
		/*   12345
		 *   12345
		 *   12345
		 *   12345
		 *   12345
		 *       
		 * 
		 */
		
		/*for(i=1;i<=5;i++) //1<=5 2<=5 3<=5 4<=5 5<=5
		{
			for(j=1;j<=5;j++) //1<=5 2<=5 3<=5 4<=5 5<=5 6<=5
				System.out.print(j); //***** ***** ***** ***** *****
			System.out.println("");
		}*/
		
		/*   55555
		 * 	 44444
		 *   33333
		 *   22222
		 *   11111
		 *  
		 */
		
		/*for(i=5;i>=1;i--)
		{
			for(j=1;j<=5;j++)
				System.out.print(i);
			System.out.println("");
		}*/
		
		/*
		 *    54321
		 *    54321
		 *    54321
		 *    54321
		 *    54321
		 */
		
		/*for(i=5;i>=1;i--)
		{
			for(j=5;j>=1;j--)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*
		 *    AAAAA
		 *    BBBBB
		 *    CCCCC
		 *    DDDDD
		 *    EEEEE
		 */
		
		
		/*for(i='A';i<='E';i++)
		{
			for(j='A';j<='E';j++)
				System.out.print(i);
			System.out.println("");
		}*/
		
		/*int k,l;
		
		for(k=65;k<=69;k++)
		{
			for(l=65;l<=69;l++)
				System.out.print((char)k);
			System.out.println("");
		}*/
		
		/*
		 *    ABCDE
		 *    ABCDE
		 *    ABCDE
		 *    ABCDE
		 *    ABCDE
		 */
		
		/*for(i='A';i<='E';i++)
		{
			for(j='A';j<='E';j++)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*   EEEEE
		 *   DDDDD
		 *   CCCCC
		 *   BBBBB
		 *   AAAAA
		 *  
		 */
		
		/*for(i='E';i>='A';i--)
		{
			for(j='A';j<='E';j++)
				System.out.print(i);
			System.out.println("");
		}*/
		
		/*   EDCBA
		 *   EDCBA
		 *   EDCBA
		 *   EDCBA
		 *   EDCBA
		 * 
		 */
		
		for(i='E';i>='A';i--)
		{
			for(j='E';j>='A';j--)
				System.out.print(j);
			System.out.println("");
		}
		
		
		/*   ZYXWV
		 *   ZYXWV
		 *   ZYXWV
		 *   ZYXWV
		 *   ZYXWV
		 */
		
		/*for(i='Z';i>='V';i--)
		{
			for(j='Z';j>='V';j--)
				System.out.print(j);
			System.out.println("");
		}*/
		
		/*
		 *       *
		 *       **
		 *       ***
		 *       ****
		 *       *****
		 */
		
		/*for(i=1;i<=5;i++) //1<=5 2<=5 3<=5 4<=5 5<=5
		{ 
			for(j=1;j<=i;j++) //j=1 1<=1 2<=1 1<=2 1<=3 1<=4 1<=5
				System.out.print("*"); //* ** *** **** *****
			System.out.println("");
		}*/
		
		
		/*for(i=1;i<=5;i++) //1<=5 2<=5 3<=5 4<=5 5<=5
		{ 
			for(j=1;j<=i;j++) //j=1 1<=1 2<=1 1<=2 1<=3 1<=4 1<=5
				System.out.print("#"); //* ** *** **** *****
			System.out.println("");
		}*/
		
		/*     1
		 * 	   22
		 *     333
		 *     4444
		 *     55555
		 *  
		 */
		
		/*for(i=1;i<=5;i++) //1<=5 2<=5 3<=5 4<=5 5<=5
		{ 
			for(j=1;j<=i;j++) //j=1 1<=1 2<=1 1<=2 1<=3 1<=4 1<=5
				System.out.print(i); //1 22 333 4444 55555
			System.out.println("");
		}*/
		
		/*
		 *   1
		 *   12
		 *   123
		 *   1234
		 *   12345
		 */
		
		/*for(i=1;i<=5;i++) //1<=5 2<=5 3<=5 4<=5 5<=5
		{ 
			for(j=1;j<=i;j++) //j=1 1<=1 2<=1 1<=2 1<=3 1<=4 1<=5
				System.out.print(j); //* ** *** **** *****
			System.out.println("");
		}*/
		
		/*    5
		 *    54
		 *    543
		 *    5432
		 *    54321
		 * 
		 */
		
		/*for(i=5;i>=1;i--)
		{
			for(j=5;j>=i;j--)
				System.out.print(j); //5 54 543 5432 54321
			System.out.println("");
		}*/
		
		/*      5
		 *      44
		 *      333
		 *      2222
		 *      11111
		 * 
		 */
		
		/*for(i=5;i>=1;i--)
		{
			for(j=5;j>=i;j--)
				System.out.print(i); 
			System.out.println("");
		}*/
		
		/*    A
		 *    AB
		 *    ABC
		 *    ABCD
		 *    ABCDE
		 *   
		 */
		
		for(i='A';i<='E';i++)
		{
			for(j='A';j<=i;j++)
				System.out.print(j);
			System.out.println("");
		}
		
		/*     A
		 *     BB
		 *     CCC
		 *     DDDD
		 *     EEEEE
		 */
		
		for(i='A';i<='E';i++)
		{
			for(j='A';j<=i;j++)
				System.out.print(i);
			System.out.println("");
		}
		
		
		/*      E
		 *      DD
		 *      CCC
		 *      BBBB
		 *      AAAAA
		 *  
		 */
		
		for(i='E';i>='A';i--)
		{
			for(j='E';j>=i;j--)
				System.out.print(i); //E DD CCC BBBB AAAAA
			System.out.println("");
		}
		
		/*
		 *   E
		 *   ED
		 *   EDC
		 *   EDCB
		 *   EDCBA
		 */
		for(i='E';i>='A';i--)
		{
			for(j='E';j>=i;j--)
				System.out.print(j);
			System.out.println("");
		}
		
		/*  EDCBA
		 *  EDCB
		 *  EDC
		 *  ED
		 *  E
		 * 
		 */
		
		for(i='A';i<='E';i++)
		{
			for(j='E';j>=i;j--)
				System.out.print(j);
			System.out.println("");
		}
		
		
		/*   EDCBA
		 *   DCBA
		 *   CBA
		 *   BA
		 *   A
		 * 
		 */
		
		for(i='E';i>='A';i--)
		{
			for(j=i;j>='A';j--)
				System.out.print(j);
			System.out.println("");
				
		}
		
		/*
		 *    A
		 *    BA
		 *    CBA
		 *    DCBA
		 *    EDCBA
		 */
		
		for(i='A';i<='E';i++)
		{
			for(j=i;j>='A';j--)
				System.out.print(j); //A BA CBA DCBA EDCBA
			System.out.println("");
		}
		
		/*     ABCDE
		 *     ABCD
		 *     ABC
		 *     AB
		 *     A
		 * 
		 */
		
		for(i='E';i>='A';i--)
		{
			for(j='A';j<=i;j++)
				System.out.print(j);
			System.out.println("");
		}
		
		/*     ABCDE
		 *     BCDE
		 *     CDE
		 *     DE
		 *     E
		 * 
		 */
		
		for(i='A';i<='E';i++)
		{
			for(j=i;j<='E';j++)
				System.out.print(j);
			System.out.println("");
		}
		
		/*     E
		 *     DE
		 *     CDE
		 *     BCDE
		 *     ABCDE
		 * 
		 */
		
		for(i='E';i>='A';i--)
		{
			for(j=i;j<='E';j++)
				System.out.print(j);
			System.out.println("");
		}
	}

}

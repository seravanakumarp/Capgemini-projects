package Controlstatements.looping.patterns;
import java.util.*;
public class Level3Patterns {

	public static void main(String[] args) 
	{
		/*       1
		 *      232
		 *     34543
		 *    4567654
		 *   567898765
		 * 
		 */
		
		int i,j,k=1,p;
		
		for(i=1;i<=5;i++) //i=2 i=3
		{
			for(j=1;j<=5-i;j++)
				System.out.print(" ");
			for(j=1;j<=i;j++) //j=1 1<=3 2<=3 3<=3 4<=3
				System.out.print(k++); //1 23 345 
			for(j=i;j>1;j--) //j=3 3>1 2>1 1>=1
			{
				p=k-2; //4-2=2 p=6-2=4 p=5-2=3
				k=k-1; //k=3 k=5 k=4
				
				System.out.print(p);//p=2 43
			}
			System.out.println("");
			
		}
		
		/*       1
		 *      121
		 *     12321
		 *    1234321
		 *   123454321
		 * 
		 */
		
		for(i=1;i<=5;i++)
		{
			for(j=1;j<=5-i;j++)
				System.out.print(" ");
			for(j=1;j<=i;j++)
				System.out.print(j);
			for(j=i-1;j>0;j--)
				System.out.print(j); //21 321 4321
			
			System.out.println("");
		}
		
		/*
		 *         1
		 *        212
		 *       32123
		 *      4321234
		 *     543212345
		 */
		
		for(i=1;i<=5;i++)
		{
			for(j=1;j<=5-i;j++)
				System.out.print(" ");
			for(j=i;j>=1;j--)
				System.out.print(j);
			for(j=2;j<=i;j++)
				System.out.print(j);
			System.out.println("");
		}
		
	}

}

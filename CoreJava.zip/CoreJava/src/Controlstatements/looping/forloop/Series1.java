package Controlstatements.looping.forloop;
import java.util.*;
public class Series1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		int i,n,sum=0;
		
		System.out.println("Enter the number of terms");
		n=sc.nextInt();
		
		for(i=1;i<=n;i++)
		{
			sum=sum+i*(i+1); //0+1*(2)+2*(3)+3*(4)
		}
		System.out.println(sum);
	}

}

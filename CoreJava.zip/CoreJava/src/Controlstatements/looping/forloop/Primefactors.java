package Controlstatements.looping.forloop;
import java.util.*;
public class Primefactors 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n,i;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt(); //56
		
		for(i=2;i<=n;i++) //3<=7 //4<=7 //5<=7 //6<=7 7<7
		{
			while(n%i==0) //28%2 14%2 7%3 7%4 7%5 7%6
			{
				System.out.print(i+" "); //2 2 2 7
				n=n/i; //28 14 7 
			}
		}
		/*if(n>2)
			System.out.print(n);*/
		
	}

}

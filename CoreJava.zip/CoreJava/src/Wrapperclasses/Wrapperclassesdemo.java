/*
 * Is java a full object oriented programming language?
 * No, it supports both primitives types as well as reference types.
 * 
 * Which languages are fully object oriented programming languages?
 * 				   Ruby, Smalltalk
 * To make an application as fully object oriented base, we need to 
 * convert the primitive types to an reference type.
 * 
 * Wrapping is a mechanism which converts a primitive type to an object
 * and object to a primitive type.
 * 
 * To achieve the wrapping mechanism, java do supports of wrapper classes
 * for converting primitive to objects.
 * 
 * List of Wrapper classes w.r.t the primitive type are as follows:
 * 
 * 				Primitive types                  Wrapper classes
 * 				   int                                Integer
 * 	               float                              Float
 * 				   char                               Character
 *                 double                             Double
 *                 long                               Long
 *                 short                              Short
 *                 byte                               Byte
 *                 boolean                            Boolean
 *                 
 *                          Object(Super class)
 *                     |               |          | 
 *                  Numbers          Character   Boolean
 *                    |-> Integer
 *                    |-> Float
 *                    |-> Double
 *                    |-> Long
 *                    |-> Short
 *                    |-> Byte     
 *                          
 * Conversions w.r.t Wrapper classes:
 * 1. primitive to Object (Boxing)
 * 2. Object to primitive (Unboxing)
 * 3. primitive to String
 * 4. String to primitive
 * 5. String to Object
 * 6. Object to String
 * 
 */
package Wrapperclasses;

public class Wrapperclassesdemo {

	public static void main(String[] args) 
	{
		//primitive to Object(Boxing)
		
		byte x=100;
		Byte b=Byte.valueOf(x);
		
		System.out.println(b);
		
		//Object to primitive (Unboxing)
		
		byte y=b.byteValue();
		
		System.out.println(y);
		
		//primitive to String
		
		int i=200;
		String s=Integer.toString(i);
		
		System.out.println(s);
		
		// String to primitive
		
		String s1="2345";
		int j=Integer.parseInt(s1);
		
		System.out.println(j);
		
		// String to Object
		
		String s2="123";
		Byte b2=Byte.valueOf(s2);
		
		System.out.println(b2);
		
		//Object to String
		
		Integer p=234;
		String s3=Integer.toString(p);
		
		System.out.println(s3);
		
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.SIZE);
		System.out.println(Integer.BYTES);
		
		System.out.println(Float.MIN_VALUE);
		System.out.println(Float.MAX_VALUE);
		System.out.println(Float.SIZE);
		System.out.println(Float.BYTES);
		
		
		
	}

}

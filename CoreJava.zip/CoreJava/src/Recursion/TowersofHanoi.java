package Recursion;
import java.util.*;
public class TowersofHanoi {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n;
		
		System.out.println("Enter the number of discs");
		n=sc.nextInt();
		
		toh(n,1,2,3);
	
	}
	public static void toh(int n,int A,int B,int C)
	{
		if(n!=0)
		{
			toh(n-1,A,C,B);
			System.out.println("Move disc from"+A+"to"+C);
			toh(n-1,B,A,C);
		}
	}

}

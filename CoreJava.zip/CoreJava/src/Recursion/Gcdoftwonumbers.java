package Recursion;
import java.util.*;
public class Gcdoftwonumbers {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int a,b,result;
		
		System.out.println("Enter the values of a and b");
		a=sc.nextInt(); //24
		b=sc.nextInt(); //36
		
		result=gcd_of_two(a,b);
		
		System.out.println(result);
	}
	public static int gcd_of_two(int x,int y) //gcd(24,12) gcd(0,12)
	{
		if(x==0) return y; //return 12;
		if(y==0) return x;
		
		if(x>y) //24>36 24>12
			return gcd_of_two(x%y, y); //gcd(0,12)
		else
			return gcd_of_two(x, y%x); //gcd(24,12)
	}

}

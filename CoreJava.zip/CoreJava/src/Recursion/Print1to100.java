package Recursion;
import java.util.*;
public class Print1to100 {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int a,b;
		
		System.out.println("Enter the values of a and b");
		a=sc.nextInt();
		b=sc.nextInt();
		
		print_1_to_100(a,b);
		
	}
	public static void print_1_to_100(int x,int y)
	{
		if(x<=y)
		{
			System.out.print(x+" ");
			print_1_to_100(x+1, y);
		}
	
			
	}

}

package Recursion;

import java.util.Scanner;

public class Decimaltobinary {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n,result;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt(); //15
		
		result=Dec_to_bin(n); //15
		
		System.out.println(result);
	
	}
	
	public static int Dec_to_bin(int n)
	{
		if(n!=0) //1111!=0
			return (n%2+10*Dec_to_bin(n/2));
		else
			return 0;
	}

}

package Recursion;
import java.util.*;
public class Reverse {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
		reverse_number(n);
	}
	public static void reverse_number(int n) //12 1 0
	{
		if(n!=0) //12!=0 1!=0 0!=0
		{
			System.out.print(n%10); //123%10=3 12%10=2 1%10=1
			reverse_number(n/10); //123/10=12 12/10=1 1/10=0
		}
	}

}

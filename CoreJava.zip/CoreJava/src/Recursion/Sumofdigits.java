package Recursion;
import java.util.*;
public class Sumofdigits {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n,result;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
		result=sum_of_n(n);
		
		System.out.println("sum of digits of given number="+result);
		
	}
	public static int sum_of_n(int n)
	{
		if(n!=0)
			return(n%10+sum_of_n(n/10));
		else
			return 0;
	}

}

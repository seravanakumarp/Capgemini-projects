package Recursion;
import java.util.*;
public class Binarytodecimal 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int n,result;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt(); //1111
		
		result=bin_to_dec(n); //1111
		
		System.out.println(result);
	
	}
	
	public static int bin_to_dec(int n)
	{
		if(n!=0) //1111!=0
			return (n%10+2*bin_to_dec(n/10));
		else
			return 0;
	}

}

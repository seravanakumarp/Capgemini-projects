package Typecasting;
class Animal {
    void makeSound() {
        System.out.println("Some sound");
    }
}

class Dog extends Animal {
    void makeSound() {
        System.out.println("Bark");
    }
    
    void fetch() {
        System.out.println("Fetching the ball");
    }
}

public class TypecastingEx1 {

	public static void main(String[] args) 
	{
		//upcasting
		Animal animal = new Dog(); 
		
        // Downcasting
        Dog dog = (Dog) animal; // Explicit downcast
        dog.fetch(); 
        
        // Example of an invalid downcast
        Animal anotherAnimal = new Animal();
        Dog anotherDog = (Dog) anotherAnimal; 
        // This will throw ClassCastException
	}

}

/*
 * Typecasting with respect to reference types:
 *-> It is a process of converting an object of one reference type to
 *an another reference type, when they are compatible.
 *
 *The reference types are said to be compatible, if their corresponding
 *classes are in IS-A Relationship.
 *
 *Upcasting: If the child class object is referred by an parent class
 *reference variable, then it is called upcasting.
 *
 *				Syntax: Parent p=(Parent)new Child();
 *In the case of upcasting, no explicit typecasting is required. 
 *
 *Downcasting: If the parent class object is referred by a child class
 *reference variable, then it is called as downcasting.
 *
 *In the case of downcasting, explicit typecasting is mandatory.
 *
 *				Syntax:  Child c=(Child)new Parent();
 * 
 */
package Typecasting;
class Parent1
{
	public void show()
	{
		System.out.println("show method of parent class");
	}
	public void display()
	{
		System.out.println("display method of parent class");
	}
}
class Child1 extends Parent1
{
	public void show()
	{
		System.out.println("show method of child class");
	}
	public void print()
	{
		System.out.println("print method of child class");
	}
}
public class Typecasting {

	public static void main(String[] args) 
	{
		Parent1 p=new Parent1();
		p.show();
		p.display();
		
		Child1 c=new Child1();
		c.show();
		c.display();
		c.print();
		
		//upcasting
		Parent1 p1=new Child1();
		p1.display();
		p1.show();
		
		/*  Object o=new Object();
		 *  Object o1=new Employee();
		 *  Object o2=new Customer();
		 *  Object o3=new String();
		 * 
		 */
	
		//downcasting
		//Child1 c1=(Child1)new Parent1();
		
		Parent1 p11=new Child1();
		Child1 c11=(Child1)p11;
		
		c11.display();
		c11.show();
		c11.print();
		
	}

}

package IOstreams;
import java.io.*;
import java.io.File;
import java.io.IOException;

public class FileMethods{
    public static void main(String[] args) {
        // Create a File object
        File file = new File("C:/Users/sekumarp/Documents/PYTHON/decorator4.txt");

		 // Create the file if it doesn't exist

        try {
            // Create a new file
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        // Check if file exists
        System.out.println("Exists: " + file.exists());

        // Get file path
        System.out.println("Path: " + file.getPath());

        // Get absolute path
        System.out.println("Absolute Path: " + file.getAbsolutePath());

        // Check if it is a file or directory
        System.out.println("Is File: " + file.isFile());
        System.out.println("Is Directory: " + file.isDirectory());

        // Get file size
        System.out.println("File Size (bytes): " + file.length());

        // Rename file
        File newFile = new File("C:/Users/sekumarp/Documents/PYTHON/decorator12.txt");
        if (file.renameTo(newFile)) {
            System.out.println("File renamed to: " + newFile.getName());
        } else {
            System.out.println("Rename failed.");
        }

         //Delete file
        if (newFile.delete()) {
            System.out.println("File deleted.");
        } else {
            System.out.println("Delete failed.");
        }
    }
}
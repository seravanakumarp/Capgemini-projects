package IOstreams;
import java.io.*;
public class ReadWriteByteStream
{
	public static void main(String[] args) throws IOException
	{
		FileInputStream fis=null;
		FileOutputStream fos=null;
		
		try
		{
			fis=new FileInputStream("C:/Users/sekumarp/Documents/PYTHON/decorator4.txt");
			fos=new FileOutputStream("C:/Users/sekumarp/Documents/PYTHON/decorator2.txt",false);
			
			int ch;
			
			while((ch=fis.read())!=-1)
			{
				fos.write(ch);
			}
			System.out.println("file copied successfully");
		}
		finally
		{
			if(fis!=null)
				fis.close();
			if(fos!=null)
				fos.close();
		}
	}

}

package IOstreams;
import java.io.*;
public class Datastreams {

	public static void main(String[] args) throws IOException
	{
		String name="sachin";
		int roll=124;
		try
		{
			FileOutputStream fos=new FileOutputStream("C:/Users/sekumarp/Documents/PYTHON/decorator1.txt");
			DataOutputStream dos=new DataOutputStream(fos);
			dos.writeInt(roll);
			dos.writeUTF(name);
			
			dos.close();
			FileInputStream fis=new FileInputStream("C:/Users/sekumarp/Documents/PYTHON/decorator1.txt");
			DataInputStream dis=new DataInputStream(fis);
			
			int rollno=dis.readInt();
			String nm=dis.readUTF();
			
			System.out.println(rollno+" "+nm);
			dis.close();
		}
		catch(FileNotFoundException fne)
		{
			System.out.println(fne.getMessage());
		}
			}

}

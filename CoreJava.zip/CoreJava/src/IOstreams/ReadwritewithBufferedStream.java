package IOstreams;
import java.io.*;
public class ReadwritewithBufferedStream 
{
	public static void main(String[] args) throws Exception
	{
		FileReader fr=null;
		FileWriter fw=null;
		BufferedWriter bw=null;
		
		try
		{
			fr=new FileReader("C:/Users/sekumarp/Documents/PYTHON/decorator1.txt");
			fw=new FileWriter("C:/Users/sekumarp/Documents/PYTHON/decorator11.txt");
			bw=new BufferedWriter(fw);
			
			int ch;
			
			while((ch=fr.read())!=-1)
			{
				bw.write(ch);
			}
			System.out.println("read write done successfully");
		}
		finally
		{
		if(bw!=null)
			bw.close();
		if(fr!=null)
			fr.close();
		if(fw!=null)
			fw.close();
		}
	}

}

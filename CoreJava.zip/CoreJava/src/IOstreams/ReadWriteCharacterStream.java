package IOstreams;
import java.io.*;
public class ReadWriteCharacterStream 
{
	public static void main(String[] args) throws IOException
	{
		FileReader fr=null;
		FileWriter fw=null;
		
		try
		{
			fr=new FileReader("C:/Users/sekumarp/Documents/PYTHON/decorator1.txt");
			fw=new FileWriter("C:/Users/sekumarp/Documents/PYTHON/decorator4.txt",false);
			
			int ch;
			
			while((ch=fr.read())!=-1)
			{
				fw.write(ch);
			}
			System.out.println("file written successfully");
		}
		finally
		{
			if(fr!=null)
				fr.close();
			if(fw!=null)
				fw.close();
		}
		
	}

}

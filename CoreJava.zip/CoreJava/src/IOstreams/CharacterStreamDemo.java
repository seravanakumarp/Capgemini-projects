package IOstreams;
import java.io.*;
public class CharacterStreamDemo {

	public static void main(String[] args) throws IOException
	{
		FileReader fr=null;
		FileWriter fw=null;
		try
		{
			fr=new FileReader("C:/Users/sekumarp/Documents/PYTHON/decorator1.txt");
			fw=new FileWriter("C:/Users/sekumarp/Documents/PYTHON/decorator3.txt",true);
			int ch;
			while((ch=fr.read())!=-1)
				fw.write((char)ch);
		}
		catch(FileNotFoundException fne)
		{
			System.out.println(fne.getMessage());
		}
		finally
		{
			if(fr!=null)
			{
				fr.close();
			}
			if(fw!=null)
			{
				fw.close();
			}
		}

	}

}

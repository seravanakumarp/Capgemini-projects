package IOstreams;
import java.io.*;
public class FileExists
{
	public static void main(String[] args) throws Exception
	{
		File f=new File("C:/Users/sekumarp/Documents/PYTHON/decorator300.txt");
		
		if(f.exists())
			System.out.println("file is present");
		else
		{
			f.createNewFile();
			System.out.println("file created successfully");
		}
	}

}

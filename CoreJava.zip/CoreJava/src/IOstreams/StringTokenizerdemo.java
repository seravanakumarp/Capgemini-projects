/*
 * String Tokenizer class:
 * 1. It is a class belongs to util package.
 * 2. It is introduced in the version 1.0.
 * 3. It is used to convert a given string into tokens.
 * 
 * Methods:
 * 
 * 1. boolean hasMoreTokens():
 *       - Returns true if there is a token available.
 *       - Returns false if there is no token
 * 2. Object nextToken():
 *       _ Return the token in the form of an object.
 * 3. boolean hasMoreElements():
 *       - It is similar to hasMoreTokens()
 * 4. Object nextElement():
 *       - It is similar to nextToken()
 * 5. int countTokens():
 *       - It is used to count number of tokens in a given string.
 *       
 */
package IOstreams;
import java.util.*;
public class StringTokenizerdemo {

	public static void main(String[] args)
	{
		StringTokenizer st=new StringTokenizer("weclome to Qedge tech");
		
		System.out.println(st.countTokens());
		while(st.hasMoreTokens())
		{
			System.out.println(st.nextToken());
		}
		
		StringTokenizer st1=new StringTokenizer("welcome,to,java,full,stack,program",",");
		
		System.out.println(st1.countTokens());
		
		while(st1.hasMoreElements())
		{
			System.out.println(st1.nextElement());
		}
	}

}

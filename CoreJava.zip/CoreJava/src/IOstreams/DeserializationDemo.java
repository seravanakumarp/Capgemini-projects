package IOstreams;
import java.io.*;

public class DeserializationDemo
{

	public static void main(String[] args) throws Exception
	{
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		try
		{
			fis=new FileInputStream("C:/Users/sekumarp/Documents/PYTHON/Emp.ser");
			ois=new ObjectInputStream(fis);
			
			Employee e=(Employee)ois.readObject();
			
			System.out.println(e.empno+" "+e.name+" "+e.salary+" "+e.SSN);
		}
		catch(IOException io)
		{
			System.out.println(io.getMessage());
		}
		finally
		{
			if(fis!=null)
				fis.close();
			if(ois!=null)
				ois.close();
		}
	}

}

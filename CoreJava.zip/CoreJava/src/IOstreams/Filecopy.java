package IOstreams;
import java.io.*;
public class Filecopy {

	public static void main(String[] args) throws Exception
	{
		File inputfile=new File("D:/string.java");
		File outputfile=new File("D:/stringnew.java");
		
		FileReader in=new FileReader(inputfile);
		FileWriter out=new FileWriter(outputfile);
		int c;
		while((c=in.read())!=-1)
		{
			out.write(c);
		}
		in.close();
		out.close();
	}

}

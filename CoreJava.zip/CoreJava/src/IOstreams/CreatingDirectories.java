package IOstreams;
import java.io.*;
public class CreatingDirectories 
{
	public static void main(String[] args) 
	{
		String s1="C:/Users/sekumarp/Documents/test1";
		String s2="C:/Users/sekumarp/Documents/test2/test3/test4";
		
		File d1=new File(s1);
		File d2=new File(s2);
		
		if(d1.mkdir())
			System.out.println(s1+"created");
		if(d2.mkdirs())
			System.out.println(s2+"created");
	}

}

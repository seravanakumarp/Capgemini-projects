package IOstreams;
import java.io.*;
public class ReadCharacterstream {

	public static void main(String[] args) throws IOException
	{
			FileReader fr=null;
			try
			{
				fr=new FileReader("D:/sample.java");
				
				int ch;
				while((ch=fr.read())!=-1)
				{
					System.out.print((char)ch);
				}
				
				System.out.println("file read successfully");
			}
			finally
			{
				if(fr!=null)
					fr.close();
			}
	}

}

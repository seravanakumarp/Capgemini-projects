package IOstreams;
import java.io.*;
public class ReadoperationwithBufferedStream 
{

	public static void main(String[] args) throws Exception 
	{
		FileReader fr=null;
		BufferedReader br=null;
		
		try
		{
			fr=new FileReader("D:/sample1000.java");
			br=new BufferedReader(fr);
			
			String str;
			
			while((str=br.readLine())!=null)
			{
				System.out.println(str);
			}
		}
		finally
		{
			if(br!=null)
				br.close();
			if(fr!=null)
				fr.close();
		}
	}

}

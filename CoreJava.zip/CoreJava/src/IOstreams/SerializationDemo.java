package IOstreams;
import java.io.*;
class Employee implements Serializable
{
	int empno;
	String name;
	float salary;
	transient int SSN;
	public Employee(int empno, String name, float salary, int sSN) {
		this.empno = empno;
		this.name = name;
		this.salary = salary;
		SSN = sSN;
	}
	
}
public class SerializationDemo 
{

	public static void main(String[] args)throws IOException
	{
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		
		Employee e=new Employee(1234,"sachin",45000,34324234);
		
		System.out.println(e.empno+" "+e.name+" "+e.salary+" "+e.SSN);
		try
		{
			fos=new FileOutputStream("C:/Users/sekumarp/Documents/PYTHON/Emp.ser");
			oos=new ObjectOutputStream(fos);
			oos.writeObject((Object)e);
			System.out.println("task completed");
		}
		catch(IOException io)
		{
			System.out.println(io.getMessage());
		}
		finally
		{
			if(fos!=null)
			{
				fos.close();
			}
			if(oos!=null)
			{
				oos.close();
			}
		}
	}

}

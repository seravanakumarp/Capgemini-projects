/*
 * Method overloading can happen with instance methods, static methods
 * as well as main method.
 */
package Polymorphism;
class Sample11
{
	public static void display(int x,int y)
	{
		System.out.println("product="+(x*y));
	}
	public static void display(int x,float y)
	{
		System.out.println("division="+(x/y));
	}
}
public class Methodoverloadingwithstatic {

	public static void main(String[] args) 
	{
			Sample11 s=new Sample11();
			s.display(10,20);
			s.display(10,20.0f);
			

	}

}

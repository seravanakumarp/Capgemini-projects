package Polymorphism;
class Test12
{
	public static void main(String args[])
	{
		int i;
		for(i=0;i<args.length;i++)
			System.out.print(args[i]+" ");
	}
	public static void main(int args[])
	{
		int i;
		for(i=0;i<args.length;i++)
			System.out.print(args[i]+" ");
		
	}
	public static void main(String args)
	{
		System.out.println(args);
	}
	public static void main(int args)
	{
		System.out.println(args);
	}
}
public class Methooverloadingwithmain {

	public static void main(String[] args) 
	{
		Test12 t=new Test12();
		t.main(new String[] {"sachin","rahul","kapil","dhoni","yuvraj"});
		t.main(new int[] {10,20,30,40,50});
		t.main("sachin");
		t.main(20);
		

	}

}

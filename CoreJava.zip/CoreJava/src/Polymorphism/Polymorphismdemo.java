/*
 * Polymorphism:
 * ->An entity which exhibits multiple forms or multiple behavior is called
 *   polymorphism.
 * -> A polymorphism provides the flexibility to the user in terms of 
 * performing different operations based on the requirement.
 * 
 * Two types of Polymorphism:
 * 1. Compile Time Polymorphism
 * 2. Run time Polymorphism
 * 
 * 
 * Compile Time Polymorphism:
 *-> The polymorphic nature of an entity which is decided by the compiler
 *during the compilation time is called compile time polymorphism.
 *
 *-> This compile time polymorphism can be achieved by means of approach
 * called method overloading.
 * 
 *  Method Overloading:
 *  It is process of having multiple methods with different method signature
 *  having the same method name.
 *  
 *  Method signature:
 *  It contains majorly four parts:
 *  1. Method name
 *  2. Number of parameters
 *  3. Type of parameters
 *  4. Order of parameters
 *  
 * -> A class can contain any number of methods with different signature.
 *  -> No two methods of a class can contains same method signature.
 * -> Methods which participate in method overloading are called as
 * overloaded methods.
 * -> In method signature we don't consider the name of the parameter
 * and return type of method.
 * 
 * -> In method overloading, the compiler will link or bind the method
 * invocation with the method definition.  Once the link or binding is
 * done with respect to the method signature, it cannot be altered.
 * Hence is treated as static binding.
 * 
 * -> since the binding is done before the execution of a program, it is
 * also called as early binding.
 
 * 
 * 
 * 
 * 
 * 
 */
package Polymorphism;
class Test11
{
	public void show(int x)
	{
		System.out.println("value of x="+x);
	}
	public void show(int x,int y)
	{
		System.out.println("value of x="+x+"value of y="+y);
	}
	public void show(double x,int y)
	{
		System.out.println("value of x="+x+"value of y="+y);
	}
	public void show(int x,double y)
	{
		System.out.println("value of x="+x+"value of y="+y);
	}
}
public class Polymorphismdemo {

	public static void main(String[] args) {
		
		Test11 t=new Test11();
		t.show(10);
		t.show(4.5, 20);
		t.show(10, 3.5);
		t.show(10, 20);

	}

}

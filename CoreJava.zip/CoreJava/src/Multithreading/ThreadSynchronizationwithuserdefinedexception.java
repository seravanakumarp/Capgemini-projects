package Multithreading;
class InsufficientFundsException extends Exception
{
	String name;
	public InsufficientFundsException(String name) 
	{
		this.name=name;
	}
	public String getErrorMessage()
	{
		return this.name;
	}
}
class Account
{
	int balance;
	Account(int balance)
	{
		this.balance=balance;
	}
	public int getBalance()
	{
		return this.balance;
	}
	public synchronized void withdraw(int amount) throws InsufficientFundsException
	{
		System.out.println("Withdrawal amount:"+amount);
		
		if(amount<=this.balance)
		{
			this.balance=this.balance-amount;
		}
		else
		{
			throw new InsufficientFundsException("No funds");
		}
	}
}
class AccountThread extends Thread
{
	Account atm;
	int amount;
	
	AccountThread(Account atm,int amount)
	{
		this.atm=atm;
		this.amount=amount;
	}
	public void run()
	{
		try
		{
			atm.withdraw(amount);
		}
		catch(InsufficientFundsException ie)
		{
			System.out.println(ie.getErrorMessage());
		}
	}
}
public class ThreadSynchronizationwithuserdefinedexception 
{

	public static void main(String[] args) throws Exception
	{
		Account acc=new Account(6000);
		System.out.println("Current available balance:"+acc.getBalance());
		
		AccountThread t1=new AccountThread(acc,4000);
		AccountThread t2=new AccountThread(acc,3000);
		
		t1.start();
		t2.start();
		
		t1.join();
		t2.join();
		
		System.out.println("Current available balance="+acc.getBalance());
		

	}

}

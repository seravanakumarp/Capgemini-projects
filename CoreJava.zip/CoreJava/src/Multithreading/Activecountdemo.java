package Multithreading;

public class Activecountdemo extends Thread
{
	public Activecountdemo(String threadname,ThreadGroup tg) 
	{
		super(tg,threadname);
		start();
	}
	public void run()
	{
		for(int i=0;i<1000;i++)
		{
			try
			{
				Thread.sleep(100);
			}
			catch(Exception e)
			{
				e.getMessage();
			}
		}
	}
	public static void main(String[] args) 
	{
		ThreadGroup tg=new ThreadGroup("parent thread group");
		Activecountdemo t1=new Activecountdemo("one",tg);
		System.out.println("Starting one");
		Activecountdemo t2=new Activecountdemo("two",tg);
		System.out.println("Starting two");
		
		System.out.println("number of active threads:"+tg.activeCount());
		

	}

}

package Multithreading;
class P
{
	int num;
	boolean value=false;
	public synchronized void put(int num)
	{
		while(value)
		{
			try
			{
			wait();
			}
			catch(Exception e)
			{
				
			}
		}
		System.out.println("put:"+num);
		this.num=num;
		value=true;
		notify();
	}
	public synchronized void get()
	{
		while(!value)
		{
			try
			{
				wait();
			}
			catch(Exception e)
			{
				
			}
		}
		System.out.println("get:"+num);
		value=false;
		notify();
	}
}
class Producer implements Runnable
{
	P p;
	Producer(P p)
	{
		this.p=p;
		Thread t=new Thread(this,"Producer");
		t.start();
	}
	public void run()
	{
		int i=0;
		while(true)
		{
			try
			{
			p.put(i++);
			Thread.sleep(1000);
			}
			catch(Exception e)
			{
				
			}
		}
	}
}
class Consumer implements Runnable
{
	P p;
	Consumer(P p)
	{
		this.p=p;
		Thread t=new Thread(this,"Consumer");
		t.start();
	}
	public void run()
	{
			while(true)
			{
				try
				{
				p.get();
				Thread.sleep(1000);
				}
				catch(Exception e)
				{
					
				}
			}
		
	}
}
public class Interthreadcommunication 
{

	public static void main(String[] args) 
	{
		P p=new P();
		new Producer(p);
		new Consumer(p);
	}

}

package Multithreading;
class Thread1 implements Runnable
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception e)
			{
				
			}
			System.out.println("Hi");
		}
		System.out.println(Thread.currentThread().getName());
			
	}
}
class Thread2 implements Runnable
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception e)
			{
				
			}
			System.out.println("hello");
		}
		System.out.println(Thread.currentThread().getName());
	}
}
public class Runnabledemo {

	public static void main(String[] args) throws Exception
	{
		Thread1 t1=new Thread1();
		Thread2 t2=new Thread2();
		
		Thread t11=new Thread(t1);
		Thread t22=new Thread(t2);
		
		t11.start();
		try
		{
			Thread.sleep(10);
		}
		catch(Exception e)
		{
			
		}
		t22.start();
		
		System.out.println(t11.isAlive());
		System.out.println(t22.isAlive());
		
		System.out.println(t11.getName());
		System.out.println(t22.getName());
		
		t11.setName("First Thread");
		t22.setName("Second Thread");
		
		System.out.println(t11.getName());
		System.out.println(t22.getName());
		
		System.out.println(t11.getPriority());
		t11.setPriority(2);
		t22.setPriority(8);
		
		System.out.println(t11.getPriority());
		System.out.println(t22.getPriority());
		
		System.out.println(Thread.MIN_PRIORITY);
		System.out.println(Thread.NORM_PRIORITY);
		System.out.println(Thread.MAX_PRIORITY);
		
		
		t11.join();
		t22.join();
		
		System.out.println(t11.isAlive());
		System.out.println(t22.isAlive());
		
		System.out.println(t11.getId());
		System.out.println(t22.getId());
		
		
		System.out.println("happy coding");
	}

}

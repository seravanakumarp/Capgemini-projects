package Methodcalling;

import java.util.Scanner;

public class Armstrongwithmethodcalling {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int n;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
		int result=armstrongnumber(n);
		
		if(result==1)
			System.out.println("armstrong number");
		else
			System.out.println("not an armstrong number");
	}
	public static int armstrongnumber(int n)
	{
		int temp1,temp2,count=0,rem,x,y,sum=0;
		temp1=n;
		while(temp1!=0)
		{
			temp1=temp1/10;
			count++;
		}
		temp2=n;
		while(temp2!=0)
		{
			rem=temp2%10;
			x=1;y=count;
			while(y>0)
			{
				x=x*rem;
				y--;
			}
			sum=sum+x;
			temp2=temp2/10;
		}
		if(sum==n)
			return 1;
		else
			return 0;
	}
}

package Methodcalling;
import java.util.*;
public class Type4methodcallilng {

	public static void main(String[] args) 
	{
			fibonacci_series();
	}
	public static void fibonacci_series()
	{
		Scanner sc=new Scanner(System.in);
		
		int limit,fib1=0,fib2=1,fib3,count;
		
		System.out.println("Enter the limit");
		limit=sc.nextInt();
		
		System.out.print(fib1+" "+fib2+" ");
		
		count=2;
		do
		{
			fib3=fib1+fib2;
			System.out.print(fib3+" ");
			fib1=fib2;
			fib2=fib3;
			count++;
		}while(count<limit);
		
		
	}
}

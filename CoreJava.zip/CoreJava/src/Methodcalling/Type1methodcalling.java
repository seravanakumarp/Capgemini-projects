package Methodcalling;
import java.util.*;
public class Type1methodcalling 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		float a,b,c,area;
		
		System.out.println("enter the sides of triangle");
		a=sc.nextFloat();
		b=sc.nextFloat();
		c=sc.nextFloat();
		
		area=area_of_triangle(a,b,c); //calling method
		
		System.out.println("area of triangle="+area);
				
	}
	public static float area_of_triangle(float x,float y,float z)
	{
		float side,area;
		side=(x+y+z)/2;
		area=(float)Math.sqrt(side*(side-x)*(side-y)*(side-z));
		return area;
	}

}

package Methodcalling;
//Method returning an object

class Student10
{
	int rollno=121;
	String name="raju";
	float marks=456;
}

public class Methodreturningobject {

	public static void main(String[] args) 
	{
		Methodreturningobject mro=new Methodreturningobject();
		Student10 s=mro.print();
		
		System.out.println(s.rollno+" "+s.name+" "+s.marks);
	}

	Student10 print()
	{
		Student10 s1=new Student10();
		return s1;
	}
}

package Methodcalling;

import java.util.Scanner;

public class Primewithmethodcalling
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int result,n;
		
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		
		result=primeCheck(n);
		
		if(result==1)
			System.out.println("it is a prime number");
		else
			System.out.println("it is not a prime number");
	}
	public static int primeCheck(int n)
	{
		int i,x=0;
		i=2;
		while(i<=n/2)
		{
			if(n%i==0)
			{
				x=1;
				break;
			}
			i++;
		}
		if(x==0)
			return 1;
		else
			return 0;
	}

}

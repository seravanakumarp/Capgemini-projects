package Methodcalling;
import java.util.*;
class Prime
{
	public boolean prime_number(int n)
	{
		int i,x=0;
		i=2;
		while(i<=n/2) //2<=5 3<=5 4<=5 5<=5 6<=5
		{
			if(n%i==0)
			{
				x=1;
				break;
			}
			i++;
		}
		if(x==0)
			return true;
		else
			return false;
	}
}
class Palindrome
{
	public boolean palindrome_number(int n)
	{
		int rem,rev=0,temp;
		temp=n;
		while(temp!=0)
		{
			rem=temp%10;
			rev=rev*10+rem;
			temp=temp/10;
		}
		if(n==rev)
			return true;
		else
			return false;
	}
}
public class Primepalindromenumbers {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		Prime p=new Prime(); //create an object of Prime class
		Palindrome pd=new Palindrome(); //create an object of Palindrome class
		
		int i,n;

		System.out.println("Enter the value of n");
		n=sc.nextInt(); //1000
	
		for(i=1;i<=n;i++)
		{
			if(p.prime_number(i) && pd.palindrome_number(i))
				System.out.print(i+" ");
			
		}
		
	}

}

package Methodcalling;
class LCM
{
	public int lcm_of_two(int a,int b)
	{
		int largest=(a>b)?a:b;
		int lcm=0;
		
		for(int i=1;i<=largest;i++)
		{
			if(largest%a==0 && largest%b==0)
			{
				lcm=largest;
				break;
			}
			largest++;
		}
		return lcm;
	}
}
class GCD
{
	public int gcd_of_two(int a,int b)
	{
		int num,den,rem;
		
		if(a>b)
		{
			num=a;
			den=b;
		}
		else
		{
			num=b;
			den=a;
		}
		rem=num%den;
		
		while(rem!=0)
		{
			num=den;
			den=rem;
			rem=num%den;
		}
		return den;
		
	}
}
public class LCMANDGCDusingmethodcalling
{

	public static void main(String[] args) 
	{
		LCM l=new LCM();
		GCD g=new GCD();
		
		int lcm=l.lcm_of_two(24, 36);
		int gcd=g.gcd_of_two(24, 36);
		
		System.out.println("lcm of two numbers="+lcm);
		System.out.println("gcd of two numbers="+gcd);
		
	}

}

package Methodcalling;
//passing object as an argument inside of a method.
class Employee
{
	int empid=1234;
	String name="venkat";
	float salary=55000;
}
public class Objectasargument {

	public static void main(String[] args)
	{
		Objectasargument osa=new Objectasargument();
		Employee e=new Employee();
		osa.display(e);
		
	}
	public void display(Employee e1)
	{
		System.out.println(e1.empid+" "+e1.name+" "+e1.salary);
	}

}

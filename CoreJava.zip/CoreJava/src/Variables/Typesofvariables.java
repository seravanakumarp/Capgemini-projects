/*  Types of variable:
 * 
 *  Definition: A quantity which changes during the execution of a program
 *  is called a variable.
 *  
 *  1. Instance variable
 *  2. Static variable
 *  3. Local variable
 *  4. Reference variable
 *  
 *  Instance variable:
 *  
 *  1. A variable which is declared inside a class outside the method and
 *  outside the constructor is called as instance variable.
 *  
 *  2. Memory for the instance variable is allocated during the object creation
 *  time.
 *  
 *  3. Memory for the instance variable is allocated at heap memory.
 *  
 *  4. Memory for the instance variable is allocated every time an object
 *  is been created.
 *  
 *  5. Every object will have a copy of instance variable.
 *  
 *  6. When an instance variable is declared but not initialized, it
 *  will be initialized with the default values.
 *  
 *  		int - 0
 *          float - 0.0
 *          double -0.0
 *          char - space
 *          String - null
 *          long - 0
 *          byte -0
 *          short -0
 *          boolean - false
 *          any class - null
 *          
 * 7. If all the objects of the instance variables want to have same value,
 * it can initialized during the declaration time or by means
 * of zero argument constructor.
 * 
 * 8. If all the objects of the instance variables want to have different
 * value, it can done by means of parameterized constructor.
 * 
 * 
 * Static variable:
 * 
 * 1. A variable which is declared inside a class outside a method and outside
 * a constructor with a static keyword is called static variable.
 * 
 * 2. Memory for the static variables are allocated during the class
 * loading time.
 * 
 * 3. Memory for the static variables is allocated in memory segment
 * called method area.
 * 
 * 4. Memory for the static variables is allocated only one time for an
 * entire class.
 * 
 * 5. All the objects share the static variables.
 * 
 * 6. If a static variable is declared but not initialized, it will be
 * initialized with the default values.
 * 
 * 7. A class contains both the instance variables as well as static
 * variables.
 * 
 * Local variable:
 * 
 * 1. A variable which is declared inside a class inside a method or
 * inside a constructor is called local variable.
 * 
 * 2. Memory for the local variables are allocated during the method
 * invocation or constructor invocation.
 * 
 * 3. Memory for the local variables are allocated in java stack.
 * 
 * 4. Memory for the local variables is allocated every time when a method
 * or constructor is invoked.
 * 
 * 5. If a local variable is declared but not initialized, it will not
 * be initialized with default values. The programmer must explicitly
 * initialize the local variables upon declaration.
 * 
 * Reference variable:
 * 
 * 1. A variable which is referring or pointing to a object is called 
 * reference variable.
 * 
 * 2. The reference variable of any class can be declared as static,instance
 * and local.
 * 
 * 3. With the help of reference variable, we can access instance members
 * as well as static members of a class.
 * 
 * Instance method:
 * 
 * A method which is defined inside a class without a static keyword are 
 * called instance methods.
 * 
 *    Syntax: Access_specifier return_type method_name(Paramter_list)
 *    			{
 *    			}
 *    Example: public int display()
 *    			{
 *    			}
 * Static method:
 * 
 * A method which is defined inside a class with a static keyword is called
 * static method.
 * 
 *    Syntax: Access_specifier static return_type method_name(parameter_list)
 *    			{
 *    			}
 *    Example: public static void display()
 *    			{
 *    			}
 * A class can contain both the instance members(instance variables as
 * well as instance methods) and static members(static variables as
 * well as static methods).
 * 
 * Instance members are accessed by means of reference(Object) whereas
 * static members are accessed by means of reference(object) or class
 * name.
 * 
 * NOTE: it is always better to access the static members by means of 
 * class name rather than reference because availability of object is 
 * not guaranteed.
 * 
 * An instance method can access both instance members and static members
 * directly whereas a static method can access only the static members.
 * 
 */
package Variables;

public class Typesofvariables 
{
	int a; //instance variable
	static int b; //static variable
	static char c;
    String d;
    boolean e;
	
	public static void main(String[] args) 
	{
		Typesofvariables tov=new Typesofvariables();
		System.out.println(tov.a);
		System.out.println(b);
		System.out.println(Typesofvariables.b);
		System.out.println(tov.b);
		System.out.println(c);
		System.out.println(tov.d);
		System.out.println(tov.e);
		
	}

}

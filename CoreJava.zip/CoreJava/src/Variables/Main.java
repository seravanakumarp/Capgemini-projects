package Variables;

public class Main {

	public static void main(String[] args) 
	{
		Employee e=new Employee();
		e.setEmpno(101);
		e.setName("John");
		e.setSalary(45000);
		
		System.out.println("Employee Number: "+e.getEmpno());
		System.out.println("Employee Name: "+e.getName());
		System.out.println("Employee Salary: "+e.getSalary());
		
		
		
		
	}

}

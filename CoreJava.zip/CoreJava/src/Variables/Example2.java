package Variables;

public class Example2 
{
	int x=10;
	static int y=20;
	
	public void display()
	{
		System.out.println(x);
		System.out.println(y);
	}
	public static void print()
	{
		System.out.println(y);
		//System.out.println(x);
	}
	public static void main(String[] args) 
	{
		Example2 e=new Example2();
		e.display();
		e.print();
	}

}

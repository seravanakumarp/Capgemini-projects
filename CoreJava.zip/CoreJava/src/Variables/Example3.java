package Variables;

public class Example3 
{
	int x=0;
	static int y=0;
	public static void main(String[] args) 
	{
		Example3 e1=new Example3();
		e1.x++;
		e1.y++;
		
		System.out.println(e1.x+" "+e1.y);
		
		Example3 e2=new Example3();
		
		e2.x++;
		e2.y++;
		
		System.out.println(e2.x+" "+e2.y);
		
		Example3 e3=new Example3();
		
		e3.x++;
		e3.y++;
		
		System.out.println(e3.x+" "+e3.y);
	}

}

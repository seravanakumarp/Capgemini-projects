/*
 * Access Specifiers:
 * -> They are used to define the level of accessibility of members of 
 * a class or interface/ level of accessibility of class and interface
 * in a package.
 * 
 * -> They define the scope of accessing the class or interface by providing
 * the security.
 * 
 * Java comes four different access specifiers:
 * -> public
 * -> private
 * -> protected
 * -> default
 * 
 * public: If a member is declared as public, it is accessed to all the classes
 * as well as all the packages. public can be applied to variables,
 * methods,constructors,classes and interfaces.
 * 
 * private: If a member is declared as private, it is accessed within
 * the class itself. A private can be applied to variables,
 * constructors and methods.
 * 
 * protected: If a member is declared as protected, it is accessed within
 * the package and subclasses of other package. A protected can be applied
 * to variables, constructors and methods.
 * 
 * default: If a member is not declared either as a protected, private
 * and public then it is called as default access specifier. If a member
 * is default, it can be accessed within package. Hence a default access
 * specifier is also treated as package level access specifier.
 * A default can be applied to classes, variables, methods,constructors
 * and interfaces.
 * 
 * -> Public is the most accessible access specifier whereas private
 * is most restricted access specifier in java.
 * 
 * Overriding Rule: When a method is overriding, the child class method
 * access specifier must be same as that of parent class method access
 * specifier or it should be above.
 * 
 * a private method can't be inherited and hence it cannot be overridden.
 * 
 * A class and interface can have access specifier called public and 
 * default.
 * 
 * If a class is public class, the class name and the file name must be
 * the same.
 * 
 * If a class is default class, the class name and the file name need not
 * to be same.
 * 
 * A java program can have any number of classes, but can contain atmost
 * one public class.
 * 
 * Any class in java will have a constructor whether we specify or not.
 * If a class is a public class, then the compiler will allocate a
 * public zero parameterized constructor.
 * 
 * If a class is a default class, then the compiler will allocate a
 * default zero parameterized constructor.
 * 
 * A compiler cannot provide private and protected constructor as well
 * as parameterized constructor.
 * 
 * A programmer can have any constructor defined explicitly with access specifiers such
 * as public, private, protected and default.
 * 
 * Singleton class:
 * A class which contains only one object, then it is treated as 
 * singleton class.
 * This singleton class can be achieved by having a private constructor
 * inside a class.
 * 
 * 
 * 
 * 
 */
package Variables;

public class Accessspecifiers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

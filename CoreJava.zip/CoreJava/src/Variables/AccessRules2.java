package Variables;

public class AccessRules2 
{
	void m4() //instance method
	{
		AccessRules1 ar2=new AccessRules1();
		System.out.println(ar2.x); //rule1
		ar2.m1(); //rule1
		System.out.println(AccessRules1.y);//rule2
		ar2.m3(); //rule2
		System.out.println("instance method of m4");
	}
	public static void main(String[] args) 
	{
		AccessRules1 ar3=new AccessRules1();
		System.out.println(ar3.y); //rule3
		ar3.m3(); //rule3
		System.out.println(ar3.x); //rule4
		ar3.m1();
		AccessRules2 arr=new AccessRules2();
		arr.m4(); //rule4
	}

}

package Variables;

public class Example4 
{
	int a=10;
	int b=20;
	public static void main(String[] args)
	{
		Example4 e4=new Example4();
		int c=30;
		int d;
		
		System.out.println(e4.a);
		System.out.println(e4.b);
		
		System.out.println(c);
		d=35;
		System.out.println(d);
	}

}

package Arrays;
import java.util.*;
/*
 *              1 2 3 4 5
 *              0 1 2 3 4
 *              
 *              1 2 6 3 4 5
 *              0 1 2 3 4 5
 */
public class Insertion {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int a[]=new int[10];
		int i,n,location,element;
		
		System.out.println("Enter the size of array a");
		n=sc.nextInt();
		
		System.out.println("Enter the array a elements");
		for(i=0;i<n;i++)
			a[i]=sc.nextInt();
		
		System.out.println("Enter the element to be inserted");
		element=sc.nextInt(); //6
		
		System.out.println("Enter the location to be inserted");
		location=sc.nextInt(); //3
		 
		for(i=n;i>=location;i--) //i=5 5>=3 i=4 4>=3 3>=3 2>=3
			a[i]=a[i-1]; //a[5]=a[4] a[4]=a[3] a[3]=a[2]
		
		
		a[i]=element; //a[2]=6
		
		n++;
		
		for(i=0;i<n;i++)
			System.out.print(a[i]+" ");
		
	}

}

package Arrays;

public class SumOfArrayElements 
{

	public static void main(String[] args) 
	{
			int a[]= {2,5,7,9,13,18},sum=0;
			
			for(int i=0;i<a.length;i++)
			{
				sum=sum+a[i];
			}
			System.out.println("sum of array a elements="+sum);
	}

}

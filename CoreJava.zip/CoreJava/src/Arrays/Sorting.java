package Arrays;
import java.util.*;
public class Sorting {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int a[]=new int[10];
		int i,n,j,temp;
		
		System.out.println("Enter the size of array a");
		n=sc.nextInt();
		
		System.out.println("Enter the array a elements");
		for(i=0;i<n;i++)
			a[i]=sc.nextInt();
		// 25 52 12 45 36
		// 0  1  2  3  4
		// 12 52 25 45 36
		// 
		for(i=0;i<n;i++) //i=0 i=1
		{
			for(j=i+1;j<n;j++) //j=1 j=2 j=3 j=4 j=5 j=2
			{
				if(a[i]>a[j]) //25>52 25>12	12>45 12>36 52>25 52>45 52>36 25>45 25>36 45>36
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					
				}
			}
		}
		
		for(i=0;i<n;i++)
			System.out.print(a[i]+" ");
		
	}

}

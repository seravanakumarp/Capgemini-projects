package Arrays;
import java.util.*;
public class Twodarrays {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int a[][]=new int[5][5];
		
		int i,j,row,col;
		
		System.out.println("Enter the number of rows and columns");
		row=sc.nextInt();
		col=sc.nextInt();
		
		System.out.println("Enter the elements of the 2d array");
		for(i=0;i<row;i++)
		{
			for(j=0;j<col;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		
		System.out.println("The elements of the 2d array are");
		
		for(i=0;	i<row;i++)
		{
			for(j=0;j<col;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
	}

}

package Arrays;
import java.util.*;
public class Removingduplicates 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int a[]=new int[10];
		
		int i,n,j,k;
		
		System.out.println("Enter the size of array a");
		n=sc.nextInt();
		
		System.out.println("Enter the array a elements");
		for(i=0;i<n;i++)
			a[i]=sc.nextInt();
		
		for(i=0;i<n;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if(a[i]==a[j])
				{
					for(k=j;k<n-1;k++)
						a[k]=a[k+1];
					j--;
					n--;
					
				}
			}
		}
		for(i=0;i<n;i++)
			System.out.print(a[i]+" ");
	
	}

}

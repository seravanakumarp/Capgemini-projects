package Arrays;

import java.util.Scanner;

public class Sumandproduct {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
			int a[][]=new int[5][5];
			
			int i,j,row,col,sum=0,product=1;
			
			System.out.println("Enter the size of two dimensional array a");
			row=sc.nextInt();
			col=sc.nextInt();
			
			//storing the elements into 2d array a
			System.out.println("Enter the elements of 2D Array a");
			for(i=0;i<row;i++)
			{
				for(j=0;j<col;j++)
				{
					a[i][j]=sc.nextInt();
				}
			}
			
			for(i=0;i<row;i++)
			{
				for(j=0;j<col;j++)
				{
					sum=sum+a[i][j];
					product=product*a[i][j];
				}
			}
			System.out.println("sum of all the elements of array a="+sum);
			System.out.println("product of all the elements of array a="+product);
			
			
	}

}

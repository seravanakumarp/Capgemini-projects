package Arrays;
import java.util.*;
public class Secondlargest {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		int a[]=new int[20];
		int i,n,largest,slargest;
		
		System.out.println("enter the size of array a");
		n=sc.nextInt();
		
		System.out.println("Enter the array a elements");
		for(i=0;i<n;i++)
			a[i]=sc.nextInt();
		
		largest=a[0];
		for(i=1;i<n;i++)
		{
			if(a[i]>largest)
				largest=a[i];
		}
		slargest=Integer.MIN_VALUE;
		
		for(i=0;i<n;i++)
		{
			if(a[i]>slargest && a[i]!=largest)
				slargest=a[i];
				
		}
		System.out.println(slargest);
		
	}

}

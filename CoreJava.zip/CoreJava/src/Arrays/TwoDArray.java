package Arrays;
import java.util.*;
public class TwoDArray 
{

	public static void main(String[] args) 
	{
			Scanner sc=new Scanner(System.in);
			
		/*	int a[][]=new int[10][10];
			
			int i,j,row,col;
			
			System.out.println("Enter the size of two dimensional array a");
			row=sc.nextInt();
			col=sc.nextInt();
			
			//storing the elements into 2d array a
			System.out.println("Enter the elements of 2D Array a");
			for(i=0;i<row;i++)
			{
				for(j=0;j<col;j++)
				{
					a[i][j]=sc.nextInt();
				}
			}
			
			//Retrieving elements from 2d array a 
			for(i=0;i<row;i++)
			{
				for(j=0;j<col;j++)
				{
					System.out.print(a[i][j]+" ");
				}
				System.out.println("");
			}
		*/
			
		/*	int a[][]= {{1,2,3},{4,5,6},{7,8,9}};
			
			int i,j;
			
			for(i=0;i<a.length;i++)
			{
				for(j=0;j<a[i].length;j++)
				{
					System.out.print(a[i][j]+" ");
				}
				System.out.println("");
			}
		*/
			
			/*int a[][]= {{1,2},{4,5,6},{7,8,9,10}};
			
			int i,j;
			
			for(i=0;i<a.length;i++)
			{
				for(j=0;j<a[i].length;j++)
				{
					System.out.print(a[i][j]+" ");
				}
				System.out.println("");
			}*/
			
			
			int a[][]=new int[3][4];
			
			int i,j;
			
			System.out.println("Enter the elements of 2d array a ");
			for(i=0;i<a.length;i++)
			{
				for(j=0;j<a[i].length;j++)
				{
					a[i][j]=sc.nextInt();
				}
			}
			
			
			for(i=0;i<a.length;i++)
			{
				for(j=0;j<a[i].length;j++)
				{
					System.out.print(a[i][j]+" ");
				}
				System.out.println("");
			}
			
	}

}

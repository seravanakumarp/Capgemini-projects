package Arrays;
import java.util.*;
public class Merging {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		int n,i,j;
		
		System.out.println("Enter the size of two arrays");
		n=sc.nextInt();
		
		int a[]=new int[n]; //1 2 3 4 5
		int b[]=new int[n]; //6 7 8 9 10
		int c[]=new int[2*n];
		
		System.out.println("Enter the array a elements");
		for(i=0;i<n;i++)
			a[i]=sc.nextInt();
		
		System.out.println("Enter the array b elements");
		for(i=0;i<n;i++)
			b[i]=sc.nextInt();
		
		for(i=0;i<n;i++)
			c[i]=a[i]; //
		
		j=i; //
		for(i=0;i<n;i++)
		{
			c[j]=b[i]; //c[5]=b[0] c[6]=b[1]
			j++;
		}
		
		for(i=0;i<j;i++)
			System.out.print(c[i]+" ");
		
		
		
		
		
	}

}

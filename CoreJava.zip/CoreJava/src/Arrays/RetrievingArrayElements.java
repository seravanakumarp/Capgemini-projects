package Arrays;
import java.util.*;
public class RetrievingArrayElements {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		//int a[]=new int[]{1,2,3,4,5}; //initialization of 1-D array
		
		/*int a[]= {1,2,3,4,5}; 
		
		int i;
		//Retrieving the elements of an array
		for(i=0;i<5;i++)
			System.out.println("index:"+i+"-"+a[i]); */
		
		
		int a[]=new int[10]; //declaration of 1-d array a
		
		int i,n;
		
		System.out.println("Enter the size of array a");
		n=sc.nextInt();
		
		
		System.out.println("enter the elements of array a");
		for(i=0;i<n;i++)
			a[i]=sc.nextInt();
		
		System.out.println("array a alements are");
		for(i=0;i<n;i++)
			System.out.println(i+"-"+a[i]);
		
		
		
		
	}

}

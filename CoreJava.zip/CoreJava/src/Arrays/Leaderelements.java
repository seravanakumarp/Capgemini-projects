package Arrays;

import java.util.Scanner;

public class Leaderelements {

	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		
		int a[]=new int[10];
		
		int i,n,j;
		
		System.out.println("Enter the size of array a");
		n=sc.nextInt();
		
		System.out.println("Enter the array a elements");
		for(i=0;i<n;i++)
			a[i]=sc.nextInt();
		
		for(i=0;i<n;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if(a[i]<a[j])
					break;
			}
			if(j==n)
				System.out.print(a[i]+" ");
		}
	
	}

}

package Arrays;

import java.util.Scanner;

public class Sparsematrix {

	public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
		
		int a[][]=new int[5][5];
		
		int i,j,row,col,count=0;
		
		System.out.println("Enter the size of 2D Array a");
		row=sc.nextInt();
		col=sc.nextInt();
		
		System.out.println("Enter the 2d array a elements");
		for(i=0;i<row;i++)
		{
			for(j=0;j<col;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		
		for(i=0;i<row;i++)
		{
			for(j=0;j<col;j++)
			{
				if(a[i][j]==0)
					count++;
			}
		}
		if(count>(row*col)/2)
			System.out.println("sparse matrix");
		else
			System.out.println("not a sparse matrix");
	}

}

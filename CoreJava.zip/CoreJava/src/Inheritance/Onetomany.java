package Inheritance;
class Book
{
	String title;
	String publisher;
	float price;
	
	Book(String title,String publisher,float price)
	{
		this.title=title;
		this.publisher=publisher;
		this.price=price;
	}
	void display()
	{
		System.out.print(title+" "+publisher+" "+price+" ");
	}
}
class Authors
{
	String name1;
	String name2;
	String name3;
	
	Authors(String name1,String name2,String name3)
	{
		this.name1=name1;
		this.name2=name2;
		this.name3=name3;
	}
	void print()
	{
		System.out.print(this.name1+" "+this.name2+" "+this.name3);
	}
}

public class Onetomany {

	public static void main(String[] args) 
	{
		Book b=new Book("Java Complete Reference","Tata McGrawHill",750);
		b.display();
		Authors a=new Authors("Herbert Schildt","Rohan kumar","Sunil Kumar");
		a.print();
	}

}

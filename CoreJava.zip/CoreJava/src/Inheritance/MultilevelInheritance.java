package Inheritance;
class GrandFather
{
	String name;
	int age;
	
	public void set(String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	
	public void get()
	{
		System.out.println(name+" "+age);
	}
}
class Father extends GrandFather
{
     float salary;
     String designation;
     
     public void accept(String name,int age,float salary,String designation)
     {
    	 this.name=name;
    	 this.age=age;
    	 this.salary=salary;
    	 this.designation=designation;
    			 
     }
     public void display()
     {
    	 System.out.println(name+" "+age+" "+salary+" "+designation);
     }
}
class Son extends Father
{
	String education;
		
	public void receive(String name,int age,String education)
	{
		this.name=name;
		this.age=age;
		this.education=education;
	}
	public void show()
	{
		System.out.println(name+" "+age+" "+education);
	}
}
public class MultilevelInheritance {

	public static void main(String[] args) 
	{
		Son s=new Son();
		
		System.out.println("*********Grandfather details**********");
		s.set("Chandrashekar", 65);
		s.get();
		
		System.out.println("*********Father details**********");
		s.accept("Prasad", 50, 45000,"analyst");
		s.display();
		
		System.out.println("*********Son details**********");
		s.receive("Srujan", 35,"MTECH");
		s.show();
		
	}

}

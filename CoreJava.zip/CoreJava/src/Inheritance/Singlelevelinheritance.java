package Inheritance;
class Person
{
	public void work()
	{
		System.out.println("works in an organization");
	}
	
}
class Manager extends Person
{
	public void workforteam()
	{
		System.out.println("works for himself and supports team");
	}
}
public class Singlelevelinheritance {

	public static void main(String[] args) 
	{
			Manager m=new Manager();
			m.work();
			m.workforteam();

	}

}

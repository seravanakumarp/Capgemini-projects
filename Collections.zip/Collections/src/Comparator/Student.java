package Comparator;

public class Student 
{
	int rollno;
	String name;
	String branch;
	int semester;
	float marks;
	public Student(int rollno, String name, String branch, int semester, float marks)
	{
		
		this.rollno = rollno;
		this.name = name;
		this.branch = branch;
		this.semester = semester;
		this.marks = marks;
	}
	
}

package Map;

import java.util.*;

public class Mapiterator {

	public static void main(String[] args)
	{
		String[] books = {"C", "C++", "Java", "Python", "Android"};
		double[] prices = {200.0, 300.0, 250.0, 200.0, 250.0};
		Map<String, Double> map = new HashMap<String, Double>();
		for(int i=0 ; i<=books.length-1 ; i++)
		{
		map.put(books[i], prices[i]);
		}
		System.out.println("Map is : ");
		Set<String> keys = map.keySet();
		Iterator<String> itr = keys.iterator();
		while(itr.hasNext())
		{
		String key = itr.next();
		Double value = map.get(key);
		System.out.println(key + " = " + value);
		}

	}

}

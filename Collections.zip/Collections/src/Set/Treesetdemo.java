package Set;
import java.util.*;
public class Treesetdemo 
{
	public static void main(String[] args)
	{
		Set<Integer> set = new TreeSet<Integer>();
		set.add(50);
		set.add(40);
		set.add(30);
		set.add(20);
		set.add(10);
		System.out.println("Set : " + set);
		}

}

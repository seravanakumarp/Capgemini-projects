package Set;
import java.util.*;
public class Example1 {

	public static void main(String[] args) 
	{
		Set<Integer> set = new HashSet<Integer>();
		set.add(50);
		set.add(40);
		set.add(30);
		set.add(20);
		set.add(10);
		System.out.println("Set : " + set);
	}

}

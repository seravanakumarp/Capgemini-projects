package Arraylist;
import java.util.*;
class Test1
{
	static Vector<Integer> list = new Vector<Integer>();
}
class First1 extends Thread
{
	public void run()
	{
		for (int i=1 ; i<=100000 ; i++)
		{
			Test1.list.add(i);
		}
	}
}
class Second1 extends Thread
{
	public void run()
	{
		for (int i=1 ; i<=100000 ; i++)
		{
			Test1.list.add(i);
		}
	}
}

public class Vectorsynchronized 
{
	public static void main(String[] args) throws Exception
	{
		First1 f = new First1();
		Second1 s = new Second1();
		f.start();
		s.start();
		f.join();
		s.join();
		System.out.println("Vector size is : " + Test1.list.size());
	}
}

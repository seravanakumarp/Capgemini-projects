package Arraylist;
import java.util.*;
public class ArraylistCRUD {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		List<Employee> list = new ArrayList<Employee>();
		while(true)
		{
			System.out.println("1.Add Record");
			System.out.println("2.Display Record");
			System.out.println("3.Display All");
			System.out.println("4.Update Record");
			System.out.println("5.Delete Record");
			System.out.println("6.Exit");
			
			System.out.print("Enter choice : ");
			int ch = sc.nextInt();
			if(ch==1)
			{
				System.out.println("Enter details :");
				int id = sc.nextInt();
				String name = sc.next();
				double salary = sc.nextDouble();
				Employee e=new Employee(id,name,salary);
				list.add(e);
				System.out.println("Record Added");
			}
			else if(ch==2)
			{
				if(list.isEmpty())
				{
					System.out.println("empty list");
				}
				else
				{
					System.out.print("Enter id : ");
					int id = sc.nextInt();
					boolean found=false;
					for(Employee e : list)
					{
						if(e.id == id)
						{
							System.out.println("Name : " + e.name);
							System.out.println("Salary : " + e.salary);
							found = true;
							break;
						}
					}
					if(!found)
						System.out.println("Invalid ID");
					}
				}
			else if(ch==3)
			{
				if(list.isEmpty())
				{
					System.out.println("Empty list");
				}
				else
				{
				System.out.println("Details : ");
					for(Employee e : list)
					{
						System.out.println("Name : " + e.name);
						System.out.println("Salary : " + e.salary);
					}
				}
			}
			else if(ch==4)
			{
				if(list.isEmpty())
				{
				System.out.println("Empty list");
				}
				else
				{
					System.out.print("Enter id : ");
					int id = sc.nextInt();
					boolean found=false;
					for(Employee e : list)
					{
						if(e.id == id)
						{
						System.out.print("Enter sal to update: ");
						double salary = sc.nextDouble();
						e.salary = salary;
						System.out.println("Record updated");
						found = true;
						break;
						}
					}
				if(!found)
				System.out.println("Invalid ID");
				}
			}
			else if(ch==5)
			{
				if(list.isEmpty())
				{	
					System.out.println("Empty list");
				}
			else
			{
				System.out.print("Enter id : ");
				int id = sc.nextInt();
				boolean found=false;
				for(Employee e : list)
				{
					if(e.id == id)
					{
					int index = list.indexOf(e);
					list.remove(index);
					System.out.println("Removed");
					found = true;
					break;
					}
				}
			if(!found)
			System.out.println("Invalid ID");
			}
			}
			else if(ch==6)
			{
				System.out.println("End");
				System.exit(1);
			}
			else
				System.out.println("Invalid choice");
			}

			
		}
	}


